import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { WorkOrder, WorkOrderStatus, UrgencyLevel } from '../../types';
import {
  UserCheck,
  CheckCircle2,
  Clock,
  AlertTriangle,
  Search,
  Filter,
  Wrench,
  Sparkles,
  ArrowRight,
  Plus,
  Boxes,
  FileText,
  Calendar,
  Building,
  Cpu,
  Check,
  CheckCheck,
  RotateCcw,
  ExternalLink,
  X,
  Send,
  SlidersHorizontal,
} from 'lucide-react';

interface MyAssignedTasksViewProps {
  onOpenNewTicketModal?: () => void;
}

export const MyAssignedTasksView: React.FC<MyAssignedTasksViewProps> = ({
  onOpenNewTicketModal,
}) => {
  const {
    currentUser,
    workOrders,
    updateWorkOrder,
    spareParts,
    recordStockMovement,
    openAssetHistoryById,
    setActiveTab,
    isAdmin,
  } = useApp();

  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState<string>('active'); // 'all', 'active', 'In Progress', 'Open', 'Pending', 'Closed'
  const [filterUrgency, setFilterUrgency] = useState<string>('all');
  const [selectedTechnicianName, setSelectedTechnicianName] = useState<string>(
    currentUser?.name || 'Agus Wijaya'
  );

  // Quick Complete modal state (In Progress -> Closed)
  const [taskToComplete, setTaskToComplete] = useState<WorkOrder | null>(null);
  const [completeNotes, setCompleteNotes] = useState('');
  const [completeDowntime, setCompleteDowntime] = useState<number>(2.0);
  const [completePartId, setCompletePartId] = useState('');
  const [completePartQty, setCompletePartQty] = useState(1);
  const [completeError, setCompleteError] = useState<string | null>(null);

  // Quick Action / Details modal
  const [selectedTask, setSelectedTask] = useState<WorkOrder | null>(null);

  // Match technician
  const isAssignedToUser = (wo: WorkOrder) => {
    const techTarget = selectedTechnicianName.toLowerCase();
    const assigned = (wo.assignedTechnician || '').toLowerCase();
    if (!assigned) return false;
    return (
      assigned.includes(techTarget) ||
      techTarget.includes(assigned) ||
      (assigned.includes('agus') && techTarget.includes('agus')) ||
      (assigned.includes('budi') && techTarget.includes('budi')) ||
      (assigned.includes('hendra') && techTarget.includes('hendra'))
    );
  };

  // Filter tasks
  const userTasks = workOrders.filter(isAssignedToUser);

  const inProgressTasks = userTasks.filter((t) => t.status === 'In Progress');
  const openOrPendingTasks = userTasks.filter((t) => t.status === 'Open' || t.status === 'Pending');
  const closedTasks = userTasks.filter((t) => t.status === 'Closed');
  const activeTasks = userTasks.filter((t) => t.status !== 'Closed');

  const filteredTasks = userTasks.filter((wo) => {
    // Status filter
    if (filterStatus === 'active' && wo.status === 'Closed') return false;
    if (filterStatus === 'In Progress' && wo.status !== 'In Progress') return false;
    if (filterStatus === 'Open' && wo.status !== 'Open') return false;
    if (filterStatus === 'Pending' && wo.status !== 'Pending') return false;
    if (filterStatus === 'Closed' && wo.status !== 'Closed') return false;

    // Urgency filter
    if (filterUrgency !== 'all' && wo.urgency !== filterUrgency) return false;

    // Search query
    const query = searchTerm.toLowerCase();
    return (
      wo.title.toLowerCase().includes(query) ||
      wo.ticketNumber.toLowerCase().includes(query) ||
      wo.machineName.toLowerCase().includes(query) ||
      wo.category.toLowerCase().includes(query) ||
      wo.reporterName.toLowerCase().includes(query)
    );
  });

  // Open Quick Complete Modal
  const handleOpenCompleteModal = (wo: WorkOrder, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    setTaskToComplete(wo);
    setCompleteNotes(
      wo.actionsTaken ||
        'Perbaikan mesin telah selesai dilakukan oleh teknisi. Parameter pengujian normal dan mesin siap beroperasi kembali.'
    );
    setCompleteDowntime(wo.downtimeHours || 2.0);
    setCompletePartId('');
    setCompletePartQty(1);
    setCompleteError(null);
  };

  // Fast direct 1-click status update to Closed
  const handleDirectClose = (wo: WorkOrder, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    const nowStr = new Date().toISOString().slice(0, 16).replace('T', ' ');
    updateWorkOrder(wo.id, {
      status: 'Closed',
      completedDate: nowStr,
      downtimeHours: wo.downtimeHours || 2.5,
      actionsTaken:
        wo.actionsTaken ||
        'Perbaikan selesai diverifikasi. Mesin telah kembali beroperasi normal pada jalur produksi.',
    });
  };

  // Fast direct status change to In Progress
  const handleDirectStart = (wo: WorkOrder, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    updateWorkOrder(wo.id, {
      status: 'In Progress',
      assignedTechnician: wo.assignedTechnician || currentUser?.name || 'Agus Wijaya',
    });
  };

  // Fast direct status change dropdown
  const handleStatusChange = (wo: WorkOrder, newStatus: WorkOrderStatus) => {
    const nowStr = new Date().toISOString().slice(0, 16).replace('T', ' ');
    updateWorkOrder(wo.id, {
      status: newStatus,
      completedDate: newStatus === 'Closed' ? nowStr : wo.completedDate,
      downtimeHours:
        newStatus === 'Closed' && !wo.downtimeHours ? 2.5 : wo.downtimeHours,
    });
  };

  // Submit complete modal
  const handleConfirmQuickComplete = (e: React.FormEvent) => {
    e.preventDefault();
    if (!taskToComplete) return;

    // Optional spare part deduction if technician used one
    if (completePartId) {
      const part = spareParts.find((p) => p.id === completePartId);
      if (part) {
        if (part.currentStock < completePartQty) {
          setCompleteError(
            `Stok ${part.name} tidak cukup (sisa ${part.currentStock} ${part.unit})`
          );
          return;
        }
        recordStockMovement({
          partId: part.id,
          type: 'out',
          quantity: completePartQty,
          machineNo: taskToComplete.machineNo,
          referenceWO: taskToComplete.ticketNumber,
          notes: `Penggantian part saat closing tiket ${taskToComplete.ticketNumber}`,
        });

        const newUsed = [
          ...taskToComplete.usedParts,
          {
            partId: part.id,
            partName: part.name,
            category: part.category,
            quantity: completePartQty,
          },
        ];
        updateWorkOrder(taskToComplete.id, { usedParts: newUsed });
      }
    }

    const nowStr = new Date().toISOString().slice(0, 16).replace('T', ' ');

    updateWorkOrder(taskToComplete.id, {
      status: 'Closed',
      completedDate: nowStr,
      downtimeHours: completeDowntime,
      actionsTaken: completeNotes,
    });

    setTaskToComplete(null);
  };

  const getUrgencyBadge = (urgency: UrgencyLevel) => {
    switch (urgency) {
      case 'Emergency':
        return 'bg-red-600 text-white font-black animate-pulse';
      case 'High':
        return 'bg-amber-500 text-white font-bold';
      case 'Medium':
        return 'bg-blue-600 text-white font-semibold';
      case 'Low':
        return 'bg-slate-200 text-slate-700 font-semibold';
    }
  };

  const getStatusBadge = (status: WorkOrderStatus) => {
    switch (status) {
      case 'Open':
        return 'bg-slate-100 text-slate-700 border-slate-300';
      case 'In Progress':
        return 'bg-amber-50 text-amber-800 border-amber-300';
      case 'Pending':
        return 'bg-purple-50 text-purple-800 border-purple-300';
      case 'Closed':
        return 'bg-emerald-50 text-emerald-800 border-emerald-300';
    }
  };

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Header bar */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 bg-white p-6 rounded-3xl border border-emerald-100 shadow-xs">
        <div className="flex items-start gap-4">
          <div className="w-12 h-12 rounded-2xl bg-emerald-600 text-white flex items-center justify-center font-bold shadow-lg shadow-emerald-600/30 shrink-0">
            <UserCheck className="w-6 h-6" />
          </div>
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-50 text-emerald-800 text-xs font-bold mb-1.5 border border-emerald-200">
              <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
              <span>Personal Technician Workspace</span>
            </div>
            <h1 className="text-2xl font-black text-slate-900 tracking-tight flex items-center gap-2.5">
              <span>Tugas Saya (My Assigned Tasks)</span>
            </h1>
            <p className="text-xs sm:text-sm text-slate-500 mt-1">
              Fokus kerja khusus teknisi PIC: kelola tiket yang ditugaskan, mulai pengerjaan, dan perbarui status langsung dari <strong>In Progress</strong> ke <strong>Closed</strong>.
            </p>
          </div>
        </div>

        {/* Technician switcher (if admin or testing) */}
        <div className="flex flex-wrap items-center gap-3">
          {isAdmin ? (
            <div className="flex items-center gap-2 bg-slate-50 border border-slate-200 px-3 py-1.5 rounded-xl">
              <SlidersHorizontal className="w-3.5 h-3.5 text-slate-500" />
              <span className="text-xs text-slate-600 font-semibold">Lihat Teknisi:</span>
              <select
                value={selectedTechnicianName}
                onChange={(e) => setSelectedTechnicianName(e.target.value)}
                className="bg-transparent text-xs font-bold text-emerald-800 focus:outline-hidden cursor-pointer"
              >
                <option value="Agus Wijaya">Agus Wijaya (Staff Teknisi)</option>
                <option value="Hendra Pratama">Hendra Pratama (Staff Teknisi)</option>
                <option value="Budi Santoso, S.T.">Budi Santoso (Admin/SPV)</option>
              </select>
            </div>
          ) : (
            <div className="flex items-center gap-2 bg-emerald-50/80 border border-emerald-200 px-3.5 py-2 rounded-xl text-xs font-bold text-emerald-900">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping"></span>
              <span>Login sebagai: {currentUser?.name}</span>
            </div>
          )}

          {onOpenNewTicketModal && (
            <button
              onClick={onOpenNewTicketModal}
              className="flex items-center gap-1.5 px-4 py-2 bg-emerald-600 hover:bg-emerald-700 active:scale-95 text-white rounded-xl text-xs sm:text-sm font-bold shadow-md shadow-emerald-600/30 transition-all cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>Lapor Tiket Baru</span>
            </button>
          )}
        </div>
      </div>

      {/* KPI / Status Summary Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {/* In Progress card */}
        <div
          onClick={() => setFilterStatus('In Progress')}
          className={`p-5 rounded-2xl border transition-all cursor-pointer ${
            filterStatus === 'In Progress'
              ? 'bg-amber-500 text-white border-amber-600 shadow-md ring-2 ring-amber-400'
              : 'bg-white text-slate-800 border-amber-200 hover:border-amber-400 hover:bg-amber-50/40'
          }`}
        >
          <div className="flex items-center justify-between">
            <span
              className={`text-xs font-bold uppercase tracking-wider ${
                filterStatus === 'In Progress' ? 'text-amber-100' : 'text-amber-700'
              }`}
            >
              Sedang Dikerjakan
            </span>
            <div
              className={`w-8 h-8 rounded-xl flex items-center justify-center ${
                filterStatus === 'In Progress'
                  ? 'bg-white/20 text-white'
                  : 'bg-amber-100 text-amber-700'
              }`}
            >
              <Wrench className="w-4 h-4 animate-spin" />
            </div>
          </div>
          <div className="text-3xl font-black mt-2">{inProgressTasks.length}</div>
          <div
            className={`text-[11px] mt-1 font-medium ${
              filterStatus === 'In Progress' ? 'text-amber-100' : 'text-slate-500'
            }`}
          >
            Siap diselesaikan (In Progress ➔ Closed)
          </div>
        </div>

        {/* Open & Pending card */}
        <div
          onClick={() => setFilterStatus('Open')}
          className={`p-5 rounded-2xl border transition-all cursor-pointer ${
            filterStatus === 'Open' || filterStatus === 'Pending'
              ? 'bg-blue-600 text-white border-blue-700 shadow-md ring-2 ring-blue-400'
              : 'bg-white text-slate-800 border-blue-200 hover:border-blue-400 hover:bg-blue-50/40'
          }`}
        >
          <div className="flex items-center justify-between">
            <span
              className={`text-xs font-bold uppercase tracking-wider ${
                filterStatus === 'Open' || filterStatus === 'Pending'
                  ? 'text-blue-100'
                  : 'text-blue-700'
              }`}
            >
              Antrean / Pending
            </span>
            <div
              className={`w-8 h-8 rounded-xl flex items-center justify-center ${
                filterStatus === 'Open' || filterStatus === 'Pending'
                  ? 'bg-white/20 text-white'
                  : 'bg-blue-100 text-blue-700'
              }`}
            >
              <Clock className="w-4 h-4" />
            </div>
          </div>
          <div className="text-3xl font-black mt-2">{openOrPendingTasks.length}</div>
          <div
            className={`text-[11px] mt-1 font-medium ${
              filterStatus === 'Open' || filterStatus === 'Pending'
                ? 'text-blue-100'
                : 'text-slate-500'
            }`}
          >
            Menunggu dieksekusi oleh teknisi
          </div>
        </div>

        {/* Closed card */}
        <div
          onClick={() => setFilterStatus('Closed')}
          className={`p-5 rounded-2xl border transition-all cursor-pointer ${
            filterStatus === 'Closed'
              ? 'bg-emerald-600 text-white border-emerald-700 shadow-md ring-2 ring-emerald-400'
              : 'bg-white text-slate-800 border-emerald-200 hover:border-emerald-400 hover:bg-emerald-50/40'
          }`}
        >
          <div className="flex items-center justify-between">
            <span
              className={`text-xs font-bold uppercase tracking-wider ${
                filterStatus === 'Closed' ? 'text-emerald-100' : 'text-emerald-700'
              }`}
            >
              Telah Selesai (Closed)
            </span>
            <div
              className={`w-8 h-8 rounded-xl flex items-center justify-center ${
                filterStatus === 'Closed'
                  ? 'bg-white/20 text-white'
                  : 'bg-emerald-100 text-emerald-700'
              }`}
            >
              <CheckCircle2 className="w-4 h-4" />
            </div>
          </div>
          <div className="text-3xl font-black mt-2">{closedTasks.length}</div>
          <div
            className={`text-[11px] mt-1 font-medium ${
              filterStatus === 'Closed' ? 'text-emerald-100' : 'text-slate-500'
            }`}
          >
            Tiket tertutup dengan sukses
          </div>
        </div>

        {/* Total Tasks card */}
        <div
          onClick={() => setFilterStatus('all')}
          className={`p-5 rounded-2xl border transition-all cursor-pointer ${
            filterStatus === 'all'
              ? 'bg-slate-900 text-white border-slate-950 shadow-md ring-2 ring-slate-400'
              : 'bg-white text-slate-800 border-slate-200 hover:border-slate-400 hover:bg-slate-50/50'
          }`}
        >
          <div className="flex items-center justify-between">
            <span
              className={`text-xs font-bold uppercase tracking-wider ${
                filterStatus === 'all' ? 'text-slate-300' : 'text-slate-500'
              }`}
            >
              Total Tiket Saya
            </span>
            <div
              className={`w-8 h-8 rounded-xl flex items-center justify-center ${
                filterStatus === 'all'
                  ? 'bg-white/20 text-white'
                  : 'bg-slate-100 text-slate-600'
              }`}
            >
              <FileText className="w-4 h-4" />
            </div>
          </div>
          <div className="text-3xl font-black mt-2">{userTasks.length}</div>
          <div
            className={`text-[11px] mt-1 font-medium ${
              filterStatus === 'all' ? 'text-slate-300' : 'text-slate-500'
            }`}
          >
            {activeTasks.length} tugas belum tertutup
          </div>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white p-4 rounded-2xl border border-emerald-100 shadow-xs flex flex-col md:flex-row items-center justify-between gap-3">
        {/* Status Tab Chips */}
        <div className="flex flex-wrap items-center gap-1.5 w-full md:w-auto">
          <button
            onClick={() => setFilterStatus('active')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              filterStatus === 'active'
                ? 'bg-emerald-600 text-white shadow-xs'
                : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            Aktif / Perlu Tindakan ({activeTasks.length})
          </button>
          <button
            onClick={() => setFilterStatus('In Progress')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              filterStatus === 'In Progress'
                ? 'bg-amber-500 text-white shadow-xs'
                : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            In Progress ({inProgressTasks.length})
          </button>
          <button
            onClick={() => setFilterStatus('Open')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              filterStatus === 'Open'
                ? 'bg-blue-600 text-white shadow-xs'
                : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            Open / Pending ({openOrPendingTasks.length})
          </button>
          <button
            onClick={() => setFilterStatus('Closed')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              filterStatus === 'Closed'
                ? 'bg-emerald-700 text-white shadow-xs'
                : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            Closed ({closedTasks.length})
          </button>
          <button
            onClick={() => setFilterStatus('all')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              filterStatus === 'all'
                ? 'bg-slate-800 text-white shadow-xs'
                : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            Semua ({userTasks.length})
          </button>
        </div>

        {/* Search & Urgency filter */}
        <div className="flex items-center gap-2.5 w-full md:w-auto">
          <div className="relative flex-1 sm:w-60">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Cari tiket atau mesin..."
              className="w-full pl-9 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-emerald-500"
            />
          </div>

          <select
            value={filterUrgency}
            onChange={(e) => setFilterUrgency(e.target.value)}
            className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-700 focus:outline-hidden cursor-pointer"
          >
            <option value="all">Semua Urgensi</option>
            <option value="Emergency">Emergency</option>
            <option value="High">High</option>
            <option value="Medium">Medium</option>
            <option value="Low">Low</option>
          </select>
        </div>
      </div>

      {/* Task List Section */}
      <div className="space-y-4">
        {filteredTasks.length === 0 ? (
          <div className="bg-white p-12 rounded-3xl border border-emerald-100 text-center shadow-xs">
            <div className="w-16 h-16 rounded-full bg-emerald-50 text-emerald-600 flex items-center justify-center mx-auto mb-4">
              <CheckCheck className="w-8 h-8" />
            </div>
            <h3 className="text-lg font-bold text-slate-800">
              {filterStatus === 'In Progress'
                ? 'Tidak Ada Tiket Sedang Dikerjakan'
                : filterStatus === 'active'
                ? 'Kerja Bagus! Tidak Ada Tugas Menunggu'
                : 'Tidak Ada Tugas yang Cocok'}
            </h3>
            <p className="text-xs text-slate-500 mt-1 max-w-md mx-auto">
              {filterStatus === 'active'
                ? 'Semua tiket perbaikan yang ditugaskan kepada Anda sudah diselesaikan (Closed).'
                : 'Coba ubah filter pencarian atau lihat seluruh tiket departemen.'}
            </p>
            <div className="mt-5 flex items-center justify-center gap-3">
              <button
                onClick={() => setFilterStatus('all')}
                className="px-4 py-2 border border-slate-200 hover:bg-slate-50 text-slate-700 text-xs font-bold rounded-xl cursor-pointer"
              >
                Lihat Semua Riwayat Tiket
              </button>
              <button
                onClick={() => setActiveTab('work-orders')}
                className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl shadow-xs cursor-pointer"
              >
                Buka Seluruh Work Order
              </button>
            </div>
          </div>
        ) : (
          filteredTasks.map((wo) => {
            const isInProgress = wo.status === 'In Progress';
            const isClosed = wo.status === 'Closed';

            return (
              <div
                key={wo.id}
                className={`bg-white rounded-3xl border transition-all duration-200 overflow-hidden shadow-xs hover:shadow-md ${
                  isInProgress
                    ? 'border-amber-300 ring-2 ring-amber-400/20'
                    : isClosed
                    ? 'border-emerald-100 bg-slate-50/50'
                    : 'border-slate-200'
                }`}
              >
                {/* Top card banner */}
                <div className="p-5 sm:p-6">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-100">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="font-mono text-xs font-extrabold text-slate-800 bg-slate-100 px-2.5 py-1 rounded-lg">
                        {wo.ticketNumber}
                      </span>
                      <span
                        className={`text-[10px] px-2.5 py-1 rounded-full uppercase tracking-wider ${getUrgencyBadge(
                          wo.urgency
                        )}`}
                      >
                        {wo.urgency}
                      </span>
                      <span className="text-xs text-slate-500 font-medium">
                        Kategori: <strong className="text-slate-700">{wo.category}</strong>
                      </span>
                    </div>

                    {/* Status badge & Quick dropdown */}
                    <div className="flex items-center gap-2">
                      <span className="text-[11px] text-slate-400 font-medium hidden sm:inline">
                        Status Saat Ini:
                      </span>
                      <select
                        value={wo.status}
                        onChange={(e) =>
                          handleStatusChange(wo, e.target.value as WorkOrderStatus)
                        }
                        className={`text-xs font-extrabold px-3 py-1.5 rounded-xl border focus:outline-hidden cursor-pointer ${getStatusBadge(
                          wo.status
                        )}`}
                      >
                        <option value="Open">Open</option>
                        <option value="In Progress">In Progress</option>
                        <option value="Pending">Pending</option>
                        <option value="Closed">Closed</option>
                      </select>
                    </div>
                  </div>

                  {/* Title & Description */}
                  <div className="mt-4">
                    <h3 className="text-base sm:text-lg font-extrabold text-slate-900 tracking-tight">
                      {wo.title}
                    </h3>
                    <p className="text-xs text-slate-600 mt-2 leading-relaxed bg-slate-50/80 p-3 rounded-2xl border border-slate-100">
                      <strong className="text-slate-800 font-semibold block mb-0.5">
                        Laporan Kerusakan:
                      </strong>
                      {wo.description}
                    </p>
                  </div>

                  {/* Machine & Target info grid */}
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mt-4 text-xs">
                    <div className="flex items-center gap-2 p-2.5 rounded-xl bg-emerald-50/60 border border-emerald-100">
                      <Cpu className="w-4 h-4 text-emerald-700 shrink-0" />
                      <div className="min-w-0">
                        <span className="text-[10px] text-emerald-800 block uppercase font-bold">
                          Unit Mesin
                        </span>
                        <span className="font-bold text-slate-900 truncate block">
                          {wo.machineName}
                        </span>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 p-2.5 rounded-xl bg-slate-50 border border-slate-100">
                      <Building className="w-4 h-4 text-slate-600 shrink-0" />
                      <div className="min-w-0">
                        <span className="text-[10px] text-slate-500 block uppercase font-bold">
                          Pelapor / Departemen
                        </span>
                        <span className="font-bold text-slate-800 truncate block">
                          {wo.reporterName} ({wo.department})
                        </span>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 p-2.5 rounded-xl bg-slate-50 border border-slate-100">
                      <Calendar className="w-4 h-4 text-slate-600 shrink-0" />
                      <div className="min-w-0">
                        <span className="text-[10px] text-slate-500 block uppercase font-bold">
                          Waktu Lapor / Target
                        </span>
                        <span className="font-bold text-slate-800 truncate block">
                          {wo.createdDate} ➔ {wo.targetDate}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Actions Taken so far (if any) */}
                  {wo.actionsTaken && (
                    <div className="mt-3.5 p-3 rounded-xl bg-teal-50/50 border border-teal-100 text-xs">
                      <span className="text-[11px] font-bold text-teal-900 block mb-0.5">
                        Tindakan Perbaikan yang Dicatat:
                      </span>
                      <p className="text-slate-700 text-xs leading-relaxed">
                        {wo.actionsTaken}
                      </p>
                    </div>
                  )}

                  {/* Parts used */}
                  {wo.usedParts && wo.usedParts.length > 0 && (
                    <div className="mt-3 flex flex-wrap items-center gap-2 text-xs">
                      <span className="text-[11px] font-semibold text-slate-500 flex items-center gap-1">
                        <Boxes className="w-3.5 h-3.5 text-slate-400" />
                        Suku Cadang Terpakai:
                      </span>
                      {wo.usedParts.map((p, idx) => (
                        <span
                          key={idx}
                          className="px-2.5 py-0.5 rounded-md bg-emerald-100/70 text-emerald-800 font-bold text-[11px]"
                        >
                          {p.partName} ({p.quantity} pcs)
                        </span>
                      ))}
                    </div>
                  )}

                  {/* Action buttons footer */}
                  <div className="mt-5 pt-4 border-t border-slate-100 flex flex-wrap items-center justify-between gap-3">
                    {/* Secondary links */}
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => openAssetHistoryById(wo.machineId || wo.machineNo)}
                        className="flex items-center gap-1 px-3 py-1.5 rounded-xl border border-slate-200 hover:bg-slate-100 text-slate-700 text-xs font-semibold cursor-pointer transition-colors"
                        title="Buka Kartu Riwayat Aset Mesin ini"
                      >
                        <ExternalLink className="w-3.5 h-3.5 text-emerald-600" />
                        <span>Riwayat Mesin #{wo.machineNo}</span>
                      </button>
                    </div>

                    {/* Prominent Quick-Action Button */}
                    <div className="flex items-center gap-2">
                      {isInProgress && (
                        <>
                          {/* Direct 1-Click Complete */}
                          <button
                            onClick={(e) => handleDirectClose(wo, e)}
                            className="flex items-center gap-1.5 px-4 py-2 bg-emerald-600 hover:bg-emerald-700 active:scale-95 text-white rounded-xl text-xs sm:text-sm font-extrabold shadow-md shadow-emerald-600/30 transition-all cursor-pointer"
                            title="Tutup tiket langsung dengan 1-klik"
                          >
                            <Check className="w-4 h-4" />
                            <span>1-Klik: Selesaikan (Closed)</span>
                          </button>

                          {/* Detailed Complete Modal (with spare parts & downtime) */}
                          <button
                            onClick={(e) => handleOpenCompleteModal(wo, e)}
                            className="flex items-center gap-1.5 px-3.5 py-2 border-2 border-emerald-600 text-emerald-800 hover:bg-emerald-50 rounded-xl text-xs font-bold transition-all cursor-pointer"
                            title="Selesaikan dengan mencatat suku cadang & downtime"
                          >
                            <FileText className="w-4 h-4 text-emerald-600" />
                            <span>Catat Part & Close</span>
                          </button>
                        </>
                      )}

                      {(wo.status === 'Open' || wo.status === 'Pending') && (
                        <button
                          onClick={(e) => handleDirectStart(wo, e)}
                          className="flex items-center gap-1.5 px-4 py-2 bg-amber-500 hover:bg-amber-600 active:scale-95 text-white rounded-xl text-xs sm:text-sm font-extrabold shadow-md shadow-amber-500/30 transition-all cursor-pointer"
                        >
                          <Wrench className="w-4 h-4" />
                          <span>Mulai Kerjakan (In Progress)</span>
                        </button>
                      )}

                      {isClosed && (
                        <div className="flex items-center gap-2 text-xs font-bold text-emerald-700 bg-emerald-50 px-3 py-1.5 rounded-xl border border-emerald-200">
                          <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                          <span>Selesai ({wo.completedDate || 'Closed'})</span>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Quick Complete Modal (In Progress -> Closed) */}
      {taskToComplete && (
        <div className="fixed inset-0 bg-slate-900/60 z-50 flex items-center justify-center p-4 backdrop-blur-xs animate-fadeIn">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 shadow-2xl border border-emerald-100 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-emerald-600 text-white flex items-center justify-center shadow-xs">
                  <CheckCircle2 className="w-5 h-5" />
                </div>
                <div>
                  <span className="text-[10px] uppercase font-bold tracking-wider text-emerald-700 block">
                    Penyelesaian Pekerjaan Teknisi
                  </span>
                  <h3 className="text-base font-extrabold text-slate-900">
                    Selesaikan Tiket: {taskToComplete.ticketNumber}
                  </h3>
                </div>
              </div>
              <button
                onClick={() => setTaskToComplete(null)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-100"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleConfirmQuickComplete} className="mt-4 space-y-4 text-xs">
              <div className="p-3 rounded-xl bg-slate-50 border border-slate-200">
                <div className="font-bold text-slate-800 text-sm">
                  {taskToComplete.title}
                </div>
                <div className="text-slate-500 mt-1">
                  Unit: <strong>{taskToComplete.machineName}</strong> | Teknisi PIC:{' '}
                  <strong>{taskToComplete.assignedTechnician}</strong>
                </div>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">
                  Tindakan Perbaikan / Langkah Teknis yang Dilakukan *
                </label>
                <textarea
                  rows={3}
                  required
                  value={completeNotes}
                  onChange={(e) => setCompleteNotes(e.target.value)}
                  placeholder="Jelaskan komponen yang diperbaiki, diganti, atau di-adjust..."
                  className="w-full p-3 rounded-xl border border-slate-300 focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">
                  Downtime Mesin Aktual (Jam)
                </label>
                <input
                  type="number"
                  step="0.5"
                  min="0"
                  value={completeDowntime}
                  onChange={(e) => setCompleteDowntime(parseFloat(e.target.value) || 0)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
                />
              </div>

              <div className="p-3 rounded-2xl bg-emerald-50/60 border border-emerald-200 space-y-2">
                <span className="font-bold text-emerald-900 block">
                  Pemakaian Suku Cadang (Otomatis potong stok gudang):
                </span>
                <div className="grid grid-cols-3 gap-2">
                  <div className="col-span-2">
                    <select
                      value={completePartId}
                      onChange={(e) => {
                        setCompletePartId(e.target.value);
                        setCompleteError(null);
                      }}
                      className="w-full px-3 py-2 rounded-xl border border-emerald-300 bg-white text-xs font-semibold text-slate-700"
                    >
                      <option value="">-- Tanpa Suku Cadang Tambahan --</option>
                      {spareParts.map((p) => (
                        <option key={p.id} value={p.id}>
                          {p.name} (Stok: {p.currentStock} {p.unit})
                        </option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <input
                      type="number"
                      min="1"
                      value={completePartQty}
                      onChange={(e) => setCompletePartQty(parseInt(e.target.value) || 1)}
                      className="w-full px-3 py-2 rounded-xl border border-emerald-300 bg-white text-xs font-semibold"
                      placeholder="Qty"
                    />
                  </div>
                </div>
                {completeError && (
                  <p className="text-[11px] text-red-600 font-bold mt-1">
                    {completeError}
                  </p>
                )}
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setTaskToComplete(null)}
                  className="px-4 py-2 border border-slate-200 hover:bg-slate-50 rounded-xl text-slate-600 font-semibold cursor-pointer"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-emerald-600 hover:bg-emerald-700 active:scale-95 text-white font-extrabold rounded-xl shadow-md shadow-emerald-600/30 cursor-pointer flex items-center gap-1.5"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Konfirmasi Tutup Tiket (Closed)</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
