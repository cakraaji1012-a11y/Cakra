import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { WorkOrder, WorkOrderStatus, UrgencyLevel, WorkOrderCategory } from '../../types';
import { exportWorkOrdersToExcel } from '../../utils/exportUtils';
import { ReportPrintModal } from '../common/ReportPrintModal';
import {
  ClipboardList,
  Plus,
  Search,
  Filter,
  AlertCircle,
  Clock,
  CheckCircle2,
  Hourglass,
  User,
  Wrench,
  Trash2,
  Edit,
  Eye,
  Layers,
  ArrowRight,
  Package,
  Calendar,
  AlertOctagon,
  Building,
  FileSpreadsheet,
  Printer,
  UserCheck,
  Play,
  CheckCheck,
  Sparkles,
} from 'lucide-react';

interface WorkOrderViewProps {
  onOpenNewTicketModal: () => void;
}

export const WorkOrderView: React.FC<WorkOrderViewProps> = ({ onOpenNewTicketModal }) => {
  const {
    workOrders,
    updateWorkOrder,
    deleteWorkOrder,
    isAdmin,
    isStaff,
    spareParts,
    recordStockMovement,
    currentUser,
  } = useApp();

  // Task scope: Default to 'my-tasks' for staff, 'all' for admin
  const [activeTaskScope, setActiveTaskScope] = useState<'my-tasks' | 'all'>(
    currentUser?.role === 'staff' ? 'my-tasks' : 'all'
  );
  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [filterUrgency, setFilterUrgency] = useState<string>('all');
  const [filterCategory, setFilterCategory] = useState<string>('all');
  const [viewMode, setViewMode] = useState<'kanban' | 'table'>('kanban');
  const [showReportModal, setShowReportModal] = useState(false);

  // Quick Complete modal state (In Progress -> Closed)
  const [taskToComplete, setTaskToComplete] = useState<WorkOrder | null>(null);
  const [completeNotes, setCompleteNotes] = useState('');
  const [completeDowntime, setCompleteDowntime] = useState<number>(2.0);
  const [completePartId, setCompletePartId] = useState('');
  const [completePartQty, setCompletePartQty] = useState(1);
  const [completeError, setCompleteError] = useState<string | null>(null);

  // Selected WO for full details modal
  const [selectedWO, setSelectedWO] = useState<WorkOrder | null>(null);

  // Check if ticket is assigned to currently logged-in user
  const isAssignedToMe = (wo: WorkOrder) => {
    if (!currentUser?.name) return false;
    const currentName = currentUser.name.toLowerCase();
    const assigned = (wo.assignedTechnician || '').toLowerCase();
    if (!assigned) return false;
    return currentName.includes(assigned) || assigned.includes(currentName) ||
           (assigned.includes('agus') && currentName.includes('agus')) ||
           (assigned.includes('budi') && currentName.includes('budi'));
  };

  const myAssignedTasks = workOrders.filter(isAssignedToMe);
  const myActiveTasksCount = myAssignedTasks.filter((w) => w.status !== 'Closed').length;
  const myInProgressCount = myAssignedTasks.filter((w) => w.status === 'In Progress').length;

  // Open Quick Complete Modal for In Progress task
  const openQuickCompleteModal = (wo: WorkOrder, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    setTaskToComplete(wo);
    setCompleteNotes(wo.actionsTaken || 'Perbaikan selesai dilakukan. Komponen diuji coba dan mesin beroperasi normal.');
    setCompleteDowntime(wo.downtimeHours || 2.0);
    setCompletePartId('');
    setCompletePartQty(1);
    setCompleteError(null);
  };

  // Quick start task: Open -> In Progress
  const handleQuickStartTask = (wo: WorkOrder, e: React.MouseEvent) => {
    e.stopPropagation();
    updateWorkOrder(wo.id, {
      status: 'In Progress',
      assignedTechnician: wo.assignedTechnician || currentUser?.name || 'Agus Wijaya',
    });
  };

  // Confirm Quick Complete (In Progress -> Closed)
  const handleConfirmQuickComplete = () => {
    if (!taskToComplete) return;

    // Optional spare part deduction if technician used any
    if (completePartId) {
      const part = spareParts.find((p) => p.id === completePartId);
      if (part) {
        if (part.currentStock < completePartQty) {
          setCompleteError(`Stok ${part.name} tidak cukup (sisa ${part.currentStock} ${part.unit})`);
          return;
        }
        recordStockMovement({
          partId: part.id,
          type: 'out',
          quantity: completePartQty,
          machineNo: taskToComplete.machineNo,
          referenceWO: taskToComplete.ticketNumber,
          notes: `Penggantian saat penyelesaian tiket ${taskToComplete.ticketNumber}`,
        });

        const newUsed = [
          ...taskToComplete.usedParts,
          {
            partId: part.id,
            partName: part.name,
            category: part.category,
            quantity: completePartQty,
          },
        ];
        updateWorkOrder(taskToComplete.id, { usedParts: newUsed });
      }
    }

    const nowStr = new Date().toISOString().slice(0, 16).replace('T', ' ');

    updateWorkOrder(taskToComplete.id, {
      status: 'Closed',
      completedDate: nowStr,
      downtimeHours: completeDowntime,
      actionsTaken: completeNotes,
    });

    setTaskToComplete(null);
  };

  // Form states inside details modal
  const [editTechnician, setEditTechnician] = useState('');
  const [editStatus, setEditStatus] = useState<WorkOrderStatus>('Open');
  const [editActionsTaken, setEditActionsTaken] = useState('');
  const [selectedPartId, setSelectedPartId] = useState('');
  const [partQuantity, setPartQuantity] = useState(1);
  const [partError, setPartError] = useState<string | null>(null);

  const openDetails = (wo: WorkOrder) => {
    setSelectedWO(wo);
    setEditTechnician(wo.assignedTechnician || '');
    setEditStatus(wo.status);
    setEditActionsTaken(wo.actionsTaken || '');
    setSelectedPartId('');
    setPartQuantity(1);
    setPartError(null);
  };

  const handleSaveDetails = () => {
    if (!selectedWO) return;
    updateWorkOrder(selectedWO.id, {
      assignedTechnician: editTechnician,
      status: editStatus,
      actionsTaken: editActionsTaken,
      completedDate:
        editStatus === 'Closed' && !selectedWO.completedDate
          ? new Date().toISOString().slice(0, 16).replace('T', ' ')
          : selectedWO.completedDate,
      downtimeHours:
        editStatus === 'Closed' && !selectedWO.downtimeHours ? 3.0 : selectedWO.downtimeHours,
    });
    setSelectedWO(null);
  };

  // Add spare part to this WO and record stock deduction
  const handleAddPartToWO = () => {
    if (!selectedWO || !selectedPartId) return;
    const part = spareParts.find((p) => p.id === selectedPartId);
    if (!part) return;

    if (part.currentStock < partQuantity) {
      setPartError(`Stok tidak mencukupi! Sisa stok ${part.name} hanya ${part.currentStock} ${part.unit}`);
      return;
    }

    const success = recordStockMovement({
      partId: part.id,
      type: 'out',
      quantity: partQuantity,
      machineNo: selectedWO.machineNo,
      referenceWO: selectedWO.ticketNumber,
      notes: `Digunakan untuk perbaikan ${selectedWO.ticketNumber} (${selectedWO.machineName})`,
    });

    if (success) {
      const updatedUsed = [
        ...selectedWO.usedParts,
        {
          partId: part.id,
          partName: part.name,
          category: part.category,
          quantity: partQuantity,
        },
      ];
      updateWorkOrder(selectedWO.id, { usedParts: updatedUsed });
      setSelectedWO({ ...selectedWO, usedParts: updatedUsed });
      setSelectedPartId('');
      setPartQuantity(1);
      setPartError(null);
    }
  };

  const handleDelete = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (confirm('Apakah Anda yakin ingin menghapus tiket ini secara permanen?')) {
      deleteWorkOrder(id);
      if (selectedWO?.id === id) setSelectedWO(null);
    }
  };

  // Filtered WOs
  const filteredWOs = workOrders.filter((wo) => {
    // If viewing My Tasks, only show tickets assigned to current user
    if (activeTaskScope === 'my-tasks' && !isAssignedToMe(wo)) {
      return false;
    }

    const matchSearch =
      wo.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      wo.ticketNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
      wo.machineName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      wo.reporterName.toLowerCase().includes(searchTerm.toLowerCase());

    const matchStatus = filterStatus === 'all' || wo.status === filterStatus;
    const matchUrgency = filterUrgency === 'all' || wo.urgency === filterUrgency;
    const matchCat = filterCategory === 'all' || wo.category === filterCategory;

    return matchSearch && matchStatus && matchUrgency && matchCat;
  });

  const getUrgencyBadge = (urgency: UrgencyLevel) => {
    switch (urgency) {
      case 'Emergency':
        return 'bg-red-600 text-white font-black animate-pulse';
      case 'High':
        return 'bg-amber-500 text-white font-bold';
      case 'Medium':
        return 'bg-blue-600 text-white font-semibold';
      case 'Low':
        return 'bg-slate-200 text-slate-700 font-semibold';
    }
  };

  const getStatusBadge = (status: WorkOrderStatus) => {
    switch (status) {
      case 'Open':
        return 'bg-slate-100 text-slate-700 border-slate-300';
      case 'In Progress':
        return 'bg-amber-50 text-amber-800 border-amber-300';
      case 'Pending':
        return 'bg-purple-50 text-purple-800 border-purple-300';
      case 'Closed':
        return 'bg-emerald-50 text-emerald-800 border-emerald-300';
    }
  };

  const kanbanColumns: WorkOrderStatus[] = ['Open', 'In Progress', 'Pending', 'Closed'];

  return (
    <div className="space-y-6">
      {/* Header bar */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white p-6 rounded-3xl border border-emerald-100 shadow-xs">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-50 text-emerald-700 text-xs font-bold mb-2">
            <ClipboardList className="w-3.5 h-3.5" />
            <span>Sistem Tiket Kerusakan Mesin & Fasilitas</span>
          </div>
          <h1 className="text-2xl font-extrabold text-slate-900 tracking-tight">
            Manajemen Work Order (WO)
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Formulir laporan gangguan, penugasan teknisi supervisor, dan pencatatan histori perbaikan.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          {/* Export to Excel */}
          <button
            onClick={() => exportWorkOrdersToExcel(filteredWOs)}
            className="flex items-center gap-1.5 px-3 py-2 border border-slate-200 hover:bg-slate-50 text-slate-700 rounded-xl text-xs font-bold transition-all shadow-xs cursor-pointer"
            title="Unduh format spreadsheet Microsoft Excel (.xlsx)"
          >
            <FileSpreadsheet className="w-4 h-4 text-emerald-600" />
            <span>Ekspor Excel (.xlsx)</span>
          </button>

          {/* Export to PDF / Print */}
          <button
            onClick={() => setShowReportModal(true)}
            className="flex items-center gap-1.5 px-3 py-2 border border-slate-200 hover:bg-slate-50 text-slate-700 rounded-xl text-xs font-bold transition-all shadow-xs cursor-pointer"
            title="Cetak atau simpan dokumen PDF resmi"
          >
            <Printer className="w-4 h-4 text-blue-600" />
            <span>Laporan PDF / Cetak</span>
          </button>

          {/* View toggle */}
          <div className="flex items-center bg-slate-100 p-1 rounded-xl text-xs font-semibold text-slate-600">
            <button
              onClick={() => setViewMode('kanban')}
              className={`px-3 py-1.5 rounded-lg transition-colors cursor-pointer ${
                viewMode === 'kanban'
                  ? 'bg-white text-emerald-800 shadow-xs font-bold'
                  : 'hover:text-slate-900'
              }`}
            >
              Kanban Board
            </button>
            <button
              onClick={() => setViewMode('table')}
              className={`px-3 py-1.5 rounded-lg transition-colors cursor-pointer ${
                viewMode === 'table'
                  ? 'bg-white text-emerald-800 shadow-xs font-bold'
                  : 'hover:text-slate-900'
              }`}
            >
              Tabel Daftar
            </button>
          </div>

          <button
            onClick={onOpenNewTicketModal}
            className="flex items-center gap-2 px-4 py-2 bg-emerald-600 hover:bg-emerald-700 active:scale-95 text-white rounded-xl text-xs sm:text-sm font-bold shadow-md shadow-emerald-600/30 transition-all cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>Buat Tiket Baru</span>
          </button>
        </div>
      </div>

      {/* Scope Selector: My Assigned Tasks vs All Work Orders */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white p-3 rounded-2xl border border-emerald-100 shadow-xs">
        <div className="flex items-center gap-2">
          <button
            onClick={() => setActiveTaskScope('my-tasks')}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              activeTaskScope === 'my-tasks'
                ? 'bg-emerald-600 text-white shadow-sm'
                : 'text-slate-600 hover:bg-emerald-50 hover:text-emerald-800'
            }`}
          >
            <UserCheck className="w-4 h-4" />
            <span>Tugas Saya (My Assigned Tasks)</span>
            {myActiveTasksCount > 0 && (
              <span className="px-2 py-0.5 rounded-full text-[10px] font-black bg-white text-emerald-800 shadow-2xs">
                {myActiveTasksCount} Aktif
              </span>
            )}
          </button>

          <button
            onClick={() => setActiveTaskScope('all')}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              activeTaskScope === 'all'
                ? 'bg-emerald-600 text-white shadow-sm'
                : 'text-slate-600 hover:bg-emerald-50 hover:text-emerald-800'
            }`}
          >
            <ClipboardList className="w-4 h-4" />
            <span>Semua Tiket Pabrik ({workOrders.length})</span>
          </button>
        </div>

        {activeTaskScope === 'my-tasks' ? (
          <div className="flex items-center gap-2 text-xs text-slate-600 font-medium">
            <span>Teknisi PIC:</span>
            <strong className="text-emerald-800 font-bold">{currentUser?.name}</strong>
            <span className="text-[10px] px-2 py-0.5 rounded-md bg-emerald-100 text-emerald-800 font-bold">
              {myInProgressCount} Sedang Dikerjakan
            </span>
          </div>
        ) : (
          <span className="text-xs text-slate-400 font-medium">
            Total {workOrders.length} Tiket Seluruh Departemen
          </span>
        )}
      </div>

      {/* Helpful banner when in My Tasks view */}
      {activeTaskScope === 'my-tasks' && (
        <div className="p-4 rounded-2xl bg-gradient-to-r from-emerald-50 via-teal-50/60 to-emerald-50 border border-emerald-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-emerald-600 text-white flex items-center justify-center font-bold shrink-0 shadow-xs">
              <Sparkles className="w-4 h-4" />
            </div>
            <div>
              <div className="font-extrabold text-emerald-950 text-sm">
                Mode Tugas Teknisi: {currentUser?.name}
              </div>
              <p className="text-emerald-800/80 text-xs mt-0.5 leading-relaxed">
                Menampilkan tiket yang ditugaskan khusus kepada Anda. Klik tombol hijau <strong>"Selesaikan Tugas (In Progress ➔ Closed)"</strong> pada kartu tiket untuk segera menutup tiket setelah mesin selesai diperbaiki dan siap beroperasi normal kembali.
              </p>
            </div>
          </div>
          {myInProgressCount > 0 && (
            <span className="px-3 py-1.5 rounded-xl bg-amber-500 text-white font-extrabold text-xs shadow-xs shrink-0 self-start sm:self-center">
              {myInProgressCount} Perlu Dituntaskan
            </span>
          )}
        </div>
      )}

      {/* Filter and search row */}
      <div className="bg-white p-4 rounded-2xl border border-emerald-100 shadow-xs grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
        <div className="relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
          <input
            type="text"
            placeholder="Cari WO, No. Mesin, Pelapor..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-4 py-2 rounded-xl border border-slate-200 text-xs focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
          />
        </div>

        <div>
          <select
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value)}
            className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs text-slate-700 focus:ring-2 focus:ring-emerald-500"
          >
            <option value="all">Semua Status Pengerjaan</option>
            <option value="Open">Open (Baru Dilaporkan)</option>
            <option value="In Progress">In Progress (Sedang Dikerjakan)</option>
            <option value="Pending">Pending (Tunggu Spare Part / Downtime)</option>
            <option value="Closed">Closed (Selesai & Normal)</option>
          </select>
        </div>

        <div>
          <select
            value={filterUrgency}
            onChange={(e) => setFilterUrgency(e.target.value)}
            className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs text-slate-700 focus:ring-2 focus:ring-emerald-500"
          >
            <option value="all">Semua Tingkat Urgensi</option>
            <option value="Emergency">Darurat (Emergency)</option>
            <option value="High">Tinggi (High)</option>
            <option value="Medium">Sedang (Medium)</option>
            <option value="Low">Rendah (Low)</option>
          </select>
        </div>

        <div>
          <select
            value={filterCategory}
            onChange={(e) => setFilterCategory(e.target.value)}
            className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs text-slate-700 focus:ring-2 focus:ring-emerald-500"
          >
            <option value="all">Semua Kategori Kerusakan</option>
            <option value="Heater">Heater / Pemanas</option>
            <option value="Kelistrikan">Kelistrikan / Panel</option>
            <option value="Hidrolik">Hidrolik / Tekanan</option>
            <option value="Mekanikal">Mekanikal / Toggle</option>
            <option value="Pendingin/Chiller">Pendingin / Chiller</option>
            <option value="Fasilitas">Fasilitas / Gedung</option>
          </select>
        </div>
      </div>

      {/* Main Kanban Board Mode */}
      {viewMode === 'kanban' ? (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-4">
          {kanbanColumns.map((colStatus) => {
            const colWOs = filteredWOs.filter((w) => w.status === colStatus);
            return (
              <div
                key={colStatus}
                className="bg-slate-50/80 rounded-2xl p-4 border border-slate-200 flex flex-col min-h-[500px]"
              >
                <div className="flex items-center justify-between pb-3 mb-3 border-b border-slate-200">
                  <div className="flex items-center gap-2">
                    <span
                      className={`w-2.5 h-2.5 rounded-full ${
                        colStatus === 'Open'
                          ? 'bg-slate-500'
                          : colStatus === 'In Progress'
                          ? 'bg-amber-500'
                          : colStatus === 'Pending'
                          ? 'bg-purple-500'
                          : 'bg-emerald-600'
                      }`}
                    ></span>
                    <h3 className="font-extrabold text-xs uppercase tracking-wider text-slate-800">
                      {colStatus}
                    </h3>
                  </div>
                  <span className="w-6 h-6 rounded-full bg-white border border-slate-200 text-xs font-bold text-slate-700 flex items-center justify-center">
                    {colWOs.length}
                  </span>
                </div>

                <div className="space-y-3 flex-1 overflow-y-auto pr-1">
                  {colWOs.length === 0 ? (
                    <div className="h-32 flex items-center justify-center border-2 border-dashed border-slate-200 rounded-xl text-slate-400 text-xs text-center p-4">
                      Tidak ada tiket status {colStatus}
                    </div>
                  ) : (
                    colWOs.map((wo) => (
                      <div
                        key={wo.id}
                        onClick={() => openDetails(wo)}
                        className="bg-white rounded-2xl p-4 border border-slate-200 shadow-2xs hover:shadow-md hover:border-emerald-300 transition-all cursor-pointer group relative"
                      >
                        <div className="flex items-start justify-between gap-2 mb-2">
                          <span className="text-[11px] font-mono font-bold text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded-md">
                            {wo.ticketNumber}
                          </span>
                          <span
                            className={`text-[10px] px-2 py-0.5 rounded-full ${getUrgencyBadge(
                              wo.urgency
                            )}`}
                          >
                            {wo.urgency}
                          </span>
                        </div>

                        <h4 className="text-xs font-bold text-slate-900 group-hover:text-emerald-700 transition-colors line-clamp-2 leading-snug">
                          {wo.title}
                        </h4>

                        <div className="mt-2.5 text-[11px] text-slate-600 space-y-1">
                          <div className="font-medium text-slate-800 flex items-center gap-1.5">
                            <Wrench className="w-3 h-3 text-slate-400" />
                            <span>{wo.machineName}</span>
                          </div>
                          <div className="text-slate-500 flex items-center gap-1.5">
                            <Building className="w-3 h-3 text-slate-400" />
                            <span>Pelapor: {wo.reporterName}</span>
                          </div>
                        </div>

                        {/* Used parts badge if any */}
                        {wo.usedParts.length > 0 && (
                          <div className="mt-2 pt-2 border-t border-slate-100 flex items-center gap-1 text-[10px] text-emerald-700 font-semibold">
                            <Package className="w-3 h-3" />
                            <span>{wo.usedParts.length} Suku Cadang Terpakai</span>
                          </div>
                        )}

                        <div className="mt-3 pt-2.5 border-t border-slate-100 flex items-center justify-between text-[11px]">
                          <div className="flex items-center gap-1.5 text-slate-700 font-medium">
                            <User className="w-3 h-3 text-emerald-600" />
                            <span className="truncate max-w-[110px]">
                              {wo.assignedTechnician || 'Belum ditugaskan'}
                            </span>
                          </div>

                          {isAdmin && (
                            <button
                              onClick={(e) => handleDelete(wo.id, e)}
                              className="text-slate-300 hover:text-red-600 p-1 transition-colors"
                              title="Hapus Tiket (Admin Only)"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          )}
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        /* Table View */
        <div className="bg-white rounded-3xl border border-emerald-100 shadow-xs overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 border-b border-slate-200 text-slate-500 uppercase tracking-wider font-extrabold text-[10px]">
                <tr>
                  <th className="py-3.5 px-4">No. Tiket</th>
                  <th className="py-3.5 px-4">Mesin / Lokasi</th>
                  <th className="py-3.5 px-4">Gejala Kerusakan</th>
                  <th className="py-3.5 px-4">Urgensi</th>
                  <th className="py-3.5 px-4">Teknisi Bertugas</th>
                  <th className="py-3.5 px-4">Status</th>
                  <th className="py-3.5 px-4">Tanggal Lapor</th>
                  <th className="py-3.5 px-4 text-center">Aksi</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredWOs.map((wo) => (
                  <tr
                    key={wo.id}
                    onClick={() => openDetails(wo)}
                    className="hover:bg-emerald-50/40 transition-colors cursor-pointer"
                  >
                    <td className="py-3 px-4 font-mono font-bold text-emerald-800">
                      {wo.ticketNumber}
                    </td>
                    <td className="py-3 px-4 font-semibold text-slate-900">
                      {wo.machineName}
                    </td>
                    <td className="py-3 px-4 max-w-xs truncate text-slate-700">
                      {wo.title}
                    </td>
                    <td className="py-3 px-4">
                      <span
                        className={`text-[10px] px-2 py-0.5 rounded-full ${getUrgencyBadge(
                          wo.urgency
                        )}`}
                      >
                        {wo.urgency}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-slate-700">
                      {wo.assignedTechnician || '-'}
                    </td>
                    <td className="py-3 px-4">
                      <span
                        className={`text-[10px] px-2 py-0.5 rounded-full border font-bold ${getStatusBadge(
                          wo.status
                        )}`}
                      >
                        {wo.status}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-slate-500">{wo.createdDate}</td>
                    <td className="py-3 px-4 text-center">
                      <div className="flex items-center justify-center gap-1.5">
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            openDetails(wo);
                          }}
                          className="p-1 rounded-md text-emerald-700 hover:bg-emerald-100"
                        >
                          <Eye className="w-4 h-4" />
                        </button>
                        {isAdmin && (
                          <button
                            onClick={(e) => handleDelete(wo.id, e)}
                            className="p-1 rounded-md text-slate-400 hover:text-red-600 hover:bg-red-50"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* DETAIL / ACTION MODAL */}
      {selectedWO && (
        <div className="fixed inset-0 bg-slate-900/60 z-50 flex items-center justify-center p-4 backdrop-blur-xs">
          <div className="bg-white rounded-3xl max-w-3xl w-full max-h-[90vh] overflow-y-auto shadow-2xl border border-slate-200">
            {/* Modal Header */}
            <div className="p-6 bg-emerald-800 text-white rounded-t-3xl flex items-start justify-between">
              <div>
                <div className="flex items-center gap-2 mb-1">
                  <span className="font-mono bg-white/20 text-white px-2 py-0.5 rounded-md text-xs font-bold">
                    {selectedWO.ticketNumber}
                  </span>
                  <span
                    className={`text-[10px] px-2.5 py-0.5 rounded-full ${getUrgencyBadge(
                      selectedWO.urgency
                    )}`}
                  >
                    {selectedWO.urgency}
                  </span>
                  <span className="text-emerald-200 text-xs font-semibold">
                    Kategori: {selectedWO.category}
                  </span>
                </div>
                <h3 className="text-xl font-extrabold text-white mt-2">
                  {selectedWO.title}
                </h3>
                <p className="text-emerald-100 text-xs mt-1">
                  Unit: {selectedWO.machineName} | Dilaporkan oleh: {selectedWO.reporterName} ({selectedWO.department})
                </p>
              </div>
              <button
                onClick={() => setSelectedWO(null)}
                className="text-emerald-200 hover:text-white p-1 rounded-lg text-lg font-bold"
              >
                ✕
              </button>
            </div>

            <div className="p-6 space-y-6 text-xs sm:text-sm">
              {/* Description */}
              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200">
                <span className="font-bold text-slate-800 text-xs block mb-1">
                  Detail Gejala / Masalah Kerusakan:
                </span>
                <p className="text-slate-700 leading-relaxed text-xs">
                  {selectedWO.description}
                </p>
              </div>

              {/* Status & Technician Assignment */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1.5">
                    Penugasan Teknisi Bertugas {isAdmin ? '(Supervisor)' : ''}:
                  </label>
                  {isAdmin ? (
                    <select
                      value={editTechnician}
                      onChange={(e) => setEditTechnician(e.target.value)}
                      className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-xs focus:ring-2 focus:ring-emerald-500 font-medium"
                    >
                      <option value="">-- Pilih Teknisi R&M --</option>
                      <option value="Agus Wijaya">Agus Wijaya (Senior Listrik & Hidrolik)</option>
                      <option value="Hendra Pratama">Hendra Pratama (Spesialis Heater & Mekanik)</option>
                      <option value="Dwi Kurniawan">Dwi Kurniawan (Teknisi Fasilitas & Sensor)</option>
                      <option value="Budi Santoso">Budi Santoso (Supervisor Maintenance)</option>
                    </select>
                  ) : (
                    <div className="px-3.5 py-2.5 bg-slate-100 rounded-xl text-slate-700 text-xs font-semibold">
                      {editTechnician || 'Belum ditunjuk supervisor'}
                    </div>
                  )}
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1.5">
                    Status Pengerjaan Tiket:
                  </label>
                  <select
                    value={editStatus}
                    onChange={(e) => setEditStatus(e.target.value as WorkOrderStatus)}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-xs focus:ring-2 focus:ring-emerald-500 font-medium"
                  >
                    <option value="Open">Open (Baru Dilaporkan)</option>
                    <option value="In Progress">In Progress (Sedang Dikerjakan)</option>
                    <option value="Pending">Pending (Menunggu Suku Cadang)</option>
                    <option value="Closed">Closed (Selesai & Normal Kembali)</option>
                  </select>
                </div>
              </div>

              {/* Troubleshooting action taken notes */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1.5">
                  Tindakan Penanganan / Log Troubleshooting Teknisi:
                </label>
                <textarea
                  rows={3}
                  value={editActionsTaken}
                  onChange={(e) => setEditActionsTaken(e.target.value)}
                  placeholder="Catat langkah investigasi kerusakan, komponen yang diganti, serta hasil pengujian mesin..."
                  className="w-full p-3 rounded-xl border border-slate-300 text-xs focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              {/* Spare Parts Usage Section (Real Integration with Inventory!) */}
              <div className="p-4 rounded-2xl bg-emerald-50/50 border border-emerald-200">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2">
                    <Package className="w-4 h-4 text-emerald-700" />
                    <span className="font-extrabold text-xs uppercase tracking-wider text-emerald-900">
                      Pengambilan Suku Cadang (Otomatis Kurang Stok)
                    </span>
                  </div>
                  <span className="text-[11px] text-slate-500">
                    Terhubung ke Kartu Stok Gudang
                  </span>
                </div>

                {partError && (
                  <div className="mb-3 p-2 bg-red-100 text-red-700 text-xs rounded-lg font-medium">
                    {partError}
                  </div>
                )}

                {/* Add part form */}
                <div className="flex flex-col sm:flex-row gap-2">
                  <select
                    value={selectedPartId}
                    onChange={(e) => {
                      setSelectedPartId(e.target.value);
                      setPartError(null);
                    }}
                    className="flex-1 px-3 py-2 bg-white rounded-xl border border-slate-300 text-xs focus:ring-2 focus:ring-emerald-500"
                  >
                    <option value="">-- Pilih Suku Cadang Dari Stok --</option>
                    <optgroup label="Suku Cadang Heater Band">
                      {spareParts
                        .filter((p) => p.category === 'Heater')
                        .map((p) => (
                          <option key={p.id} value={p.id}>
                            Heater {p.name} (Stok: {p.currentStock} {p.unit})
                          </option>
                        ))}
                    </optgroup>
                    <optgroup label="Suku Cadang Elektrikal">
                      {spareParts
                        .filter((p) => p.category === 'Electrical')
                        .map((p) => (
                          <option key={p.id} value={p.id}>
                            {p.name} (Stok: {p.currentStock} {p.unit})
                          </option>
                        ))}
                    </optgroup>
                    <optgroup label="Suku Cadang Mekanikal & Pelumas">
                      {spareParts
                        .filter((p) => p.category === 'Mechanical')
                        .map((p) => (
                          <option key={p.id} value={p.id}>
                            {p.name} (Stok: {p.currentStock} {p.unit})
                          </option>
                        ))}
                    </optgroup>
                  </select>

                  <div className="flex items-center gap-2">
                    <input
                      type="number"
                      min={1}
                      max={99}
                      value={partQuantity}
                      onChange={(e) => setPartQuantity(Math.max(1, parseInt(e.target.value) || 1))}
                      className="w-20 px-3 py-2 bg-white rounded-xl border border-slate-300 text-xs text-center font-bold"
                    />
                    <button
                      type="button"
                      onClick={handleAddPartToWO}
                      className="px-4 py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl text-xs font-bold transition-colors cursor-pointer shrink-0"
                    >
                      + Pasang Part
                    </button>
                  </div>
                </div>

                {/* List of parts already used in this ticket */}
                {selectedWO.usedParts.length > 0 && (
                  <div className="mt-3 pt-3 border-t border-emerald-200/60 space-y-1.5">
                    <span className="text-[11px] font-bold text-slate-700 block">
                      Daftar Komponen Terpasang pada Perbaikan Ini:
                    </span>
                    {selectedWO.usedParts.map((item, idx) => (
                      <div
                        key={idx}
                        className="flex items-center justify-between bg-white px-3 py-1.5 rounded-lg border border-slate-200 text-xs"
                      >
                        <span className="font-semibold text-slate-800">
                          {item.partName} ({item.category})
                        </span>
                        <span className="font-bold text-emerald-800 bg-emerald-100 px-2 py-0.5 rounded-md text-[11px]">
                          {item.quantity} Unit Terpakai
                        </span>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Action buttons */}
              <div className="flex items-center justify-between pt-4 border-t border-slate-200">
                <span className="text-xs text-slate-400">
                  Tanggal Lapor: {selectedWO.createdDate}
                </span>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => setSelectedWO(null)}
                    className="px-4 py-2.5 rounded-xl border border-slate-300 text-slate-600 hover:bg-slate-100 font-semibold text-xs cursor-pointer"
                  >
                    Batal
                  </button>
                  <button
                    type="button"
                    onClick={handleSaveDetails}
                    className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl font-bold text-xs shadow-md shadow-emerald-600/30 transition-all cursor-pointer"
                  >
                    Simpan Perubahan Tiket
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
      {/* Formal PDF / Print Modal */}
      <ReportPrintModal
        isOpen={showReportModal}
        onClose={() => setShowReportModal(false)}
        reportType="work-order"
        workOrders={filteredWOs}
      />
    </div>
  );
};
