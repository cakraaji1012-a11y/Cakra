import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { UrgencyLevel, WorkOrderCategory } from '../../types';
import {
  Wrench,
  AlertCircle,
  Building,
  Cpu,
  Layers,
  Sparkles,
  X,
  Send,
} from 'lucide-react';

interface NewTicketModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const NewTicketModal: React.FC<NewTicketModalProps> = ({ isOpen, onClose }) => {
  const { machines, createWorkOrder, currentUser } = useApp();

  const [title, setTitle] = useState('');
  const [machineId, setMachineId] = useState('');
  const [department, setDepartment] = useState('Produksi Injeksi');
  const [reporterName, setReporterName] = useState(currentUser?.name || '');
  const [urgency, setUrgency] = useState<UrgencyLevel>('Medium');
  const [category, setCategory] = useState<WorkOrderCategory>('Heater');
  const [description, setDescription] = useState('');
  const [targetDate, setTargetDate] = useState(() => {
    const d = new Date();
    d.setDate(d.getDate() + 1);
    return d.toISOString().slice(0, 10);
  });
  const [error, setError] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) {
      setError('Judul / ringkasan kerusakan wajib diisi.');
      return;
    }
    if (!machineId) {
      setError('Pilih mesin atau fasilitas yang bermasalah.');
      return;
    }
    if (!description.trim()) {
      setError('Jelaskan detail gejala masalah yang terjadi.');
      return;
    }

    const selectedMachine = machines.find((m) => m.id === machineId);
    if (!selectedMachine) return;

    createWorkOrder({
      title,
      machineId,
      machineName: `${selectedMachine.name} (No. ${selectedMachine.noMc} - ${selectedMachine.tonase})`,
      machineNo: selectedMachine.noMc,
      reporterName: reporterName || 'Staff Operasional',
      department,
      urgency,
      category,
      description,
      status: 'Open',
      targetDate,
      usedParts: [],
    });

    onClose();
  };

  return (
    <div className="fixed inset-0 bg-slate-900/60 z-50 flex items-center justify-center p-4 backdrop-blur-xs">
      <div className="bg-white rounded-3xl max-w-2xl w-full max-h-[92vh] overflow-y-auto shadow-2xl border border-emerald-100 animate-fadeIn">
        {/* Modal Header */}
        <div className="p-6 bg-gradient-to-r from-emerald-800 to-emerald-700 text-white rounded-t-3xl flex items-start justify-between">
          <div>
            <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-white/20 text-emerald-100 text-xs font-semibold mb-2">
              <Wrench className="w-3.5 h-3.5" />
              <span>Formulir Laporan Departemen Lain / Teknisi</span>
            </div>
            <h2 className="text-xl font-extrabold tracking-tight">
              Buat Tiket Perbaikan / Work Order Baru
            </h2>
            <p className="text-emerald-100 text-xs mt-1">
              Laporkan kerusakan mesin injeksi, fasilitas pabrik, kelistrikan, atau pemanas.
            </p>
          </div>
          <button
            onClick={onClose}
            className="text-emerald-200 hover:text-white p-1 rounded-lg text-lg font-bold"
          >
            ✕
          </button>
        </div>

        {/* Modal Form */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4 text-xs sm:text-sm">
          {error && (
            <div className="p-3 bg-red-50 border border-red-200 text-red-700 rounded-xl text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0 text-red-500" />
              <span>{error}</span>
            </div>
          )}

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1.5">
              Judul Kerusakan / Ringkasan Masalah <span className="text-red-500">*</span>
            </label>
            <input
              type="text"
              required
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="Contoh: Heater Nozzle 105x60 Putus / Tekanan Pompa Hidrolik Turun"
              className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-xs focus:ring-2 focus:ring-emerald-500"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5">
                Pilih Mesin Injeksi / Alat <span className="text-red-500">*</span>
              </label>
              <select
                required
                value={machineId}
                onChange={(e) => setMachineId(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-xs focus:ring-2 focus:ring-emerald-500 bg-white"
              >
                <option value="">-- Pilih dari 46 Mesin --</option>
                {machines.map((m) => (
                  <option key={m.id} value={m.id}>
                    No. {m.noMc} - {m.name} ({m.tonase} - {m.mekanisme}) [{m.lokasi}]
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5">
                Kategori Kerusakan:
              </label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value as WorkOrderCategory)}
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-xs focus:ring-2 focus:ring-emerald-500 bg-white"
              >
                <option value="Heater">Heater / Elemen Pemanas</option>
                <option value="Kelistrikan">Kelistrikan / Panel / Sensor</option>
                <option value="Hidrolik">Hidrolik / Tekanan Pompa / Silinder</option>
                <option value="Mekanikal">Mekanikal / Toggle / Tie Bar</option>
                <option value="Pendingin/Chiller">Sistem Pendingin / Chiller</option>
                <option value="Fasilitas">Fasilitas / Kompresor / Gedung</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5">
                Tingkat Urgensi:
              </label>
              <select
                value={urgency}
                onChange={(e) => setUrgency(e.target.value as UrgencyLevel)}
                className="w-full px-3 py-2.5 rounded-xl border border-slate-300 text-xs focus:ring-2 focus:ring-emerald-500 font-bold bg-white"
              >
                <option value="Low">Rendah (Low - Masih Jalan)</option>
                <option value="Medium">Sedang (Medium - Kualitas Turun)</option>
                <option value="High">Tinggi (High - Gangguan Signifikan)</option>
                <option value="Emergency">Darurat (Emergency - Total Breakdown)</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5">
                Departemen Pelapor:
              </label>
              <select
                value={department}
                onChange={(e) => setDepartment(e.target.value)}
                className="w-full px-3 py-2.5 rounded-xl border border-slate-300 text-xs focus:ring-2 focus:ring-emerald-500 bg-white"
              >
                <option value="Produksi Injeksi">Produksi Injeksi</option>
                <option value="Quality Control (QC)">Quality Control (QC)</option>
                <option value="Tooling & Mould">Tooling & Mould</option>
                <option value="Warehouse / Gudang">Warehouse / Gudang</option>
                <option value="Repair & Maintenance">Internal R&M</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5">
                Nama Pelapor:
              </label>
              <input
                type="text"
                value={reporterName}
                onChange={(e) => setReporterName(e.target.value)}
                placeholder="Nama Anda / Operator"
                className="w-full px-3 py-2.5 rounded-xl border border-slate-300 text-xs focus:ring-2 focus:ring-emerald-500"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1.5">
              Deskripsi Masalah / Indikasi Alarm Kerusakan <span className="text-red-500">*</span>
            </label>
            <textarea
              required
              rows={4}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Jelaskan apa yang terjadi, bunyi abnormal, kode alarm di monitor (misal E-14, Overheat), atau kebocoran yang terlihat..."
              className="w-full p-3 rounded-xl border border-slate-300 text-xs focus:ring-2 focus:ring-emerald-500"
            />
          </div>

          <div className="flex items-center justify-between pt-4 border-t border-slate-200">
            <span className="text-[11px] text-slate-500">
              Tiket akan langsung masuk ke antrean Supervisor R&M.
            </span>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2.5 rounded-xl border border-slate-300 text-slate-600 hover:bg-slate-100 font-semibold text-xs cursor-pointer"
              >
                Batal
              </button>
              <button
                type="submit"
                className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl font-bold text-xs shadow-md shadow-emerald-600/30 transition-all flex items-center gap-2 cursor-pointer"
              >
                <Send className="w-3.5 h-3.5" />
                <span>Kirim Tiket Perbaikan</span>
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};
