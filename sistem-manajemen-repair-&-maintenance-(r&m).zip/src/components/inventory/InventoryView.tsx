import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { SparePart, PartCategory } from '../../types';
import { exportInventoryToExcel } from '../../utils/exportUtils';
import { ReportPrintModal } from '../common/ReportPrintModal';
import {
  Boxes,
  Search,
  Plus,
  ArrowDownLeft,
  ArrowUpRight,
  AlertTriangle,
  CheckCircle2,
  Package,
  Layers,
  FileSpreadsheet,
  Printer,
  History,
  TrendingDown,
  Trash2,
  Edit,
  ShieldCheck,
  Zap,
  Flame,
  Wrench,
  Filter,
} from 'lucide-react';

export const InventoryView: React.FC = () => {
  const {
    spareParts,
    stockLogs,
    recordStockMovement,
    addSparePart,
    updateSparePart,
    deleteSparePart,
    isAdmin,
    machines,
    currentUser,
  } = useApp();

  const [activeCategoryTab, setActiveCategoryTab] = useState<'Heater' | 'Electrical' | 'Mechanical' | 'logs'>('Heater');
  const [searchTerm, setSearchTerm] = useState('');
  const [onlyLowStock, setOnlyLowStock] = useState(false);
  const [showReportModal, setShowReportModal] = useState(false);

  // Selected item for banner lookup (just like in the user's images 2 & 3!)
  const [selectedLookupPartId, setSelectedLookupPartId] = useState<string>('');

  // Stock Movement Modal (Input Keluar/Masuk)
  const [showMovementModal, setShowMovementModal] = useState(false);
  const [moveType, setMoveType] = useState<'in' | 'out'>('out');
  const [movePartId, setMovePartId] = useState('');
  const [moveQty, setMoveQty] = useState(1);
  const [moveMachineNo, setMoveMachineNo] = useState<number | undefined>(undefined);
  const [moveNotes, setMoveNotes] = useState('');
  const [moveError, setMoveError] = useState<string | null>(null);

  // New Part Modal (Admin only)
  const [showAddPartModal, setShowAddPartModal] = useState(false);
  const [newName, setNewName] = useState('');
  const [newCategory, setNewCategory] = useState<PartCategory>('Heater');
  const [newStockAwal, setNewStockAwal] = useState(0);
  const [newMinStock, setNewMinStock] = useState(2);
  const [newMaxStock, setNewMaxStock] = useState(5);
  const [newUnit, setNewUnit] = useState('Pcs');
  const [newRack, setNewRack] = useState('Rak A-01');

  // Filter parts for active category tab
  const categoryParts = spareParts.filter((p) => {
    if (activeCategoryTab === 'logs') return true;
    return p.category === activeCategoryTab;
  });

  const filteredParts = categoryParts.filter((p) => {
    const matchSearch = p.name.toLowerCase().includes(searchTerm.toLowerCase());
    const matchLowStock = onlyLowStock ? p.currentStock <= p.minStock : true;
    return matchSearch && matchLowStock;
  });

  // Highlighted part in top Excel-style lookup card
  const activeLookupPart =
    spareParts.find((p) => p.id === selectedLookupPartId) ||
    categoryParts.find((p) => p.currentStock <= p.minStock) ||
    categoryParts[0];

  const shortageQty = activeLookupPart
    ? Math.max(0, activeLookupPart.maxStock - activeLookupPart.currentStock)
    : 0;

  const getRestockStatus = (part: SparePart) => {
    if (part.currentStock === 0) return { label: 'HABIS (RESTOCK)', color: 'bg-red-600 text-white font-extrabold' };
    if (part.currentStock <= part.minStock) return { label: 'MENIPIS (RESTOCK)', color: 'bg-amber-500 text-white font-bold' };
    return { label: 'AMAN', color: 'bg-emerald-600 text-white font-semibold' };
  };

  const handleStockMovement = (e: React.FormEvent) => {
    e.preventDefault();
    if (!movePartId) {
      setMoveError('Pilih suku cadang terlebih dahulu.');
      return;
    }
    const part = spareParts.find((p) => p.id === movePartId);
    if (!part) return;

    if (moveType === 'out' && part.currentStock < moveQty) {
      setMoveError(`Stok tidak mencukupi! Sisa stok ${part.name} hanya ${part.currentStock} ${part.unit}`);
      return;
    }

    const success = recordStockMovement({
      partId: part.id,
      type: moveType,
      quantity: moveQty,
      machineNo: moveMachineNo,
      notes: moveNotes || (moveType === 'in' ? 'Penerimaan stok gudang' : 'Pengambilan untuk perawatan'),
    });

    if (success) {
      setShowMovementModal(false);
      setMovePartId('');
      setMoveQty(1);
      setMoveNotes('');
      setMoveError(null);
    }
  };

  const handleAddPart = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newName.trim()) return;

    addSparePart({
      category: newCategory,
      name: newName,
      stockAwal: newStockAwal,
      currentStock: newStockAwal,
      minStock: newMinStock,
      maxStock: newMaxStock,
      unit: newUnit,
      rackLocation: newRack,
    });

    setShowAddPartModal(false);
    setNewName('');
  };

  // Export to CSV
  const handleExportCSV = () => {
    const headers = ['Kategori', 'Nama Barang / Ukuran', 'Stock Awal', 'Stock Saat Ini', 'Min Stock', 'Max Stock', 'Satuan', 'Lokasi Rak', 'Status'];
    const rows = filteredParts.map((p) => [
      p.category,
      p.name,
      p.stockAwal,
      p.currentStock,
      p.minStock,
      p.maxStock,
      p.unit,
      p.rackLocation,
      p.currentStock <= p.minStock ? 'PERLU RESTOCK' : 'AMAN',
    ]);
    const csvContent =
      'data:text/csv;charset=utf-8,' +
      [headers.join(','), ...rows.map((e) => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `Kartu_Stok_${activeCategoryTab}_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white p-6 rounded-3xl border border-emerald-100 shadow-xs">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-50 text-emerald-700 text-xs font-bold mb-2">
            <Boxes className="w-3.5 h-3.5" />
            <span>Manajemen Inventaris Suku Cadang & Log Mutasi</span>
          </div>
          <h1 className="text-2xl font-extrabold text-slate-900 tracking-tight">
            Kartu Stok & Spare Parts Gudang
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Data digital sesuai Kartu Stock Heater dan Stock Barang Electrical dengan fitur peringatan Auto-Reorder.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          {/* Excel Export */}
          <button
            onClick={() => exportInventoryToExcel(spareParts, stockLogs, activeCategoryTab)}
            className="flex items-center gap-1.5 px-3 py-2 border border-slate-200 hover:bg-slate-50 text-slate-700 rounded-xl text-xs font-bold transition-all shadow-xs cursor-pointer"
            title="Unduh 3 Sheet Buku Stok Microsoft Excel (.xlsx)"
          >
            <FileSpreadsheet className="w-4 h-4 text-emerald-600" />
            <span>Ekspor Excel (.xlsx)</span>
          </button>

          {/* PDF Report / Print */}
          <button
            onClick={() => setShowReportModal(true)}
            className="flex items-center gap-1.5 px-3 py-2 border border-slate-200 hover:bg-slate-50 text-slate-700 rounded-xl text-xs font-bold transition-all shadow-xs cursor-pointer"
            title="Cetak atau simpan dokumen PDF resmi inventaris"
          >
            <Printer className="w-4 h-4 text-blue-600" />
            <span>Laporan PDF / Cetak</span>
          </button>

          {/* Input Mutasi (Both Admin and Staff) */}
          <button
            onClick={() => {
              setMoveType('out');
              setShowMovementModal(true);
            }}
            className="flex items-center gap-1.5 px-3.5 py-2 bg-emerald-600 hover:bg-emerald-700 active:scale-95 text-white rounded-xl text-xs sm:text-sm font-bold shadow-md shadow-emerald-600/30 transition-all cursor-pointer"
          >
            <ArrowDownLeft className="w-4 h-4" />
            <span>Input Suku Cadang</span>
          </button>

          {/* Admin only: Tambah Item Baru */}
          {isAdmin && (
            <button
              onClick={() => setShowAddPartModal(true)}
              className="flex items-center gap-1.5 px-3.5 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs sm:text-sm font-bold transition-all cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>Tambah Master Part</span>
            </button>
          )}
        </div>
      </div>

      {/* Tabs Selection: Heater vs Electrical vs Mechanical vs Logs */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-white p-3 rounded-2xl border border-emerald-100 shadow-xs">
        <div className="flex items-center gap-2">
          <button
            onClick={() => {
              setActiveCategoryTab('Heater');
              setSelectedLookupPartId('');
            }}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              activeCategoryTab === 'Heater'
                ? 'bg-emerald-600 text-white shadow-sm'
                : 'text-slate-600 hover:bg-emerald-50 hover:text-emerald-800'
            }`}
          >
            <Flame className="w-4 h-4" />
            <span>Kartu Stock Heater (47 Ukuran)</span>
          </button>

          <button
            onClick={() => {
              setActiveCategoryTab('Electrical');
              setSelectedLookupPartId('');
            }}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              activeCategoryTab === 'Electrical'
                ? 'bg-emerald-600 text-white shadow-sm'
                : 'text-slate-600 hover:bg-emerald-50 hover:text-emerald-800'
            }`}
          >
            <Zap className="w-4 h-4" />
            <span>Stock Barang Electrical (43 Item)</span>
          </button>

          <button
            onClick={() => {
              setActiveCategoryTab('Mechanical');
              setSelectedLookupPartId('');
            }}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              activeCategoryTab === 'Mechanical'
                ? 'bg-emerald-600 text-white shadow-sm'
                : 'text-slate-600 hover:bg-emerald-50 hover:text-emerald-800'
            }`}
          >
            <Wrench className="w-4 h-4" />
            <span>Mekanikal & Pelumas</span>
          </button>

          <button
            onClick={() => setActiveCategoryTab('logs')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              activeCategoryTab === 'logs'
                ? 'bg-slate-900 text-white shadow-sm'
                : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            <History className="w-4 h-4" />
            <span>Log Keluar-Masuk ({stockLogs.length})</span>
          </button>
        </div>

        {/* Auto-reorder filter checkbox */}
        {activeCategoryTab !== 'logs' && (
          <label className="flex items-center gap-2 text-xs font-bold text-red-600 cursor-pointer bg-red-50 px-3 py-1.5 rounded-xl border border-red-200">
            <input
              type="checkbox"
              checked={onlyLowStock}
              onChange={(e) => setOnlyLowStock(e.target.checked)}
              className="rounded-sm text-red-600 focus:ring-red-500 w-3.5 h-3.5"
            />
            <span>Filter Auto-Reorder (Stok Menipis / Habis)</span>
          </label>
        )}
      </div>

      {activeCategoryTab !== 'logs' ? (
        <>
          {/* EXCEL SHEET HEADER BANNER (Exactly replicating the user's uploaded images header!) */}
          {activeLookupPart && (
            <div className="bg-gradient-to-r from-slate-900 via-emerald-950 to-slate-900 rounded-3xl p-5 text-white shadow-md border border-emerald-900/60 overflow-hidden">
              <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-2xl bg-emerald-600 text-white flex items-center justify-center font-black shadow-lg shadow-emerald-950/40">
                    {activeLookupPart.category === 'Heater' ? (
                      <Flame className="w-6 h-6" />
                    ) : (
                      <Zap className="w-6 h-6" />
                    )}
                  </div>
                  <div>
                    <span className="text-[10px] uppercase font-bold tracking-widest text-emerald-300 block">
                      Periode: September 2026 | Indikator Kartu Stok
                    </span>
                    <h2 className="text-xl font-extrabold text-white">
                      {activeCategoryTab === 'Heater' ? 'Kartu Stock Heater' : 'Stock Barang Electrical'}
                    </h2>
                  </div>
                </div>

                {/* Live Lookup Data Bar (Direct homage to Excel formula banner) */}
                <div className="grid grid-cols-2 sm:grid-cols-5 gap-2 text-center text-xs">
                  <div className="p-2.5 rounded-xl bg-white/10 backdrop-blur-sm border border-white/10">
                    <span className="text-[10px] text-emerald-200 block uppercase font-bold">
                      {activeCategoryTab === 'Heater' ? 'Ukuran Heater' : 'Nama Barang'}
                    </span>
                    <span className="text-sm font-extrabold text-white mt-0.5 truncate block">
                      {activeLookupPart.name}
                    </span>
                  </div>

                  <div className="p-2.5 rounded-xl bg-white/10 backdrop-blur-sm border border-white/10">
                    <span className="text-[10px] text-emerald-200 block uppercase font-bold">
                      Total Stock
                    </span>
                    <span className="text-sm font-extrabold text-white mt-0.5 block">
                      {activeLookupPart.currentStock} {activeLookupPart.unit}
                    </span>
                  </div>

                  <div className="p-2.5 rounded-xl bg-white/10 backdrop-blur-sm border border-white/10">
                    <span className="text-[10px] text-emerald-200 block uppercase font-bold">
                      Kekurangan
                    </span>
                    <span className="text-sm font-extrabold text-amber-300 mt-0.5 block">
                      {shortageQty} {activeLookupPart.unit}
                    </span>
                  </div>

                  <div className="p-2.5 rounded-xl bg-white/10 backdrop-blur-sm border border-white/10">
                    <span className="text-[10px] text-emerald-200 block uppercase font-bold">
                      Keterangan
                    </span>
                    <span
                      className={`text-xs px-2 py-0.5 rounded-md inline-block mt-1 ${
                        getRestockStatus(activeLookupPart).color
                      }`}
                    >
                      {activeLookupPart.currentStock <= activeLookupPart.minStock ? 'Restock' : 'Aman'}
                    </span>
                  </div>

                  <div className="p-2.5 rounded-xl bg-white/10 backdrop-blur-sm border border-white/10 col-span-2 sm:col-span-1 flex items-center justify-around">
                    <div>
                      <span className="text-[9px] text-emerald-300 block uppercase font-bold">
                        MAX
                      </span>
                      <span className="text-xs font-bold text-white">
                        {activeLookupPart.maxStock}
                      </span>
                    </div>
                    <div className="h-6 w-px bg-white/20"></div>
                    <div>
                      <span className="text-[9px] text-red-300 block uppercase font-bold">
                        MIN
                      </span>
                      <span className="text-xs font-bold text-red-300">
                        {activeLookupPart.minStock}
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Search bar inside category */}
          <div className="flex items-center justify-between gap-3 bg-white p-3 rounded-2xl border border-emerald-100 shadow-xs">
            <div className="relative flex-1 max-w-md">
              <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder={`Cari nama komponen / dimensi ukuran (misal: 105 X 60, Kontaktor 220 V)...`}
                className="w-full pl-9 pr-4 py-2 rounded-xl border border-slate-200 text-xs focus:ring-2 focus:ring-emerald-500"
              />
            </div>
            <div className="text-xs text-slate-500 font-semibold">
              Menampilkan {filteredParts.length} dari {categoryParts.length} item
            </div>
          </div>

          {/* Stock Table */}
          <div className="bg-white rounded-3xl border border-emerald-100 shadow-xs overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 border-b border-slate-200 text-slate-500 uppercase tracking-wider font-extrabold text-[10px]">
                  <tr>
                    <th className="py-3.5 px-4">
                      {activeCategoryTab === 'Heater' ? 'Ukuran Heater' : 'Nama Barang'}
                    </th>
                    <th className="py-3.5 px-4 text-center">Stock Awal</th>
                    <th className="py-3.5 px-4 text-center">Min Stock</th>
                    <th className="py-3.5 px-4 text-center">Max Stock</th>
                    <th className="py-3.5 px-4 text-center">Stock Akhir</th>
                    <th className="py-3.5 px-4 text-center">Kekurangan</th>
                    <th className="py-3.5 px-4 text-center">Status Restock</th>
                    <th className="py-3.5 px-4 text-center">Lokasi Rak</th>
                    <th className="py-3.5 px-4 text-center">Aksi Cepat</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {filteredParts.map((part) => {
                    const isSelected = activeLookupPart?.id === part.id;
                    const isLow = part.currentStock <= part.minStock;
                    const diff = Math.max(0, part.maxStock - part.currentStock);

                    return (
                      <tr
                        key={part.id}
                        onClick={() => setSelectedLookupPartId(part.id)}
                        className={`hover:bg-emerald-50/50 transition-colors cursor-pointer ${
                          isSelected ? 'bg-emerald-50/80 font-bold' : ''
                        } ${isLow ? 'bg-red-50/20' : ''}`}
                      >
                        <td className="py-3 px-4">
                          <div className="flex items-center gap-2">
                            <span className="font-extrabold text-slate-900">
                              {part.name}
                            </span>
                            {isSelected && (
                              <span className="w-2 h-2 rounded-full bg-emerald-600"></span>
                            )}
                          </div>
                        </td>
                        <td className="py-3 px-4 text-center text-slate-500 font-mono">
                          {part.stockAwal}
                        </td>
                        <td className="py-3 px-4 text-center text-red-600 font-bold font-mono">
                          {part.minStock}
                        </td>
                        <td className="py-3 px-4 text-center text-emerald-700 font-bold font-mono">
                          {part.maxStock}
                        </td>
                        <td className="py-3 px-4 text-center">
                          <span
                            className={`inline-block px-3 py-1 rounded-xl font-black font-mono text-xs ${
                              part.currentStock === 0
                                ? 'bg-red-600 text-white'
                                : part.currentStock <= part.minStock
                                ? 'bg-amber-500 text-white'
                                : 'bg-emerald-100 text-emerald-800'
                            }`}
                          >
                            {part.currentStock} {part.unit}
                          </span>
                        </td>
                        <td className="py-3 px-4 text-center font-mono">
                          {diff > 0 ? (
                            <span className="text-red-600 font-bold">-{diff}</span>
                          ) : (
                            <span className="text-slate-400">0</span>
                          )}
                        </td>
                        <td className="py-3 px-4 text-center">
                          <span
                            className={`text-[10px] px-2.5 py-0.5 rounded-full ${
                              getRestockStatus(part).color
                            }`}
                          >
                            {isLow ? 'RESTOCK' : 'AMAN'}
                          </span>
                        </td>
                        <td className="py-3 px-4 text-center text-slate-500">
                          {part.rackLocation}
                        </td>
                        <td className="py-3 px-4 text-center">
                          <div className="flex items-center justify-center gap-1.5">
                            {/* Quick use button */}
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                setMovePartId(part.id);
                                setMoveType('out');
                                setShowMovementModal(true);
                              }}
                              className="px-2 py-1 rounded-lg bg-emerald-50 text-emerald-700 hover:bg-emerald-100 font-bold text-[11px]"
                              title="Ambil Suku Cadang"
                            >
                              - Ambil
                            </button>
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                setMovePartId(part.id);
                                setMoveType('in');
                                setShowMovementModal(true);
                              }}
                              className="px-2 py-1 rounded-lg bg-blue-50 text-blue-700 hover:bg-blue-100 font-bold text-[11px]"
                              title="Restock Tambah"
                            >
                              + Masuk
                            </button>
                            {isAdmin && (
                              <button
                                onClick={(e) => {
                                  e.stopPropagation();
                                  if (confirm(`Hapus ${part.name} dari sistem?`)) {
                                    deleteSparePart(part.id);
                                  }
                                }}
                                className="p-1 rounded-lg text-slate-300 hover:text-red-600 hover:bg-red-50"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            )}
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </>
      ) : (
        /* Log Keluar-Masuk Table */
        <div className="bg-white rounded-3xl border border-emerald-100 shadow-xs overflow-hidden">
          <div className="p-4 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <History className="w-4 h-4 text-slate-600" />
              <h3 className="font-extrabold text-xs uppercase tracking-wider text-slate-800">
                Pencatatan Log Transaksi Keluar - Masuk Suku Cadang
              </h3>
            </div>
            <span className="text-xs text-slate-500 font-semibold">
              Total {stockLogs.length} Riwayat Transaksi
            </span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-100/60 border-b border-slate-200 text-slate-500 uppercase tracking-wider font-extrabold text-[10px]">
                <tr>
                  <th className="py-3 px-4">Tanggal</th>
                  <th className="py-3 px-4">Tipe Mutasi</th>
                  <th className="py-3 px-4">Nama Suku Cadang</th>
                  <th className="py-3 px-4 text-center">Jumlah</th>
                  <th className="py-3 px-4">No. Mesin / Fasilitas</th>
                  <th className="py-3 px-4">Ref WO / PO</th>
                  <th className="py-3 px-4">Petugas (PIC)</th>
                  <th className="py-3 px-4">Keterangan</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {stockLogs.map((log) => (
                  <tr key={log.id} className="hover:bg-slate-50">
                    <td className="py-3 px-4 font-mono text-slate-600">{log.date}</td>
                    <td className="py-3 px-4">
                      <span
                        className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full font-bold text-[10px] ${
                          log.type === 'in'
                            ? 'bg-emerald-100 text-emerald-800'
                            : 'bg-red-100 text-red-800'
                        }`}
                      >
                        {log.type === 'in' ? (
                          <>
                            <ArrowUpRight className="w-3 h-3 text-emerald-600" />
                            <span>MASUK</span>
                          </>
                        ) : (
                          <>
                            <ArrowDownLeft className="w-3 h-3 text-red-600" />
                            <span>KELUAR</span>
                          </>
                        )}
                      </span>
                    </td>
                    <td className="py-3 px-4 font-extrabold text-slate-900">
                      {log.partName}
                      <span className="text-[10px] text-slate-400 font-normal ml-1">
                        ({log.category})
                      </span>
                    </td>
                    <td className="py-3 px-4 text-center font-mono font-black text-slate-900">
                      {log.type === 'out' ? `-${log.quantity}` : `+${log.quantity}`}
                    </td>
                    <td className="py-3 px-4 text-slate-700">
                      {log.machineNo ? `Mesin No. ${log.machineNo}` : '-'}
                    </td>
                    <td className="py-3 px-4 font-mono font-bold text-emerald-800">
                      {log.referenceWO || '-'}
                    </td>
                    <td className="py-3 px-4 text-slate-700 font-medium">{log.pic}</td>
                    <td className="py-3 px-4 text-slate-600 max-w-xs truncate">
                      {log.notes}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* MODAL INPUT MUTASI KELUAR / MASUK */}
      {showMovementModal && (
        <div className="fixed inset-0 bg-slate-900/60 z-50 flex items-center justify-center p-4 backdrop-blur-xs">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 shadow-2xl border border-slate-200 animate-fadeIn">
            <div className="flex items-center justify-between mb-4 pb-3 border-b border-slate-100">
              <h3 className="text-lg font-bold text-slate-900">
                Catat Mutasi Suku Cadang Gudang
              </h3>
              <button
                onClick={() => setShowMovementModal(false)}
                className="text-slate-400 hover:text-slate-600 font-bold"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleStockMovement} className="space-y-4 text-xs">
              {moveError && (
                <div className="p-3 bg-red-50 text-red-700 rounded-xl text-xs flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4 shrink-0 text-red-500" />
                  <span>{moveError}</span>
                </div>
              )}

              {/* In / Out Switch */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1.5">
                  Tipe Transaksi:
                </label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setMoveType('out')}
                    className={`py-2 rounded-xl font-bold transition-all cursor-pointer ${
                      moveType === 'out'
                        ? 'bg-red-600 text-white shadow-sm'
                        : 'bg-slate-100 text-slate-700'
                    }`}
                  >
                    Pengeluaran / Pakai Mesin (OUT)
                  </button>
                  <button
                    type="button"
                    onClick={() => setMoveType('in')}
                    className={`py-2 rounded-xl font-bold transition-all cursor-pointer ${
                      moveType === 'in'
                        ? 'bg-emerald-600 text-white shadow-sm'
                        : 'bg-slate-100 text-slate-700'
                    }`}
                  >
                    Penerimaan Restock (IN)
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Pilih Komponen / Suku Cadang <span className="text-red-500">*</span>
                </label>
                <select
                  required
                  value={movePartId}
                  onChange={(e) => {
                    setMovePartId(e.target.value);
                    setMoveError(null);
                  }}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-xs bg-white"
                >
                  <option value="">-- Pilih Suku Cadang --</option>
                  <optgroup label="Suku Cadang Heater Band">
                    {spareParts
                      .filter((p) => p.category === 'Heater')
                      .map((p) => (
                        <option key={p.id} value={p.id}>
                          Heater {p.name} (Stok: {p.currentStock} {p.unit})
                        </option>
                      ))}
                  </optgroup>
                  <optgroup label="Suku Cadang Elektrikal">
                    {spareParts
                      .filter((p) => p.category === 'Electrical')
                      .map((p) => (
                        <option key={p.id} value={p.id}>
                          {p.name} (Stok: {p.currentStock} {p.unit})
                        </option>
                      ))}
                  </optgroup>
                  <optgroup label="Mekanikal & Pelumas">
                    {spareParts
                      .filter((p) => p.category === 'Mechanical')
                      .map((p) => (
                        <option key={p.id} value={p.id}>
                          {p.name} (Stok: {p.currentStock} {p.unit})
                        </option>
                      ))}
                  </optgroup>
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Jumlah / Quantity:
                  </label>
                  <input
                    type="number"
                    min={1}
                    required
                    value={moveQty}
                    onChange={(e) => setMoveQty(Math.max(1, parseInt(e.target.value) || 1))}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-xs font-bold font-mono"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Untuk Mesin Injeksi No.:
                  </label>
                  <select
                    value={moveMachineNo || ''}
                    onChange={(e) =>
                      setMoveMachineNo(e.target.value ? parseInt(e.target.value) : undefined)
                    }
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-xs bg-white"
                  >
                    <option value="">Fasilitas / Umum</option>
                    {machines.map((m) => (
                      <option key={m.id} value={m.noMc}>
                        No. {m.noMc} - {m.name} ({m.tonase})
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Catatan / Keterangan Keperluan:
                </label>
                <textarea
                  rows={2}
                  value={moveNotes}
                  onChange={(e) => setMoveNotes(e.target.value)}
                  placeholder="Misal: Penggantian heater nozzle putus, atau nomor PO restock..."
                  className="w-full p-2.5 rounded-xl border border-slate-300 text-xs"
                />
              </div>

              <div className="flex items-center justify-between pt-3 border-t border-slate-100">
                <span className="text-[11px] text-slate-400">
                  PIC: {currentUser?.name}
                </span>
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => setShowMovementModal(false)}
                    className="px-4 py-2 border rounded-xl text-slate-600"
                  >
                    Batal
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl shadow-md"
                  >
                    Simpan Mutasi
                  </button>
                </div>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL TAMBAH SPARE PART BARU (ADMIN ONLY) */}
      {showAddPartModal && (
        <div className="fixed inset-0 bg-slate-900/60 z-50 flex items-center justify-center p-4 backdrop-blur-xs">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 shadow-2xl border border-slate-200 animate-fadeIn">
            <div className="flex items-center justify-between mb-4 pb-3 border-b border-slate-100">
              <h3 className="text-lg font-bold text-slate-900">
                Tambah Master Suku Cadang Baru
              </h3>
              <button
                onClick={() => setShowAddPartModal(false)}
                className="text-slate-400 hover:text-slate-600 font-bold"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleAddPart} className="space-y-4 text-xs">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Kategori Suku Cadang:
                </label>
                <select
                  value={newCategory}
                  onChange={(e) => setNewCategory(e.target.value as PartCategory)}
                  className="w-full px-3.5 py-2 rounded-xl border border-slate-300 text-xs bg-white"
                >
                  <option value="Heater">Heater Band</option>
                  <option value="Electrical">Barang Elektrikal & Sensor</option>
                  <option value="Mechanical">Mekanikal, Seal & Pelumas</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Nama Suku Cadang / Ukuran Heater <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={newName}
                  onChange={(e) => setNewName(e.target.value)}
                  placeholder="Contoh: 140 X 80 atau Kontaktor 415V"
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-xs font-bold"
                />
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Stok Awal:
                  </label>
                  <input
                    type="number"
                    min={0}
                    value={newStockAwal}
                    onChange={(e) => setNewStockAwal(parseInt(e.target.value) || 0)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs text-center font-bold"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Batas MIN Stock:
                  </label>
                  <input
                    type="number"
                    min={1}
                    value={newMinStock}
                    onChange={(e) => setNewMinStock(parseInt(e.target.value) || 1)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs text-center font-bold text-red-600"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Batas MAX Stock:
                  </label>
                  <input
                    type="number"
                    min={1}
                    value={newMaxStock}
                    onChange={(e) => setNewMaxStock(parseInt(e.target.value) || 1)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs text-center font-bold text-emerald-700"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Satuan:
                  </label>
                  <input
                    type="text"
                    value={newUnit}
                    onChange={(e) => setNewUnit(e.target.value)}
                    placeholder="Pcs / Set / Meter"
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Lokasi Rak Gudang:
                  </label>
                  <input
                    type="text"
                    value={newRack}
                    onChange={(e) => setNewRack(e.target.value)}
                    placeholder="Contoh: Rak Heater G-5"
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs"
                  />
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowAddPartModal(false)}
                  className="px-4 py-2 border rounded-xl text-slate-600"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl shadow-md"
                >
                  Tambah Part
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
      {/* Formal PDF / Print Modal */}
      <ReportPrintModal
        isOpen={showReportModal}
        onClose={() => setShowReportModal(false)}
        reportType="inventory"
        spareParts={spareParts}
        stockLogs={stockLogs}
        activeCategory={activeCategoryTab}
      />
    </div>
  );
};
