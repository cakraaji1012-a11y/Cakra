import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Wifi,
  WifiOff,
  RefreshCw,
  Clock,
  CheckCircle2,
  AlertCircle,
  Database,
  Layers,
  X,
  Sparkles,
  ToggleLeft,
  ToggleRight,
} from 'lucide-react';

export const OfflineStatusBar: React.FC = () => {
  const {
    isOnline,
    isSimulatedOffline,
    toggleSimulatedOffline,
    offlineQueue,
    syncOfflineQueue,
    isSyncing,
  } = useApp();

  const [showQueueModal, setShowQueueModal] = useState(false);

  const pendingItems = offlineQueue.filter((item) => item.status === 'pending');

  return (
    <>
      {/* Offline Banner when disconnected or simulating offline */}
      {!isOnline && (
        <div className="bg-gradient-to-r from-amber-600 via-amber-700 to-amber-800 text-white px-4 py-2.5 text-xs font-semibold shadow-md flex flex-wrap items-center justify-between gap-3 animate-fadeIn border-b border-amber-500">
          <div className="flex items-center gap-2.5">
            <div className="w-6 h-6 rounded-full bg-white/20 flex items-center justify-center shrink-0">
              <WifiOff className="w-3.5 h-3.5 text-amber-200 animate-pulse" />
            </div>
            <div>
              <span className="font-extrabold tracking-wide">
                {isSimulatedOffline
                  ? 'Mode Simulasi Offline Aktif:'
                  : 'Koneksi Terputus (Mode Offline):'}
              </span>{' '}
              <span className="text-amber-100 font-normal">
                Pembaruan status Work Order & checklist tetap disimpan di penyimpanan lokal (IndexedDB / LocalStorage).
              </span>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {pendingItems.length > 0 && (
              <button
                onClick={() => setShowQueueModal(true)}
                className="px-2.5 py-1 rounded-lg bg-black/20 hover:bg-black/30 text-white text-[11px] font-bold cursor-pointer transition-colors border border-white/20"
              >
                {pendingItems.length} Antrean Tertunda
              </button>
            )}

            <button
              onClick={() => syncOfflineQueue()}
              disabled={isSyncing}
              className="px-3 py-1 rounded-lg bg-white text-amber-900 hover:bg-amber-50 font-extrabold text-[11px] flex items-center gap-1.5 shadow-xs cursor-pointer active:scale-95 transition-all disabled:opacity-60"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isSyncing ? 'animate-spin' : ''}`} />
              <span>{isSyncing ? 'Menyinkronkan...' : 'Sinkronkan'}</span>
            </button>

            <button
              onClick={toggleSimulatedOffline}
              className="px-2.5 py-1 rounded-lg bg-amber-950/40 hover:bg-amber-950/60 text-amber-200 text-[10px] font-bold border border-amber-400/30 cursor-pointer"
              title="Kembalikan ke mode online"
            >
              Kembali Online
            </button>
          </div>
        </div>
      )}

      {/* Floating Offline Queue Modal */}
      {showQueueModal && (
        <div className="fixed inset-0 bg-slate-900/60 z-50 flex items-center justify-center p-4 backdrop-blur-xs animate-fadeIn">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 shadow-2xl border border-slate-200 text-xs max-h-[85vh] flex flex-col">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-2xl bg-amber-500 text-white flex items-center justify-center shadow-xs">
                  <Database className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-extrabold text-slate-900">
                    Antrean Sinkronisasi Offline (Service Worker)
                  </h3>
                  <span className="text-[10px] text-slate-500">
                    Daftar aksi yang disimpan di perangkat saat koneksi internet terputus
                  </span>
                </div>
              </div>
              <button
                onClick={() => setShowQueueModal(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-100"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="my-4 flex-1 overflow-y-auto divide-y divide-slate-100 space-y-2">
              {offlineQueue.length === 0 ? (
                <div className="p-8 text-center text-slate-400">
                  <CheckCircle2 className="w-10 h-10 text-emerald-500 mx-auto mb-2 opacity-70" />
                  <p className="font-bold text-slate-700">Semua data telah tersinkronkan!</p>
                  <p className="text-[11px] text-slate-400 mt-1">
                    Tidak ada transaksi atau pembaruan status yang tertunda.
                  </p>
                </div>
              ) : (
                offlineQueue.map((item) => (
                  <div
                    key={item.id}
                    className="p-3 rounded-2xl bg-slate-50 border border-slate-200/80 flex items-start justify-between gap-3"
                  >
                    <div>
                      <div className="flex items-center gap-2">
                        <span
                          className={`text-[9px] font-black uppercase px-2 py-0.5 rounded-full ${
                            item.status === 'synced'
                              ? 'bg-emerald-100 text-emerald-800'
                              : 'bg-amber-100 text-amber-800'
                          }`}
                        >
                          {item.status === 'synced' ? 'Tersinkron' : 'Menunggu Sync'}
                        </span>
                        <span className="text-[10px] text-slate-400 font-mono">
                          {item.timestamp}
                        </span>
                      </div>
                      <div className="font-extrabold text-slate-800 text-xs mt-1">
                        {item.title}
                      </div>
                      <div className="text-[10px] text-slate-500 font-mono mt-0.5">
                        Tipe Aksi: {item.action}
                      </div>
                    </div>

                    <div className="shrink-0 mt-1">
                      {item.status === 'synced' ? (
                        <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                      ) : (
                        <Clock className="w-4 h-4 text-amber-600 animate-pulse" />
                      )}
                    </div>
                  </div>
                ))
              )}
            </div>

            <div className="pt-3 border-t border-slate-100 flex items-center justify-between">
              <span className="text-[11px] text-slate-500">
                Total {pendingItems.length} antrean pending
              </span>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => setShowQueueModal(false)}
                  className="px-3 py-1.5 border border-slate-200 rounded-xl font-bold text-slate-600 hover:bg-slate-50 cursor-pointer"
                >
                  Tutup
                </button>
                <button
                  onClick={async () => {
                    await syncOfflineQueue();
                  }}
                  disabled={isSyncing || pendingItems.length === 0}
                  className="px-4 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl font-extrabold flex items-center gap-1.5 shadow-sm disabled:opacity-50 cursor-pointer"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${isSyncing ? 'animate-spin' : ''}`} />
                  <span>{isSyncing ? 'Sinkronisasi...' : 'Sinkronkan Sekarang'}</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
