import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Bell,
  LogOut,
  UserCheck,
  ShieldCheck,
  Clock,
  PlusCircle,
  RotateCcw,
  Sparkles,
  ChevronDown,
  X,
  ExternalLink,
  Scan,
  Volume2,
  VolumeX,
  AlertTriangle,
  CalendarCheck2,
  CheckCircle2,
  BellRing,
  Wifi,
  WifiOff,
  RefreshCw,
} from 'lucide-react';

interface NavbarProps {
  onOpenNewTicketModal: () => void;
  onOpenMobileMenu: () => void;
  onOpenQRScanner?: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  onOpenNewTicketModal,
  onOpenMobileMenu,
  onOpenQRScanner,
}) => {
  const {
    currentUser,
    logout,
    loginAs,
    notifications,
    markNotificationAsRead,
    markAllNotificationsAsRead,
    setActiveTab,
    resetToDefaultData,
    webNotificationPermission,
    requestWebNotificationPermission,
    isSoundEnabled,
    setIsSoundEnabled,
    triggerTestUrgentAlert,
    triggerTestPMAlert,
    isOnline,
    isSimulatedOffline,
    toggleSimulatedOffline,
    offlineQueue,
    syncOfflineQueue,
    isSyncing,
  } = useApp();

  const [currentTime, setCurrentTime] = useState('');
  const [showNotifications, setShowNotifications] = useState(false);
  const [showUserMenu, setShowUserMenu] = useState(false);
  const [notifFilter, setNotifFilter] = useState<'all' | 'urgent' | 'pm'>('all');

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setCurrentTime(
        now.toLocaleDateString('id-ID', {
          weekday: 'short',
          day: 'numeric',
          month: 'short',
          year: 'numeric',
          hour: '2-digit',
          minute: '2-digit',
          second: '2-digit',
        })
      );
    };
    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  const unreadCount = notifications.filter((n) => !n.read).length;

  const urgentCount = notifications.filter((n) => n.type === 'urgent').length;
  const pmCount = notifications.filter(
    (n) => n.linkTab === 'pm' || n.title.includes('PM') || n.title.includes('Servis')
  ).length;

  const filteredNotifs = notifications.filter((n) => {
    if (notifFilter === 'urgent') return n.type === 'urgent';
    if (notifFilter === 'pm') {
      return n.linkTab === 'pm' || n.title.includes('PM') || n.title.includes('Servis');
    }
    return true;
  });

  return (
    <header className="h-16 bg-white border-b border-emerald-100 px-4 sm:px-6 flex items-center justify-between sticky top-0 z-30 shadow-xs">
      <div className="flex items-center gap-3">
        <button
          onClick={onOpenMobileMenu}
          className="lg:hidden p-2 rounded-xl text-slate-600 hover:text-emerald-700 hover:bg-emerald-50 focus:outline-hidden"
          aria-label="Toggle menu"
        >
          <svg
            className="w-6 h-6"
            fill="none"
            stroke="currentColor"
            viewBox="0 0 24 24"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth="2"
              d="M4 6h16M4 12h16M4 18h16"
            />
          </svg>
        </button>

        <div className="hidden sm:flex items-center gap-2 text-xs font-medium text-slate-500 bg-slate-50 px-3 py-1.5 rounded-lg border border-slate-200">
          <Clock className="w-3.5 h-3.5 text-emerald-600" />
          <span>{currentTime || 'Memuat waktu...'}</span>
        </div>
      </div>

      <div className="flex items-center gap-2 sm:gap-4">
        {/* Quick action: Scan QR Tag Aset Kamera */}
        {onOpenQRScanner && (
          <button
            onClick={onOpenQRScanner}
            className="flex items-center gap-1.5 bg-slate-900 hover:bg-slate-800 active:scale-95 text-white px-3 sm:px-3.5 py-2 rounded-xl text-xs sm:text-sm font-semibold transition-all shadow-xs cursor-pointer border border-slate-700"
            title="Pindai plat tag QR aset mesin menggunakan kamera"
          >
            <Scan className="w-4 h-4 text-emerald-400" />
            <span className="hidden md:inline">Scan QR Aset</span>
            <span className="md:hidden">Scan</span>
          </button>
        )}

        {/* Quick action: Buat Tiket Baru (Accessible to BOTH Admin and Staff) */}
        <button
          onClick={onOpenNewTicketModal}
          className="flex items-center gap-1.5 bg-emerald-600 hover:bg-emerald-700 active:scale-95 text-white px-3 sm:px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold transition-all shadow-sm shadow-emerald-600/30 cursor-pointer"
        >
          <PlusCircle className="w-4 h-4" />
          <span className="hidden sm:inline">Buat Tiket WO</span>
          <span className="sm:hidden">Tiket</span>
        </button>

        {/* Notifications */}
        <div className="relative">
          <button
            onClick={() => setShowNotifications(!showNotifications)}
            className="p-2 rounded-xl text-slate-600 hover:text-emerald-700 hover:bg-emerald-50 transition-colors relative cursor-pointer"
            aria-label="Notifikasi"
          >
            <Bell className="w-5 h-5" />
            {unreadCount > 0 && (
              <span className="absolute -top-0.5 -right-0.5 w-5 h-5 bg-red-500 text-white rounded-full text-[10px] font-bold flex items-center justify-center animate-pulse">
                {unreadCount > 9 ? '9+' : unreadCount}
              </span>
            )}
          </button>

          {/* Notification dropdown */}
          {showNotifications && (
            <div className="absolute right-0 mt-2 w-84 sm:w-96 bg-white rounded-3xl shadow-2xl border border-slate-200 z-50 overflow-hidden animate-fadeIn text-xs">
              {/* Header */}
              <div className="p-4 bg-gradient-to-r from-emerald-900 via-emerald-800 to-teal-900 text-white flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-xl bg-white/10 flex items-center justify-center">
                    <BellRing className="w-4 h-4 text-emerald-300 animate-bounce" />
                  </div>
                  <div>
                    <h3 className="font-extrabold text-sm text-white leading-tight">
                      Pusat Notifikasi & Peringatan
                    </h3>
                    <span className="text-[10px] text-emerald-200 block">
                      Alert Work Order Urgent & Jadwal Servis PM
                    </span>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  {/* Sound Toggle */}
                  <button
                    onClick={() => setIsSoundEnabled(!isSoundEnabled)}
                    className="p-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-white transition-colors cursor-pointer"
                    title={isSoundEnabled ? 'Matikan Suara Alert' : 'Nyalakan Suara Alert'}
                  >
                    {isSoundEnabled ? (
                      <Volume2 className="w-4 h-4 text-emerald-300" />
                    ) : (
                      <VolumeX className="w-4 h-4 text-slate-400" />
                    )}
                  </button>

                  {unreadCount > 0 && (
                    <button
                      onClick={markAllNotificationsAsRead}
                      className="text-[11px] text-emerald-200 hover:text-white underline cursor-pointer"
                    >
                      Tandai dibaca
                    </button>
                  )}
                  <button
                    onClick={() => setShowNotifications(false)}
                    className="text-emerald-200 hover:text-white p-1 rounded-lg hover:bg-white/10 cursor-pointer"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* Web Browser Push Permission Status & Request Banner */}
              <div className="p-3 bg-slate-50 border-b border-slate-200/80 flex items-center justify-between gap-2.5">
                <div className="flex items-center gap-2 min-w-0">
                  <span
                    className={`w-2.5 h-2.5 rounded-full shrink-0 ${
                      webNotificationPermission === 'granted'
                        ? 'bg-emerald-500'
                        : webNotificationPermission === 'denied'
                        ? 'bg-red-500'
                        : 'bg-amber-500 animate-ping'
                    }`}
                  ></span>
                  <div className="truncate text-[11px]">
                    <span className="font-bold text-slate-800 block truncate">
                      {webNotificationPermission === 'granted'
                        ? 'Notifikasi Web Browser: Aktif'
                        : webNotificationPermission === 'denied'
                        ? 'Izin Web Browser Ditolak'
                        : 'Notifikasi Web: Belum Diizinkan'}
                    </span>
                    <span className="text-[10px] text-slate-500 block truncate">
                      {webNotificationPermission === 'granted'
                        ? 'Push browser & chime audio aktif'
                        : 'Klik aktifkan agar staff terima alert saat window diminimalkan'}
                    </span>
                  </div>
                </div>

                {webNotificationPermission !== 'granted' && webNotificationPermission !== 'unsupported' && (
                  <button
                    onClick={async () => {
                      await requestWebNotificationPermission();
                    }}
                    className="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-lg text-[10px] shadow-xs shrink-0 cursor-pointer"
                  >
                    Aktifkan
                  </button>
                )}
              </div>

              {/* Instant Test Alert Buttons (For quick demonstration) */}
              <div className="p-2.5 bg-emerald-50/50 border-b border-emerald-100 flex items-center justify-between gap-2 text-[10px]">
                <span className="font-extrabold text-emerald-950 uppercase tracking-wider">
                  Uji Coba Alert:
                </span>
                <div className="flex items-center gap-1.5">
                  <button
                    onClick={() => triggerTestUrgentAlert()}
                    className="px-2 py-1 bg-red-600 hover:bg-red-700 active:scale-95 text-white font-bold rounded-lg transition-all flex items-center gap-1 cursor-pointer shadow-xs"
                    title="Simulasikan notifikasi Work Order darurat ditugaskan ke staf"
                  >
                    <AlertTriangle className="w-3 h-3" />
                    <span>Test Tiket Urgent</span>
                  </button>
                  <button
                    onClick={() => triggerTestPMAlert()}
                    className="px-2 py-1 bg-amber-500 hover:bg-amber-600 active:scale-95 text-white font-bold rounded-lg transition-all flex items-center gap-1 cursor-pointer shadow-xs"
                    title="Simulasikan notifikasi Preventive Maintenance jatuh tempo"
                  >
                    <CalendarCheck2 className="w-3 h-3" />
                    <span>Test PM Due</span>
                  </button>
                </div>
              </div>

              {/* Filter Tabs */}
              <div className="px-3 pt-2 pb-1.5 bg-white flex items-center gap-1 border-b border-slate-100">
                <button
                  onClick={() => setNotifFilter('all')}
                  className={`px-2.5 py-1 rounded-lg text-[11px] font-bold transition-colors cursor-pointer ${
                    notifFilter === 'all'
                      ? 'bg-slate-900 text-white'
                      : 'text-slate-600 hover:bg-slate-100'
                  }`}
                >
                  Semua ({notifications.length})
                </button>
                <button
                  onClick={() => setNotifFilter('urgent')}
                  className={`px-2.5 py-1 rounded-lg text-[11px] font-bold transition-colors flex items-center gap-1 cursor-pointer ${
                    notifFilter === 'urgent'
                      ? 'bg-red-600 text-white'
                      : 'text-slate-600 hover:bg-slate-100'
                  }`}
                >
                  <span>Urgent WO</span>
                  {urgentCount > 0 && (
                    <span className="px-1.5 py-0.2 rounded-full text-[9px] bg-red-100 text-red-800 font-black">
                      {urgentCount}
                    </span>
                  )}
                </button>
                <button
                  onClick={() => setNotifFilter('pm')}
                  className={`px-2.5 py-1 rounded-lg text-[11px] font-bold transition-colors flex items-center gap-1 cursor-pointer ${
                    notifFilter === 'pm'
                      ? 'bg-amber-500 text-white'
                      : 'text-slate-600 hover:bg-slate-100'
                  }`}
                >
                  <span>PM Servis</span>
                  {pmCount > 0 && (
                    <span className="px-1.5 py-0.2 rounded-full text-[9px] bg-amber-100 text-amber-800 font-black">
                      {pmCount}
                    </span>
                  )}
                </button>
              </div>

              {/* List */}
              <div className="max-h-72 overflow-y-auto divide-y divide-slate-100">
                {filteredNotifs.length === 0 ? (
                  <div className="p-6 text-center text-slate-400">
                    <CheckCircle2 className="w-8 h-8 text-emerald-500 mx-auto mb-2 opacity-60" />
                    <span>Tidak ada peringatan untuk kategori ini. Kondisi mesin prima!</span>
                  </div>
                ) : (
                  filteredNotifs.map((notif) => (
                    <div
                      key={notif.id}
                      onClick={() => {
                        markNotificationAsRead(notif.id);
                        if (notif.linkTab) setActiveTab(notif.linkTab);
                        setShowNotifications(false);
                      }}
                      className={`p-3.5 hover:bg-slate-50 transition-colors cursor-pointer flex gap-3 ${
                        !notif.read ? 'bg-emerald-50/50' : ''
                      }`}
                    >
                      <div
                        className={`w-2.5 h-2.5 rounded-full mt-1.5 shrink-0 ${
                          notif.type === 'urgent'
                            ? 'bg-red-500 ring-2 ring-red-200'
                            : notif.type === 'warning'
                            ? 'bg-amber-500'
                            : 'bg-emerald-500'
                        }`}
                      ></div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between gap-2">
                          <span className="font-bold text-slate-800 truncate">
                            {notif.title}
                          </span>
                          <span className="text-[10px] text-slate-400 shrink-0">
                            {notif.time}
                          </span>
                        </div>
                        <p className="text-slate-600 mt-0.5 leading-relaxed line-clamp-2">
                          {notif.message}
                        </p>
                      </div>
                    </div>
                  ))
                )}
              </div>

              {/* Footer */}
              <div className="p-2.5 bg-slate-50 border-t border-slate-100 text-center flex items-center justify-between px-4 text-[11px] text-slate-500">
                <span>Klik item untuk langsung menuju ke halaman tiket</span>
                <span className="font-bold text-emerald-700">Auto-Alert ON</span>
              </div>
            </div>
          )}
        </div>

        {/* User profile & Quick Switcher */}
        <div className="relative">
          <button
            onClick={() => setShowUserMenu(!showUserMenu)}
            className="flex items-center gap-2 p-1.5 rounded-xl hover:bg-emerald-50/80 transition-colors border border-slate-200 cursor-pointer"
          >
            <div className="w-8 h-8 rounded-lg bg-emerald-700 text-white font-bold text-xs flex items-center justify-center overflow-hidden">
              {currentUser?.avatar ? (
                <img
                  src={currentUser.avatar}
                  alt={currentUser.name}
                  className="w-full h-full object-cover"
                />
              ) : (
                currentUser?.name.charAt(0) || 'U'
              )}
            </div>
            <div className="text-left hidden md:block">
              <div className="text-xs font-bold text-slate-800 leading-tight">
                {currentUser?.name}
              </div>
              <div className="flex items-center gap-1 mt-0.5">
                <span
                  className={`inline-block w-1.5 h-1.5 rounded-full ${
                    currentUser?.role === 'admin' ? 'bg-emerald-600' : 'bg-blue-600'
                  }`}
                ></span>
                <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500">
                  {currentUser?.role === 'admin' ? 'ADMIN (Full CRUD)' : 'STAFF (Input & View)'}
                </span>
              </div>
            </div>
            <ChevronDown className="w-3.5 h-3.5 text-slate-400 hidden sm:block" />
          </button>

          {/* User popup dropdown */}
          {showUserMenu && (
            <div className="absolute right-0 mt-2 w-64 bg-white rounded-2xl shadow-xl border border-slate-200 p-2 z-50 text-xs">
              <div className="p-3 border-b border-slate-100">
                <div className="font-bold text-slate-900">{currentUser?.name}</div>
                <div className="text-slate-500 text-[11px]">{currentUser?.position}</div>
                <div className="mt-2 inline-flex items-center gap-1.5 px-2 py-0.5 rounded-md bg-emerald-100 text-emerald-800 font-semibold text-[10px]">
                  {currentUser?.role === 'admin' ? (
                    <ShieldCheck className="w-3 h-3 text-emerald-700" />
                  ) : (
                    <UserCheck className="w-3 h-3 text-blue-700" />
                  )}
                  <span>Role: {currentUser?.role.toUpperCase()}</span>
                </div>
              </div>

              {/* Fast Role Switch for testing */}
              <div className="p-2 border-b border-slate-100">
                <span className="text-[10px] uppercase font-bold text-slate-400 block mb-1.5">
                  Ganti Hak Akses (Testing):
                </span>
                <div className="grid grid-cols-2 gap-1.5">
                  <button
                    onClick={() => {
                      loginAs('admin');
                      setShowUserMenu(false);
                    }}
                    className={`p-1.5 rounded-lg text-center font-bold transition-colors cursor-pointer ${
                      currentUser?.role === 'admin'
                        ? 'bg-emerald-600 text-white'
                        : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                    }`}
                  >
                    Admin (Full)
                  </button>
                  <button
                    onClick={() => {
                      loginAs('staff');
                      setShowUserMenu(false);
                    }}
                    className={`p-1.5 rounded-lg text-center font-bold transition-colors cursor-pointer ${
                      currentUser?.role === 'staff'
                        ? 'bg-blue-600 text-white'
                        : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                    }`}
                  >
                    Staff (Terbatas)
                  </button>
                </div>
              </div>

              <div className="p-1">
                <button
                  onClick={() => {
                    if (
                      confirm(
                        'Reset seluruh data kembali ke setelan awal dari lampiran mesin & kartu stok?'
                      )
                    ) {
                      resetToDefaultData();
                      setShowUserMenu(false);
                    }
                  }}
                  className="w-full flex items-center gap-2 p-2 rounded-lg text-slate-600 hover:bg-slate-100 text-left transition-colors cursor-pointer"
                >
                  <RotateCcw className="w-3.5 h-3.5 text-slate-500" />
                  <span>Reset Data Contoh</span>
                </button>

                <button
                  onClick={logout}
                  className="w-full flex items-center gap-2 p-2 rounded-lg text-red-600 hover:bg-red-50 text-left transition-colors cursor-pointer"
                >
                  <LogOut className="w-3.5 h-3.5" />
                  <span>Keluar Akun (Logout)</span>
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </header>
  );
};
