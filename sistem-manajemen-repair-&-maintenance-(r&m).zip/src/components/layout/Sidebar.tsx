import React from 'react';
import { useApp } from '../../context/AppContext';
import {
  LayoutDashboard,
  ClipboardList,
  CalendarCheck2,
  Boxes,
  Database,
  Wrench,
  ShieldCheck,
  UserCheck,
  ChevronRight,
  Sparkles,
  TrendingUp,
  Info,
  X,
} from 'lucide-react';

interface SidebarProps {
  mobileOpen: boolean;
  onCloseMobile: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ mobileOpen, onCloseMobile }) => {
  const { activeTab, setActiveTab, currentUser, workOrders, spareParts, pmTasks } =
    useApp();

  const openWOCount = workOrders.filter((w) => w.status !== 'Closed').length;
  const lowStockCount = spareParts.filter((p) => p.currentStock <= p.minStock).length;
  const pendingPMCount = pmTasks.filter((p) => p.status === 'Scheduled').length;

  const myAssignedTasksCount = workOrders.filter((w) => {
    if (!currentUser?.name) return false;
    const currentName = currentUser.name.toLowerCase();
    const assigned = (w.assignedTechnician || '').toLowerCase();
    if (!assigned) return false;
    return (
      w.status !== 'Closed' &&
      (assigned.includes(currentName) ||
        currentName.includes(assigned) ||
        (assigned.includes('agus') && currentName.includes('agus')) ||
        (assigned.includes('budi') && currentName.includes('budi')))
    );
  }).length;

  const navItems = [
    {
      id: 'dashboard',
      label: 'Dashboard & Eksekutif',
      icon: LayoutDashboard,
      desc: 'Status aset & grafik MTBF/MTTR',
    },
    {
      id: 'my-tasks',
      label: 'Tugas Saya (My Tasks)',
      icon: UserCheck,
      badge: myAssignedTasksCount > 0 ? `${myAssignedTasksCount} Aktif` : undefined,
      badgeColor: 'bg-emerald-600 text-white font-extrabold',
      desc: 'Tiket khusus teknisi PIC',
    },
    {
      id: 'work-orders',
      label: 'Manajemen Work Order',
      icon: ClipboardList,
      badge: openWOCount > 0 ? openWOCount : undefined,
      badgeColor: 'bg-amber-500 text-white',
      desc: 'Tiket & penugasan teknisi',
    },
    {
      id: 'pm',
      label: 'Preventive Maintenance',
      icon: CalendarCheck2,
      badge: pendingPMCount > 0 ? pendingPMCount : undefined,
      badgeColor: 'bg-emerald-600 text-white',
      desc: 'Jadwal rutin & checklist servis',
    },
    {
      id: 'inventory',
      label: 'Inventaris & Suku Cadang',
      icon: Boxes,
      badge: lowStockCount > 0 ? `${lowStockCount} Menipis` : undefined,
      badgeColor: 'bg-red-500 text-white animate-pulse',
      desc: 'Kartu stok heater & elektrikal',
    },
    {
      id: 'assets',
      label: 'Database Aset & Mesin',
      icon: Database,
      desc: '46 Unit mesin, histori & SOP',
    },
    {
      id: 'reports',
      label: 'Tren MTBF & MTTR',
      icon: TrendingUp,
      desc: 'Grafik Recharts & analitik',
    },
  ];

  return (
    <>
      {/* Mobile backdrop */}
      {mobileOpen && (
        <div
          onClick={onCloseMobile}
          className="fixed inset-0 bg-slate-900/60 z-40 lg:hidden backdrop-blur-xs"
        ></div>
      )}

      <aside
        className={`fixed lg:sticky top-0 h-screen w-72 bg-white border-r border-emerald-100 flex flex-col justify-between z-50 transition-transform duration-300 ${
          mobileOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'
        }`}
      >
        {/* Brand header */}
        <div>
          <div className="h-16 border-b border-emerald-100 px-6 flex items-center justify-between bg-emerald-800 text-white">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-white text-emerald-800 flex items-center justify-center font-black shadow-md">
                <Wrench className="w-5 h-5 text-emerald-700" />
              </div>
              <div>
                <span className="text-[10px] uppercase font-bold tracking-widest text-emerald-300 block leading-tight">
                  Departemen R&M
                </span>
                <span className="text-base font-extrabold tracking-tight text-white leading-tight">
                  Maintenance Hub
                </span>
              </div>
            </div>

            <button
              onClick={onCloseMobile}
              className="lg:hidden p-1 text-emerald-200 hover:text-white rounded-lg"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* User role status card */}
          <div className="p-4 mx-3 my-3 bg-gradient-to-r from-emerald-50 to-teal-50/50 rounded-2xl border border-emerald-200/60 text-xs">
            <div className="flex items-center justify-between mb-1.5">
              <span className="text-[10px] uppercase tracking-wider font-extrabold text-emerald-800">
                Otoritas Akses Aktif
              </span>
              <span
                className={`px-2 py-0.5 rounded-full font-bold text-[10px] ${
                  currentUser?.role === 'admin'
                    ? 'bg-emerald-600 text-white'
                    : 'bg-blue-600 text-white'
                }`}
              >
                {currentUser?.role === 'admin' ? 'ADMIN' : 'STAFF'}
              </span>
            </div>
            <div className="text-slate-700 font-medium">
              {currentUser?.role === 'admin' ? (
                <div className="flex items-center gap-1.5 text-emerald-900 font-semibold">
                  <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                  <span>Full Akses (Edit, Input & Hapus)</span>
                </div>
              ) : (
                <div className="flex items-center gap-1.5 text-slate-700 font-semibold">
                  <UserCheck className="w-3.5 h-3.5 text-blue-600" />
                  <span>Akses Terbatas (Input & View Saja)</span>
                </div>
              )}
            </div>
          </div>

          {/* Navigation Links */}
          <nav className="p-3 space-y-1.5">
            <div className="px-3 py-1 text-[11px] font-bold uppercase tracking-wider text-slate-400">
              Modul Perawatan Pabrik
            </div>
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => {
                    setActiveTab(item.id);
                    onCloseMobile();
                  }}
                  className={`w-full flex items-center justify-between p-3 rounded-2xl text-left transition-all cursor-pointer group ${
                    isActive
                      ? 'bg-emerald-600 text-white font-bold shadow-md shadow-emerald-600/30'
                      : 'text-slate-700 hover:bg-emerald-50/70 hover:text-emerald-800'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <div
                      className={`w-9 h-9 rounded-xl flex items-center justify-center transition-colors ${
                        isActive
                          ? 'bg-emerald-700 text-white'
                          : 'bg-slate-100 text-slate-600 group-hover:bg-emerald-100 group-hover:text-emerald-700'
                      }`}
                    >
                      <Icon className="w-4 h-4" />
                    </div>
                    <div>
                      <div className="text-xs sm:text-sm font-semibold leading-tight">
                        {item.label}
                      </div>
                      <div
                        className={`text-[10px] mt-0.5 leading-tight ${
                          isActive ? 'text-emerald-100' : 'text-slate-400'
                        }`}
                      >
                        {item.desc}
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-1.5">
                    {item.badge && (
                      <span
                        className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${item.badgeColor}`}
                      >
                        {item.badge}
                      </span>
                    )}
                    <ChevronRight
                      className={`w-3.5 h-3.5 ${
                        isActive
                          ? 'text-white'
                          : 'text-slate-300 group-hover:text-emerald-600'
                      }`}
                    />
                  </div>
                </button>
              );
            })}
          </nav>
        </div>

        {/* Footer plant info */}
        <div className="p-4 border-t border-emerald-100 bg-slate-50/70 text-slate-500 text-xs">
          <div className="flex items-center gap-2 mb-1.5">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping"></span>
            <span className="font-semibold text-slate-700">Line Injeksi: 46 M/C Aktif</span>
          </div>
          <p className="text-[11px] text-slate-400 leading-relaxed">
            Data terintegrasi dari buku mesin & kartu stok suku cadang.
          </p>
        </div>
      </aside>
    </>
  );
};
