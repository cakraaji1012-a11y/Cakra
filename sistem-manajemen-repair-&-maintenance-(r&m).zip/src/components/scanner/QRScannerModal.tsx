import React, { useState, useEffect, useRef } from 'react';
import jsQR from 'jsqr';
import { useApp } from '../../context/AppContext';
import {
  Camera,
  X,
  RefreshCw,
  AlertCircle,
  CheckCircle2,
  Upload,
  Sparkles,
  Cpu,
  Volume2,
  VolumeX,
  Wrench,
  Scan,
} from 'lucide-react';

interface QRScannerModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const QRScannerModal: React.FC<QRScannerModalProps> = ({ isOpen, onClose }) => {
  const { machines, openAssetHistoryById } = useApp();

  const videoRef = useRef<HTMLVideoElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const animationFrameId = useRef<number | null>(null);
  const streamRef = useRef<MediaStream | null>(null);

  const [hasPermission, setHasPermission] = useState<boolean | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [facingMode, setFacingMode] = useState<'environment' | 'user'>('environment');
  const [scannedResult, setScannedResult] = useState<string | null>(null);
  const [matchedMachineName, setMatchedMachineName] = useState<string | null>(null);
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [isProcessing, setIsProcessing] = useState(false);

  // Play audio beep
  const playBeep = () => {
    if (!soundEnabled) return;
    try {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      const ctx = new AudioCtx();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(880, ctx.currentTime);
      gain.gain.setValueAtTime(0.2, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.25);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + 0.25);
    } catch {
      // AudioContext might be restricted until user interaction
    }
  };

  const stopCamera = () => {
    if (animationFrameId.current) {
      cancelAnimationFrame(animationFrameId.current);
      animationFrameId.current = null;
    }
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((track) => track.stop());
      streamRef.current = null;
    }
  };

  // Start video stream
  const startCamera = async () => {
    stopCamera();
    setErrorMessage(null);
    setScannedResult(null);
    setMatchedMachineName(null);
    setIsProcessing(false);

    try {
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        setHasPermission(false);
        setErrorMessage('Browser atau perangkat ini tidak mendukung akses kamera langsung.');
        return;
      }

      const stream = await navigator.mediaDevices.getUserMedia({
        video: {
          facingMode: { ideal: facingMode },
          width: { ideal: 1280 },
          height: { ideal: 720 },
        },
      });

      streamRef.current = stream;
      setHasPermission(true);

      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.setAttribute('playsinline', 'true');
        await videoRef.current.play();
        requestAnimationFrame(tickScan);
      }
    } catch (err: unknown) {
      console.warn('Camera access error:', err);
      setHasPermission(false);
      const e = err as { name?: string; message?: string };
      if (e.name === 'NotAllowedError' || e.name === 'PermissionDeniedError') {
        setErrorMessage('Izin kamera ditolak. Harap izinkan akses kamera di pengaturan browser Anda.');
      } else if (e.name === 'NotFoundError' || e.name === 'DevicesNotFoundError') {
        setErrorMessage('Perangkat kamera tidak ditemukan pada sistem ini.');
      } else {
        setErrorMessage('Gagal mengaktifkan kamera. Anda dapat menggunakan fitur unggah gambar tag QR di bawah.');
      }
    }
  };

  // Process decoded QR text
  const handleDecodedData = (rawText: string) => {
    if (isProcessing) return;
    setIsProcessing(true);
    setScannedResult(rawText);
    playBeep();

    // Check match
    const success = openAssetHistoryById(rawText);

    if (success) {
      // Find matching machine info for confirmation display
      const str = rawText.trim().toLowerCase();
      let found = machines.find((m) => m.id.toLowerCase() === str);
      if (!found) {
        const numMatch = str.match(/\d+/);
        if (numMatch) {
          found = machines.find((m) => m.noMc === parseInt(numMatch[0]));
        }
      }
      if (!found) {
        found = machines.find((m) => m.name.toLowerCase().includes(str));
      }

      const label = found ? `${found.name} (No. ${found.noMc} - ${found.tonase})` : rawText;
      setMatchedMachineName(label);

      // Auto close and navigate to database view
      setTimeout(() => {
        stopCamera();
        onClose();
      }, 700);
    } else {
      setErrorMessage(`Tag QR "${rawText}" terbaca, namun tidak cocok dengan 46 unit mesin terdaftar.`);
      setTimeout(() => {
        setIsProcessing(false);
        setScannedResult(null);
        if (videoRef.current && hasPermission) {
          requestAnimationFrame(tickScan);
        }
      }, 2500);
    }
  };

  // Continuous frame scanning loop
  const tickScan = () => {
    if (!videoRef.current || videoRef.current.readyState !== videoRef.current.HAVE_ENOUGH_DATA) {
      animationFrameId.current = requestAnimationFrame(tickScan);
      return;
    }

    const video = videoRef.current;
    let canvas = canvasRef.current;
    if (!canvas) {
      canvas = document.createElement('canvas');
      canvasRef.current = canvas;
    }

    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    const ctx = canvas.getContext('2d', { willReadFrequently: true });

    if (ctx) {
      ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
      const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
      const code = jsQR(imageData.data, imageData.width, imageData.height, {
        inversionAttempts: 'dontInvert',
      });

      if (code && code.data && code.data.trim()) {
        handleDecodedData(code.data);
        return;
      }
    }

    animationFrameId.current = requestAnimationFrame(tickScan);
  };

  // Handle image upload fallback
  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        canvas.width = img.width;
        canvas.height = img.height;
        const ctx = canvas.getContext('2d');
        if (!ctx) return;
        ctx.drawImage(img, 0, 0, img.width, img.height);
        const imageData = ctx.getImageData(0, 0, img.width, img.height);
        const code = jsQR(imageData.data, imageData.width, imageData.height);

        if (code && code.data) {
          handleDecodedData(code.data);
        } else {
          setErrorMessage('Tidak ditemukan barcode atau QR Code yang terbaca pada gambar tersebut.');
        }
      };
      img.src = event.target?.result as string;
    };
    reader.readAsDataURL(file);
  };

  // Quick testing simulator
  const handleSimulateScan = (machineNo: number) => {
    handleDecodedData(`mc-${machineNo}`);
  };

  useEffect(() => {
    if (isOpen) {
      startCamera();
    } else {
      stopCamera();
    }
    return () => {
      stopCamera();
    };
  }, [isOpen, facingMode]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-slate-950/80 z-50 flex items-center justify-center p-3 sm:p-4 backdrop-blur-md animate-fadeIn">
      <div className="bg-slate-900 text-white rounded-3xl max-w-lg w-full overflow-hidden shadow-2xl border border-emerald-500/30 flex flex-col">
        {/* Header */}
        <div className="p-4 sm:p-5 bg-gradient-to-r from-emerald-950 via-slate-900 to-emerald-950 border-b border-emerald-800/40 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-emerald-600 text-white flex items-center justify-center shadow-lg shadow-emerald-600/30">
              <Scan className="w-5 h-5 text-white" />
            </div>
            <div>
              <div className="inline-flex items-center gap-1.5 text-[10px] uppercase font-bold tracking-widest text-emerald-400">
                <Sparkles className="w-3 h-3" />
                <span>Pemindai Kamera Langsung</span>
              </div>
              <h3 className="text-base font-extrabold text-white">
                Scan QR Tag Aset Mesin
              </h3>
            </div>
          </div>

          <div className="flex items-center gap-1.5">
            <button
              onClick={() => setSoundEnabled(!soundEnabled)}
              className="p-2 text-slate-400 hover:text-white rounded-xl hover:bg-slate-800 transition-colors cursor-pointer"
              title={soundEnabled ? 'Matikan Suara Beep' : 'Nyalakan Suara Beep'}
            >
              {soundEnabled ? <Volume2 className="w-4 h-4 text-emerald-400" /> : <VolumeX className="w-4 h-4" />}
            </button>
            <button
              onClick={() => setFacingMode(facingMode === 'environment' ? 'user' : 'environment')}
              className="p-2 text-slate-400 hover:text-white rounded-xl hover:bg-slate-800 transition-colors cursor-pointer"
              title="Ganti Kamera Depan/Belakang"
            >
              <RefreshCw className="w-4 h-4" />
            </button>
            <button
              onClick={onClose}
              className="p-2 text-slate-400 hover:text-white rounded-xl hover:bg-slate-800 transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Viewfinder / Video Section */}
        <div className="relative aspect-4/3 sm:aspect-16/10 bg-black flex items-center justify-center overflow-hidden">
          <video
            ref={videoRef}
            className="w-full h-full object-cover"
            playsInline
            muted
          />

          {/* Industrial Targeting Reticle Overlay */}
          <div className="absolute inset-0 pointer-events-none flex items-center justify-center p-6">
            <div className="w-56 h-56 sm:w-64 sm:h-64 border-2 border-emerald-500/40 rounded-3xl relative flex items-center justify-center shadow-[0_0_50px_rgba(16,185,129,0.15)]">
              {/* Corner accent brackets */}
              <div className="absolute -top-1 -left-1 w-6 h-6 border-t-4 border-l-4 border-emerald-400 rounded-tl-xl"></div>
              <div className="absolute -top-1 -right-1 w-6 h-6 border-t-4 border-r-4 border-emerald-400 rounded-tr-xl"></div>
              <div className="absolute -bottom-1 -left-1 w-6 h-6 border-b-4 border-l-4 border-emerald-400 rounded-bl-xl"></div>
              <div className="absolute -bottom-1 -right-1 w-6 h-6 border-b-4 border-r-4 border-emerald-400 rounded-br-xl"></div>

              {/* Animated laser scanning line */}
              {!scannedResult && (
                <div className="w-full h-0.5 bg-gradient-to-r from-transparent via-emerald-400 to-transparent shadow-[0_0_15px_#10b981] animate-bounce"></div>
              )}

              {/* Success badge over viewfinder */}
              {matchedMachineName && (
                <div className="absolute inset-0 bg-emerald-950/90 rounded-3xl flex flex-col items-center justify-center p-4 text-center animate-fadeIn">
                  <div className="w-14 h-14 rounded-full bg-emerald-500 text-white flex items-center justify-center shadow-lg shadow-emerald-500/40 mb-2">
                    <CheckCircle2 className="w-8 h-8" />
                  </div>
                  <span className="text-xs uppercase font-extrabold tracking-wider text-emerald-300">
                    Aset Terdeteksi!
                  </span>
                  <div className="font-extrabold text-sm text-white mt-1">
                    {matchedMachineName}
                  </div>
                  <span className="text-[11px] text-emerald-200/80 mt-1">
                    Membuka Kartu Riwayat Aset...
                  </span>
                </div>
              )}
            </div>
          </div>

          {/* Camera fallback / Permission warning message */}
          {hasPermission === false && (
            <div className="absolute inset-0 bg-slate-950/95 flex flex-col items-center justify-center p-6 text-center">
              <div className="w-12 h-12 rounded-2xl bg-amber-500/20 text-amber-400 flex items-center justify-center mb-3">
                <AlertCircle className="w-6 h-6" />
              </div>
              <h4 className="font-extrabold text-sm text-white">Kamera Belum Terhubung / Diizinkan</h4>
              <p className="text-xs text-slate-400 mt-1.5 max-w-xs leading-relaxed">
                {errorMessage || 'Pastikan browser memiliki izin mengakses kamera perangkat.'}
              </p>
              <button
                onClick={startCamera}
                className="mt-4 px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl text-xs flex items-center gap-2 cursor-pointer shadow-md"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                <span>Coba Akses Kamera Lagi</span>
              </button>
            </div>
          )}
        </div>

        {/* Footer controls & manual testing options */}
        <div className="p-4 sm:p-5 bg-slate-900 border-t border-slate-800 space-y-4 text-xs">
          {/* Instruction */}
          <div className="flex items-center justify-between text-[11px] text-slate-400">
            <span>Arahkan kamera ke barcode/QR Code pada plat mesin</span>
            <span className="font-mono text-emerald-400 font-bold">Auto-Focus ON</span>
          </div>

          {/* Alternative: Upload QR image from device */}
          <div className="flex items-center justify-between gap-3 pt-2 border-t border-slate-800/80">
            <input
              type="file"
              ref={fileInputRef}
              accept="image/*"
              className="hidden"
              onChange={handleImageUpload}
            />
            <button
              onClick={() => fileInputRef.current?.click()}
              className="flex-1 py-2 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold text-xs flex items-center justify-center gap-2 transition-colors cursor-pointer border border-slate-700"
            >
              <Upload className="w-3.5 h-3.5 text-emerald-400" />
              <span>Unggah Gambar Tag QR</span>
            </button>
          </div>

          {/* Testing Simulator Dropdown (Single-click test all 46 machines!) */}
          <div className="pt-2 border-t border-slate-800/80">
            <label className="block text-[10px] uppercase font-bold tracking-wider text-slate-400 mb-1.5">
              Simulasi Pindai Cepat Tag Aset (Untuk Testing Langsung):
            </label>
            <select
              onChange={(e) => {
                if (e.target.value) {
                  handleSimulateScan(parseInt(e.target.value));
                }
              }}
              defaultValue=""
              className="w-full py-2 px-3 rounded-xl bg-slate-950 border border-slate-700 text-emerald-300 text-xs font-semibold focus:ring-2 focus:ring-emerald-500 cursor-pointer"
            >
              <option value="" disabled>-- Pilih Tag Mesin untuk Disimulasikan --</option>
              <option value="2">Mesin No. 2 - TOSHIBA (220 Ton - Hydrolik)</option>
              <option value="3">Mesin No. 3 - NISSEI (100 Ton - Hydrolik)</option>
              <option value="6">Mesin No. 6 - YIZUMI (260 Ton - Toggle)</option>
              <option value="21">Mesin No. 21 - KAWAGUCHI (180 Ton - Breakdown)</option>
              <option value="38">Mesin No. 38 - TOSHIBA (450 Ton - Breakdown)</option>
              <option value="44">Mesin No. 44 - YIZUMI (260 Ton - Toggle)</option>
              <option value="52">Mesin No. 52 - TAIFU (85 Ton - Hydrolik)</option>
            </select>
          </div>
        </div>
      </div>
    </div>
  );
};
