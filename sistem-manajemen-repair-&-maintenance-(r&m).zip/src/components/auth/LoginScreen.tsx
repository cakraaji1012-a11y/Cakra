import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Wrench,
  ShieldCheck,
  UserCheck,
  Lock,
  ArrowRight,
  Cpu,
  CheckCircle2,
  AlertCircle,
  Activity,
  Layers,
  Sparkles,
} from 'lucide-react';

export const LoginScreen: React.FC = () => {
  const { login, loginAs } = useApp();
  const [username, setUsername] = useState('admin');
  const [password, setPassword] = useState('••••••••');
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!username.trim()) {
      setError('Silakan masukkan ID Pengguna atau Username.');
      return;
    }
    const success = login(username);
    if (!success) {
      setError('Username tidak terdaftar! Gunakan "admin" atau "staff".');
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-emerald-950 via-emerald-900 to-slate-950 flex items-center justify-center p-4 sm:p-6 lg:p-8 relative overflow-hidden font-sans">
      {/* Decorative Grid & Glow Background */}
      <div className="absolute inset-0 opacity-15 pointer-events-none bg-[radial-gradient(#10b981_1px,transparent_1px)] [background-size:24px_24px]"></div>
      <div className="absolute -top-40 -right-40 w-96 h-96 bg-emerald-500/20 rounded-full blur-3xl pointer-events-none"></div>
      <div className="absolute -bottom-40 -left-40 w-96 h-96 bg-teal-500/15 rounded-full blur-3xl pointer-events-none"></div>

      <div className="w-full max-w-5xl bg-white rounded-3xl shadow-2xl overflow-hidden border border-emerald-100 grid grid-cols-1 lg:grid-cols-12 relative z-10">
        {/* Left Side: Brand & Feature Presentation */}
        <div className="lg:col-span-6 bg-gradient-to-b from-emerald-800 via-emerald-850 to-emerald-900 text-white p-8 sm:p-12 flex flex-col justify-between relative overflow-hidden">
          <div className="absolute top-0 right-0 w-80 h-80 bg-white/5 rounded-full blur-2xl pointer-events-none"></div>
          
          <div>
            <div className="flex items-center gap-3 mb-8">
              <div className="w-12 h-12 rounded-2xl bg-white text-emerald-800 flex items-center justify-center shadow-lg shadow-emerald-950/20 font-black">
                <Wrench className="w-6 h-6 text-emerald-700" />
              </div>
              <div>
                <span className="text-xs uppercase tracking-widest text-emerald-200 font-bold block">
                  Plant Engineering & Maintenance
                </span>
                <h1 className="text-2xl font-extrabold tracking-tight text-white">
                  R&M System
                </h1>
              </div>
            </div>

            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-emerald-700/60 border border-emerald-500/40 text-emerald-200 text-xs font-semibold mb-6">
              <Sparkles className="w-3.5 h-3.5 text-emerald-300" />
              <span>Sistem Pemeliharaan & Keandalan Mesin</span>
            </div>

            <h2 className="text-3xl font-extrabold leading-tight text-white mb-4">
              Pusat Kendali Perbaikan & Pemeliharaan Terpadu
            </h2>

            <p className="text-emerald-100/90 text-sm leading-relaxed mb-8">
              Platform operasional departemen Repair and Maintenance untuk memonitor 46+ mesin injeksi,
              mengelola tiket Work Order, kartu stok heater & electrical otomatis, serta kartu riwayat aset.
            </p>

            {/* Quick feature highlights */}
            <div className="space-y-3.5 text-xs text-emerald-100">
              <div className="flex items-center gap-3 bg-white/10 backdrop-blur-sm px-3.5 py-2.5 rounded-xl border border-white/10">
                <Cpu className="w-4 h-4 text-emerald-300 shrink-0" />
                <span>46 Unit Mesin Injeksi (Toshiba, Nissei, Yizumi, Kawaguchi)</span>
              </div>
              <div className="flex items-center gap-3 bg-white/10 backdrop-blur-sm px-3.5 py-2.5 rounded-xl border border-white/10">
                <Activity className="w-4 h-4 text-emerald-300 shrink-0" />
                <span>Metrik MTBF, MTTR & Kalkulasi Downtime Otomatis</span>
              </div>
              <div className="flex items-center gap-3 bg-white/10 backdrop-blur-sm px-3.5 py-2.5 rounded-xl border border-white/10">
                <Layers className="w-4 h-4 text-emerald-300 shrink-0" />
                <span>Kartu Stok Heater & Elektrikal dengan Auto-Reorder Alert</span>
              </div>
            </div>
          </div>

          <div className="pt-8 border-t border-emerald-700/50 mt-8 flex items-center justify-between text-xs text-emerald-300">
            <span>© 2026 PT Manufacturing Industry</span>
            <span className="font-mono bg-emerald-950/40 px-2.5 py-1 rounded-md text-emerald-200">
              v3.4 Production
            </span>
          </div>
        </div>

        {/* Right Side: Login Form with Role Switchers */}
        <div className="lg:col-span-6 p-8 sm:p-12 bg-white flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-8">
              <div>
                <h3 className="text-2xl font-bold text-slate-900 tracking-tight">
                  Masuk ke Portal
                </h3>
                <p className="text-slate-500 text-sm mt-1">
                  Pilih peran Anda atau masukkan kredensial akun
                </p>
              </div>
              <div className="w-10 h-10 rounded-full bg-emerald-50 text-emerald-600 flex items-center justify-center border border-emerald-200">
                <Lock className="w-5 h-5" />
              </div>
            </div>

            {error && (
              <div className="mb-6 p-3.5 rounded-xl bg-red-50 border border-red-200 text-red-700 text-xs flex items-center gap-2.5 animate-fadeIn">
                <AlertCircle className="w-4 h-4 shrink-0 text-red-500" />
                <span>{error}</span>
              </div>
            )}

            {/* Quick Role Selection Cards */}
            <div className="mb-6">
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-500 mb-2.5">
                Login Cepat Berdasarkan Peran (Role):
              </label>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {/* Admin Option */}
                <button
                  type="button"
                  onClick={() => loginAs('admin')}
                  className="p-4 text-left rounded-2xl border-2 border-emerald-500 bg-emerald-50/50 hover:bg-emerald-100/60 transition-all text-slate-800 group relative shadow-sm"
                >
                  <div className="flex items-center justify-between mb-2">
                    <span className="w-8 h-8 rounded-xl bg-emerald-600 text-white flex items-center justify-center text-xs font-bold shadow-md shadow-emerald-600/30">
                      <ShieldCheck className="w-4 h-4" />
                    </span>
                    <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full bg-emerald-200 text-emerald-900">
                      Akses Penuh
                    </span>
                  </div>
                  <div className="font-bold text-sm text-slate-900">ADMIN / SPV</div>
                  <div className="text-xs text-slate-500 mt-1">Budi Santoso, S.T.</div>
                  <div className="text-[11px] text-emerald-700 font-medium mt-2 flex items-center gap-1">
                    <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                    <span>Lihat, Input, Edit & Hapus</span>
                  </div>
                </button>

                {/* Staff Option */}
                <button
                  type="button"
                  onClick={() => loginAs('staff')}
                  className="p-4 text-left rounded-2xl border border-slate-200 bg-slate-50/70 hover:border-emerald-400 hover:bg-emerald-50/30 transition-all text-slate-800 group relative shadow-sm"
                >
                  <div className="flex items-center justify-between mb-2">
                    <span className="w-8 h-8 rounded-xl bg-slate-700 text-white flex items-center justify-center text-xs font-bold group-hover:bg-emerald-600 transition-colors">
                      <UserCheck className="w-4 h-4" />
                    </span>
                    <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full bg-slate-200 text-slate-800">
                      Operator
                    </span>
                  </div>
                  <div className="font-bold text-sm text-slate-900">STAFF / TEKNISI</div>
                  <div className="text-xs text-slate-500 mt-1">Agus Wijaya</div>
                  <div className="text-[11px] text-slate-600 font-medium mt-2 flex items-center gap-1">
                    <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                    <span>Lihat & Input Data Saja</span>
                  </div>
                </button>
              </div>
            </div>

            <div className="relative my-6">
              <div className="absolute inset-0 flex items-center">
                <div className="w-full border-t border-slate-200"></div>
              </div>
              <div className="relative flex justify-center text-xs uppercase">
                <span className="bg-white px-3 text-slate-400 font-semibold tracking-wider">
                  atau masukkan akun manual
                </span>
              </div>
            </div>

            {/* Manual Form */}
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                  ID Pengguna / Username
                </label>
                <div className="relative">
                  <input
                    type="text"
                    value={username}
                    onChange={(e) => {
                      setUsername(e.target.value);
                      setError(null);
                    }}
                    placeholder="Contoh: admin atau staff"
                    className="w-full pl-4 pr-10 py-3 rounded-xl border border-slate-300 focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 transition-all text-sm bg-white"
                  />
                  <div className="absolute right-3.5 top-3.5 text-xs font-mono text-slate-400">
                    ID
                  </div>
                </div>
              </div>

              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="block text-xs font-semibold text-slate-700">
                    Kata Sandi
                  </label>
                  <span className="text-[11px] text-emerald-600 font-medium">
                    Default: sembarang
                  </span>
                </div>
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full px-4 py-3 rounded-xl border border-slate-300 focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 transition-all text-sm bg-white font-mono"
                />
              </div>

              <button
                type="submit"
                className="w-full py-3.5 px-4 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl font-bold text-sm transition-all flex items-center justify-center gap-2 shadow-lg shadow-emerald-600/30 hover:shadow-emerald-600/40 active:scale-[0.99] cursor-pointer mt-2"
              >
                <span>Masuk ke Dashboard Sistem</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </form>
          </div>

          {/* Role access breakdown note */}
          <div className="mt-8 pt-6 border-t border-slate-100 bg-slate-50/80 -mx-8 -mb-12 p-6 rounded-b-3xl">
            <div className="text-xs text-slate-500 flex items-start gap-2">
              <span className="font-bold text-emerald-700 shrink-0">Catatan Otoritas:</span>
              <span>
                <strong>Admin</strong> berhak mengedit, menambah, dan menghapus seluruh aset, inventaris, dan WO. <strong>Staff</strong> hanya memiliki hak memantau status serta menginput tiket WO dan mutasi suku cadang.
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
