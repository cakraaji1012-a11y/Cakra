import React, { useState, useEffect } from 'react';
import QRCode from 'qrcode';
import { useApp } from '../../context/AppContext';
import { Machine, DocumentSOP, MekanismeType, MachineStatus } from '../../types';
import {
  Database,
  Cpu,
  Search,
  Filter,
  Plus,
  FileText,
  History,
  QrCode,
  Printer,
  FileSpreadsheet,
  CheckCircle2,
  AlertTriangle,
  Clock,
  Layers,
  Wrench,
  BookOpen,
  Download,
  Trash2,
  Edit,
  ExternalLink,
  ShieldCheck,
  ChevronRight,
  Package,
  Scan,
} from 'lucide-react';

interface AssetDatabaseViewProps {
  onOpenQRScanner?: () => void;
}

export const AssetDatabaseView: React.FC<AssetDatabaseViewProps> = ({ onOpenQRScanner }) => {
  const {
    machines,
    addMachine,
    updateMachine,
    deleteMachine,
    workOrders,
    stockLogs,
    sopDocuments,
    isAdmin,
    selectedAssetIdForView,
    setSelectedAssetIdForView,
  } = useApp();

  const [activeSubTab, setActiveSubTab] = useState<'machines' | 'sops'>('machines');
  const [searchTerm, setSearchTerm] = useState('');
  const [filterMekanisme, setFilterMekanisme] = useState<string>('all');
  const [filterBrand, setFilterBrand] = useState<string>('all');
  const [filterStatus, setFilterStatus] = useState<string>('all');

  // Selected Machine for Asset History Card
  const [selectedMachine, setSelectedMachine] = useState<Machine | null>(null);
  const [qrCodeDataUrl, setQrCodeDataUrl] = useState<string>('');

  // Selected SOP for document viewer
  const [selectedSOP, setSelectedSOP] = useState<DocumentSOP | null>(null);

  // Auto-open machine when triggered from QR scanner or elsewhere
  useEffect(() => {
    if (selectedAssetIdForView) {
      const found = machines.find((m) => m.id === selectedAssetIdForView);
      if (found) {
        setSelectedMachine(found);
      }
      setSelectedAssetIdForView(null);
    }
  }, [selectedAssetIdForView, machines, setSelectedAssetIdForView]);

  // Generate real QR code image for machine
  useEffect(() => {
    if (selectedMachine) {
      QRCode.toDataURL(
        `mc-${selectedMachine.noMc}`,
        {
          width: 220,
          margin: 1,
          color: {
            dark: '#064e3b',
            light: '#ffffff',
          },
        },
        (err, url) => {
          if (!err && url) {
            setQrCodeDataUrl(url);
          }
        }
      );
    } else {
      setQrCodeDataUrl('');
    }
  }, [selectedMachine]);

  // Add Machine Modal
  const [showAddMachineModal, setShowAddMachineModal] = useState(false);
  const [newName, setNewName] = useState('YIZUMI');
  const [newNoMc, setNewNoMc] = useState<number>(53);
  const [newTonase, setNewTonase] = useState('260 Ton');
  const [newNegara, setNewNegara] = useState('China');
  const [newTahunBuat, setNewTahunBuat] = useState(2025);
  const [newTahunBeli, setNewTahunBeli] = useState(2026);
  const [newMekanisme, setNewMekanisme] = useState<MekanismeType>('TOGGLE');
  const [newLokasi, setNewLokasi] = useState('Bay 12 - Line Injeksi Baru');

  // Filtered Machines
  const filteredMachines = machines.filter((m) => {
    const matchSearch =
      m.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      String(m.noMc).includes(searchTerm) ||
      m.tonase.toLowerCase().includes(searchTerm.toLowerCase()) ||
      m.negaraAsal.toLowerCase().includes(searchTerm.toLowerCase());

    const matchMekanisme = filterMekanisme === 'all' || m.mekanisme === filterMekanisme;
    const matchBrand = filterBrand === 'all' || m.name === filterBrand;
    const matchStatus = filterStatus === 'all' || m.status === filterStatus;

    return matchSearch && matchMekanisme && matchBrand && matchStatus;
  });

  // Extract distinct brand list
  const distinctBrands = Array.from(new Set(machines.map((m) => m.name)));

  const handleAddMachine = (e: React.FormEvent) => {
    e.preventDefault();
    const currentYear = 2026;
    const usiaPemakaian = Math.max(0, currentYear - newTahunBeli);
    const totalUsia = Math.max(0, currentYear - newTahunBuat);
    const tonaseNum = parseInt(newTonase.replace(/\D/g, '')) || 200;

    addMachine({
      name: newName,
      noMc: newNoMc,
      tonase: newTonase,
      tonaseVal: tonaseNum,
      negaraAsal: newNegara,
      tahunPembuatan: newTahunBuat,
      tahunPembelian: newTahunBeli,
      usiaPemakaian,
      totalUsia,
      mekanisme: newMekanisme,
      status: 'active',
      lokasi: newLokasi,
    });

    setShowAddMachineModal(false);
  };

  const handlePrint = () => {
    window.print();
  };

  const getStatusBadge = (status: MachineStatus) => {
    switch (status) {
      case 'active':
        return 'bg-emerald-100 text-emerald-800 border-emerald-300';
      case 'breakdown':
        return 'bg-red-100 text-red-800 border-red-300';
      case 'maintenance':
        return 'bg-amber-100 text-amber-800 border-amber-300';
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white p-6 rounded-3xl border border-emerald-100 shadow-xs">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-50 text-emerald-700 text-xs font-bold mb-2">
            <Database className="w-3.5 h-3.5" />
            <span>Master Data Mesin Pabrik & Arsip Dokumen Digital</span>
          </div>
          <h1 className="text-2xl font-extrabold text-slate-900 tracking-tight">
            Database Aset & Data Mesin Injeksi
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Data lengkap 46 unit mesin, kartu riwayat perbaikan (Asset History Card), dan SOP digital pemeliharaan.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          {onOpenQRScanner && (
            <button
              onClick={onOpenQRScanner}
              className="flex items-center gap-1.5 px-4 py-2.5 bg-slate-900 hover:bg-slate-800 active:scale-95 text-white rounded-xl text-xs sm:text-sm font-bold shadow-md transition-all cursor-pointer border border-slate-700"
              title="Pindai plat tag QR aset mesin menggunakan kamera"
            >
              <Scan className="w-4 h-4 text-emerald-400" />
              <span>Scan QR Tag Aset</span>
            </button>
          )}

          {isAdmin && (
            <button
              onClick={() => setShowAddMachineModal(true)}
              className="flex items-center gap-1.5 px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 active:scale-95 text-white rounded-xl text-xs sm:text-sm font-bold shadow-md shadow-emerald-600/30 transition-all cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>Tambah Mesin Baru</span>
            </button>
          )}
        </div>
      </div>

      {/* Subtabs: Machines vs SOPs */}
      <div className="flex items-center gap-2 bg-white p-2 rounded-2xl border border-emerald-100 shadow-xs">
        <button
          onClick={() => setActiveSubTab('machines')}
          className={`flex items-center gap-2 px-5 py-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
            activeSubTab === 'machines'
              ? 'bg-emerald-600 text-white shadow-sm'
              : 'text-slate-600 hover:bg-emerald-50 hover:text-emerald-800'
          }`}
        >
          <Cpu className="w-4 h-4" />
          <span>Daftar 46 Unit Mesin Injeksi</span>
        </button>

        <button
          onClick={() => setActiveSubTab('sops')}
          className={`flex items-center gap-2 px-5 py-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
            activeSubTab === 'sops'
              ? 'bg-emerald-600 text-white shadow-sm'
              : 'text-slate-600 hover:bg-emerald-50 hover:text-emerald-800'
          }`}
        >
          <BookOpen className="w-4 h-4" />
          <span>Manual & Dokumen SOP ({sopDocuments.length} Dokumen)</span>
        </button>
      </div>

      {activeSubTab === 'machines' ? (
        <>
          {/* Filters Bar */}
          <div className="bg-white p-4 rounded-2xl border border-emerald-100 shadow-xs grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
            <div className="relative">
              <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Cari Merk, No. M/C, Tonase, Negara..."
                className="w-full pl-9 pr-4 py-2 rounded-xl border border-slate-200 text-xs focus:ring-2 focus:ring-emerald-500"
              />
            </div>

            <div>
              <select
                value={filterBrand}
                onChange={(e) => setFilterBrand(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs text-slate-700 bg-white"
              >
                <option value="all">Semua Merk Mesin</option>
                {distinctBrands.map((brand) => (
                  <option key={brand} value={brand}>
                    {brand}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <select
                value={filterMekanisme}
                onChange={(e) => setFilterMekanisme(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs text-slate-700 bg-white"
              >
                <option value="all">Semua Mekanisme</option>
                <option value="HYDROLIK">HYDROLIK</option>
                <option value="TOGGLE">TOGGLE</option>
              </select>
            </div>

            <div>
              <select
                value={filterStatus}
                onChange={(e) => setFilterStatus(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs text-slate-700 bg-white"
              >
                <option value="all">Semua Status Operasi</option>
                <option value="active">Aktif (Beroperasi Normal)</option>
                <option value="breakdown">Breakdown (Kerusakan)</option>
                <option value="maintenance">Maintenance (Servis PM)</option>
              </select>
            </div>
          </div>

          {/* Machine Table - Exact columns matching user's Image 1 */}
          <div className="bg-white rounded-3xl border border-emerald-100 shadow-xs overflow-hidden">
            <div className="p-4 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
              <span className="font-extrabold text-xs uppercase tracking-wider text-slate-700">
                Tabel Spesifikasi & Kartu Mesin Injeksi (Lampiran Data Departemen)
              </span>
              <span className="text-xs text-slate-500 font-semibold">
                Menampilkan {filteredMachines.length} Mesin
              </span>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-100/70 border-b border-slate-200 text-slate-600 uppercase tracking-wider font-extrabold text-[10px]">
                  <tr>
                    <th className="py-3.5 px-4">Nama M/C</th>
                    <th className="py-3.5 px-4 text-center">No M/C</th>
                    <th className="py-3.5 px-4 text-center">Tonase M/C</th>
                    <th className="py-3.5 px-4">Negara Asal</th>
                    <th className="py-3.5 px-4 text-center">Tahun Pembuatan</th>
                    <th className="py-3.5 px-4 text-center">Tahun Pembelian</th>
                    <th className="py-3.5 px-4 text-center">Usia Pemakaian</th>
                    <th className="py-3.5 px-4 text-center">Total Usia M/C</th>
                    <th className="py-3.5 px-4 text-center">Mekanisme</th>
                    <th className="py-3.5 px-4 text-center">Status</th>
                    <th className="py-3.5 px-4 text-center">Aksi</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {filteredMachines.map((m) => (
                    <tr
                      key={m.id}
                      onClick={() => setSelectedMachine(m)}
                      className={`hover:bg-emerald-50/50 transition-colors cursor-pointer ${
                        m.status === 'breakdown' ? 'bg-red-50/20' : ''
                      }`}
                    >
                      <td className="py-3 px-4 font-black text-slate-900 flex items-center gap-2">
                        <span>{m.name}</span>
                        {m.status === 'breakdown' && (
                          <span className="w-2 h-2 rounded-full bg-red-500 animate-ping"></span>
                        )}
                      </td>
                      <td className="py-3 px-4 text-center font-mono font-extrabold text-emerald-800 text-sm">
                        {m.noMc}
                      </td>
                      <td className="py-3 px-4 text-center font-bold text-slate-800">
                        {m.tonase}
                      </td>
                      <td className="py-3 px-4 text-slate-600 font-medium">
                        {m.negaraAsal}
                      </td>
                      <td className="py-3 px-4 text-center text-slate-500 font-mono">
                        {m.tahunPembuatan}
                      </td>
                      <td className="py-3 px-4 text-center text-slate-500 font-mono">
                        {m.tahunPembelian}
                      </td>
                      <td className="py-3 px-4 text-center font-semibold text-slate-700">
                        {m.usiaPemakaian} Tahun
                      </td>
                      <td className="py-3 px-4 text-center font-bold text-slate-900">
                        {m.totalUsia} Tahun
                      </td>
                      <td className="py-3 px-4 text-center">
                        <span
                          className={`text-[10px] font-bold px-2 py-0.5 rounded-md ${
                            m.mekanisme === 'HYDROLIK'
                              ? 'bg-blue-100 text-blue-800'
                              : 'bg-emerald-100 text-emerald-800'
                          }`}
                        >
                          {m.mekanisme}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-center">
                        <span
                          className={`text-[10px] font-bold px-2.5 py-0.5 rounded-full border ${getStatusBadge(
                            m.status
                          )}`}
                        >
                          {m.status === 'active'
                            ? 'Aktif'
                            : m.status === 'breakdown'
                            ? 'Breakdown'
                            : 'Maintenance'}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-center">
                        <div className="flex items-center justify-center gap-1.5">
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              setSelectedMachine(m);
                            }}
                            className="px-2.5 py-1 rounded-lg bg-emerald-50 text-emerald-700 hover:bg-emerald-100 font-bold text-[11px] flex items-center gap-1"
                          >
                            <History className="w-3 h-3" />
                            <span>Histori</span>
                          </button>
                          {isAdmin && (
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                if (confirm(`Hapus mesin ${m.name} No. ${m.noMc}?`)) {
                                  deleteMachine(m.id);
                                }
                              }}
                              className="p-1 rounded-lg text-slate-300 hover:text-red-600 hover:bg-red-50"
                              title="Hapus Mesin"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </>
      ) : (
        /* SOP Documents Section */
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {sopDocuments.map((sop) => (
            <div
              key={sop.id}
              className="bg-white rounded-3xl p-6 border border-emerald-100 shadow-xs hover:shadow-md transition-all flex flex-col justify-between"
            >
              <div>
                <div className="flex items-start justify-between gap-3 mb-3">
                  <div>
                    <span className="font-mono text-xs font-bold text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded-md">
                      {sop.code}
                    </span>
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-slate-100 text-slate-700 ml-2">
                      {sop.category}
                    </span>
                  </div>
                  <span className="text-[11px] font-mono text-slate-400">
                    {sop.version}
                  </span>
                </div>

                <h3 className="text-base font-extrabold text-slate-900 leading-snug">
                  {sop.title}
                </h3>

                <p className="text-xs text-slate-600 mt-2 leading-relaxed line-clamp-3">
                  {sop.description}
                </p>

                <div className="mt-4 pt-3 border-t border-slate-100 text-xs text-slate-500 space-y-1">
                  <div className="flex items-center justify-between">
                    <span>Target Alat: <strong>{sop.machineTarget}</strong></span>
                    <span>Ukuran: {sop.fileSize}</span>
                  </div>
                  <div>Penulis / Reviewer: {sop.author}</div>
                </div>
              </div>

              <div className="mt-6 pt-4 border-t border-slate-100 flex items-center justify-between">
                <span className="text-[11px] text-emerald-700 font-semibold">
                  Tersedia {sop.steps.length} Langkah Kerja
                </span>
                <button
                  onClick={() => setSelectedSOP(sop)}
                  className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 active:scale-95 text-white rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer shadow-sm shadow-emerald-600/20"
                >
                  <BookOpen className="w-3.5 h-3.5" />
                  <span>Baca Dokumen SOP</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* ASSET HISTORY CARD MODAL */}
      {selectedMachine && (
        <div className="fixed inset-0 bg-slate-900/60 z-50 flex items-center justify-center p-4 backdrop-blur-xs">
          <div className="bg-white rounded-3xl max-w-4xl w-full max-h-[92vh] overflow-y-auto shadow-2xl border border-slate-200">
            {/* Header with print button */}
            <div className="p-6 bg-gradient-to-r from-emerald-800 via-emerald-850 to-slate-900 text-white rounded-t-3xl flex items-start justify-between">
              <div>
                <div className="flex items-center gap-2 mb-2">
                  <span className="font-mono bg-white/20 px-2 py-0.5 rounded-md text-xs font-bold">
                    KARTU RIWAYAT ASET (ASSET HISTORY CARD)
                  </span>
                  <span
                    className={`text-[10px] font-bold px-2 py-0.5 rounded-md ${
                      selectedMachine.mekanisme === 'HYDROLIK'
                        ? 'bg-blue-400 text-slate-950'
                        : 'bg-emerald-400 text-slate-950'
                    }`}
                  >
                    {selectedMachine.mekanisme}
                  </span>
                </div>
                <h2 className="text-2xl font-extrabold text-white">
                  {selectedMachine.name} - Unit No. {selectedMachine.noMc} ({selectedMachine.tonase})
                </h2>
                <p className="text-emerald-200 text-xs mt-1">
                  Lokasi: {selectedMachine.lokasi} | Asal: {selectedMachine.negaraAsal}
                </p>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={handlePrint}
                  className="px-3 py-1.5 bg-white/10 hover:bg-white/20 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
                >
                  <Printer className="w-4 h-4" />
                  <span>Cetak Kartu</span>
                </button>
                <button
                  onClick={() => setSelectedMachine(null)}
                  className="text-emerald-200 hover:text-white p-1 rounded-lg text-lg font-bold"
                >
                  ✕
                </button>
              </div>
            </div>

            <div className="p-6 space-y-6 text-xs sm:text-sm">
              {/* Machine Specs Grid */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200">
                  <span className="text-[10px] text-slate-400 block uppercase font-bold">
                    Tahun Pembuatan
                  </span>
                  <span className="text-sm font-extrabold text-slate-900">
                    {selectedMachine.tahunPembuatan}
                  </span>
                </div>
                <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200">
                  <span className="text-[10px] text-slate-400 block uppercase font-bold">
                    Tahun Pembelian
                  </span>
                  <span className="text-sm font-extrabold text-slate-900">
                    {selectedMachine.tahunPembelian}
                  </span>
                </div>
                <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200">
                  <span className="text-[10px] text-slate-400 block uppercase font-bold">
                    Usia Pemakaian
                  </span>
                  <span className="text-sm font-extrabold text-slate-900">
                    {selectedMachine.usiaPemakaian} Tahun
                  </span>
                </div>
                <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200">
                  <span className="text-[10px] text-slate-400 block uppercase font-bold">
                    Total Usia Mesin
                  </span>
                  <span className="text-sm font-extrabold text-slate-900">
                    {selectedMachine.totalUsia} Tahun
                  </span>
                </div>
              </div>

              {/* Official QR Code Asset Tag Card */}
              {qrCodeDataUrl && (
                <div className="p-4 rounded-2xl bg-white border-2 border-emerald-100 shadow-xs flex flex-col sm:flex-row items-center justify-between gap-4">
                  <div className="flex items-center gap-4">
                    <div className="w-24 h-24 p-1.5 bg-white rounded-xl border border-slate-200 shrink-0 shadow-xs flex items-center justify-center">
                      <img
                        src={qrCodeDataUrl}
                        alt={`QR Tag MC-${selectedMachine.noMc}`}
                        className="w-full h-full object-contain"
                      />
                    </div>
                    <div>
                      <span className="text-[10px] uppercase font-bold tracking-wider text-emerald-800 bg-emerald-50 px-2.5 py-0.5 rounded-md inline-flex items-center gap-1">
                        <QrCode className="w-3 h-3" />
                        <span>Barcode / Plat Tag QR Mesin</span>
                      </span>
                      <h4 className="font-extrabold text-base text-slate-900 mt-1">
                        Tag ID: MC-{selectedMachine.noMc}
                      </h4>
                      <p className="text-xs text-slate-500 mt-0.5 leading-relaxed">
                        Pindai kode QR ini menggunakan kamera HP teknisi atau tombol <strong>Scan QR Aset</strong> untuk langsung membuka kartu histori mesin ini secara otomatis.
                      </p>
                    </div>
                  </div>

                  <button
                    onClick={handlePrint}
                    className="px-3.5 py-2 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 font-bold text-xs rounded-xl transition-colors flex items-center gap-1.5 shrink-0 cursor-pointer border border-emerald-200"
                  >
                    <Printer className="w-3.5 h-3.5" />
                    <span>Cetak Tag QR</span>
                  </button>
                </div>
              )}

              {/* Status Update Options (Admin Only) */}
              {isAdmin && (
                <div className="p-4 rounded-2xl bg-emerald-50/60 border border-emerald-200 flex items-center justify-between text-xs">
                  <div>
                    <span className="font-bold text-slate-900 block">
                      Ubah Status Operasional Mesin (Admin):
                    </span>
                    <span className="text-slate-500">
                      Mengubah status mesin akan menyinkronkan status produksi secara instan.
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    {(['active', 'breakdown', 'maintenance'] as MachineStatus[]).map((st) => (
                      <button
                        key={st}
                        onClick={() => {
                          updateMachine(selectedMachine.id, { status: st });
                          setSelectedMachine({ ...selectedMachine, status: st });
                        }}
                        className={`px-3 py-1.5 rounded-xl font-bold uppercase text-[10px] transition-all cursor-pointer ${
                          selectedMachine.status === st
                            ? 'bg-emerald-700 text-white shadow-sm'
                            : 'bg-white text-slate-700 border border-slate-200'
                        }`}
                      >
                        {st}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* History of Work Orders for this specific machine */}
              <div>
                <div className="flex items-center justify-between mb-2.5">
                  <h4 className="font-extrabold text-slate-900 text-sm flex items-center gap-2">
                    <History className="w-4 h-4 text-emerald-600" />
                    <span>Rekam Jejak Seluruh Perbaikan (Work Orders)</span>
                  </h4>
                  <span className="text-xs text-slate-500 font-semibold">
                    {
                      workOrders.filter(
                        (w) =>
                          w.machineId === selectedMachine.id ||
                          w.machineNo === selectedMachine.noMc
                      ).length
                    }{' '}
                    Tiket Tercatat
                  </span>
                </div>

                <div className="space-y-2.5 max-h-60 overflow-y-auto">
                  {workOrders
                    .filter(
                      (w) =>
                        w.machineId === selectedMachine.id ||
                        w.machineNo === selectedMachine.noMc
                    )
                    .map((wo) => (
                      <div
                        key={wo.id}
                        className="p-3.5 rounded-2xl border border-slate-200 bg-slate-50/60 text-xs flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                      >
                        <div>
                          <div className="flex items-center gap-2 mb-1">
                            <span className="font-mono font-bold text-emerald-800">
                              {wo.ticketNumber}
                            </span>
                            <span className="text-[10px] px-2 py-0.5 rounded-md bg-slate-200 font-semibold text-slate-700">
                              {wo.category}
                            </span>
                            <span className="text-[10px] px-2 py-0.5 rounded-md bg-emerald-100 text-emerald-800 font-bold">
                              {wo.status}
                            </span>
                          </div>
                          <div className="font-bold text-slate-900">{wo.title}</div>
                          <p className="text-slate-600 mt-1 text-[11px] leading-relaxed">
                            {wo.actionsTaken || wo.description}
                          </p>
                        </div>

                        <div className="text-right shrink-0">
                          <span className="text-slate-500 font-medium block">
                            Teknisi: {wo.assignedTechnician || '-'}
                          </span>
                          <span className="text-slate-400 text-[10px] block mt-0.5">
                            {wo.createdDate}
                          </span>
                        </div>
                      </div>
                    ))}
                </div>
              </div>

              {/* History of Spare Parts replaced on this machine */}
              <div>
                <h4 className="font-extrabold text-slate-900 text-sm mb-2.5 flex items-center gap-2">
                  <Package className="w-4 h-4 text-emerald-600" />
                  <span>Riwayat Suku Cadang & Heater yang Pernah Diganti</span>
                </h4>

                <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-slate-50 border-b border-slate-200 text-slate-500 uppercase font-bold text-[10px]">
                      <tr>
                        <th className="py-2.5 px-3">Tanggal</th>
                        <th className="py-2.5 px-3">Suku Cadang</th>
                        <th className="py-2.5 px-3">Jumlah</th>
                        <th className="py-2.5 px-3">Ref WO</th>
                        <th className="py-2.5 px-3">Keterangan</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {stockLogs
                        .filter((l) => l.machineNo === selectedMachine.noMc)
                        .map((l) => (
                          <tr key={l.id}>
                            <td className="py-2 px-3 font-mono text-slate-500">{l.date}</td>
                            <td className="py-2 px-3 font-bold text-slate-900">{l.partName}</td>
                            <td className="py-2 px-3 font-mono font-bold text-emerald-700">
                              {l.quantity} unit
                            </td>
                            <td className="py-2 px-3 font-mono text-slate-600">{l.referenceWO || '-'}</td>
                            <td className="py-2 px-3 text-slate-600 truncate max-w-xs">{l.notes}</td>
                          </tr>
                        ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* SOP VIEWER MODAL */}
      {selectedSOP && (
        <div className="fixed inset-0 bg-slate-900/60 z-50 flex items-center justify-center p-4 backdrop-blur-xs">
          <div className="bg-white rounded-3xl max-w-3xl w-full max-h-[92vh] overflow-y-auto shadow-2xl border border-slate-200">
            <div className="p-6 bg-gradient-to-r from-emerald-800 to-teal-800 text-white rounded-t-3xl flex items-start justify-between">
              <div>
                <span className="font-mono bg-white/20 px-2 py-0.5 rounded-md text-xs font-bold">
                  {selectedSOP.code}
                </span>
                <h3 className="text-xl font-extrabold text-white mt-1.5">
                  {selectedSOP.title}
                </h3>
                <p className="text-emerald-100 text-xs mt-1">
                  Kategori: {selectedSOP.category} | Penulis: {selectedSOP.author} ({selectedSOP.version})
                </p>
              </div>
              <button
                onClick={() => setSelectedSOP(null)}
                className="text-emerald-200 hover:text-white p-1 rounded-lg text-lg font-bold"
              >
                ✕
              </button>
            </div>

            <div className="p-6 space-y-6 text-xs sm:text-sm">
              <div className="p-4 rounded-2xl bg-emerald-50/50 border border-emerald-200 text-emerald-950">
                <span className="font-bold block mb-1">Tujuan & Lingkup SOP:</span>
                <p className="leading-relaxed text-xs">{selectedSOP.description}</p>
              </div>

              {/* SOP Steps */}
              <div className="space-y-4">
                <h4 className="font-extrabold text-slate-900 text-sm">
                  Langkah-Langkah Kerja Standar Operasional:
                </h4>

                {selectedSOP.steps.map((st) => (
                  <div
                    key={st.stepNo}
                    className="p-4 rounded-2xl border border-slate-200 bg-white space-y-2 shadow-2xs"
                  >
                    <div className="flex items-center gap-3">
                      <span className="w-7 h-7 rounded-xl bg-emerald-700 text-white font-black text-xs flex items-center justify-center">
                        {st.stepNo}
                      </span>
                      <h5 className="font-bold text-slate-900 text-xs sm:text-sm">
                        {st.title}
                      </h5>
                    </div>

                    <p className="text-slate-700 text-xs leading-relaxed pl-10">
                      {st.detail}
                    </p>

                    {st.warning && (
                      <div className="mt-2 ml-10 p-2.5 rounded-xl bg-amber-50 border border-amber-200 text-amber-800 text-[11px] font-semibold flex items-center gap-2">
                        <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0" />
                        <span>Peringatan K3: {st.warning}</span>
                      </div>
                    )}
                  </div>
                ))}
              </div>

              <div className="flex items-center justify-between pt-4 border-t border-slate-200">
                <button
                  onClick={handlePrint}
                  className="px-4 py-2 border border-slate-300 text-slate-700 rounded-xl text-xs font-semibold flex items-center gap-2 hover:bg-slate-50 cursor-pointer"
                >
                  <Printer className="w-4 h-4 text-emerald-700" />
                  <span>Cetak Lembar SOP</span>
                </button>
                <button
                  onClick={() => setSelectedSOP(null)}
                  className="px-5 py-2 bg-emerald-600 text-white rounded-xl text-xs font-bold hover:bg-emerald-700 cursor-pointer"
                >
                  Tutup Dokumen
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* CREATE NEW MACHINE MODAL (ADMIN ONLY) */}
      {showAddMachineModal && (
        <div className="fixed inset-0 bg-slate-900/60 z-50 flex items-center justify-center p-4 backdrop-blur-xs">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 shadow-2xl border border-slate-200 animate-fadeIn">
            <div className="flex items-center justify-between mb-4 pb-3 border-b border-slate-100">
              <h3 className="text-lg font-bold text-slate-900">
                Tambah Unit Mesin Injeksi Baru
              </h3>
              <button
                onClick={() => setShowAddMachineModal(false)}
                className="text-slate-400 hover:text-slate-600 font-bold"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleAddMachine} className="space-y-4 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Nama Merk Mesin <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    value={newName}
                    onChange={(e) => setNewName(e.target.value.toUpperCase())}
                    placeholder="Contoh: YIZUMI / NISSEI"
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-xs font-bold"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Nomor Mesin (No M/C) <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="number"
                    required
                    value={newNoMc}
                    onChange={(e) => setNewNoMc(parseInt(e.target.value) || 0)}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-xs font-bold font-mono"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Tonase Mesin (Tonase M/C):
                  </label>
                  <input
                    type="text"
                    value={newTonase}
                    onChange={(e) => setNewTonase(e.target.value)}
                    placeholder="Contoh: 260 Ton"
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-xs font-bold"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Negara Asal:
                  </label>
                  <input
                    type="text"
                    value={newNegara}
                    onChange={(e) => setNewNegara(e.target.value)}
                    placeholder="Jepang / China / Taiwan"
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-xs"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Tahun Pembuatan:
                  </label>
                  <input
                    type="number"
                    value={newTahunBuat}
                    onChange={(e) => setNewTahunBuat(parseInt(e.target.value) || 2020)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs font-mono"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Tahun Pembelian:
                  </label>
                  <input
                    type="number"
                    value={newTahunBeli}
                    onChange={(e) => setNewTahunBeli(parseInt(e.target.value) || 2020)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs font-mono"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Mekanisme Penguncian:
                  </label>
                  <select
                    value={newMekanisme}
                    onChange={(e) => setNewMekanisme(e.target.value as MekanismeType)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs bg-white font-bold"
                  >
                    <option value="TOGGLE">TOGGLE</option>
                    <option value="HYDROLIK">HYDROLIK</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Lokasi Bay / Line:
                  </label>
                  <input
                    type="text"
                    value={newLokasi}
                    onChange={(e) => setNewLokasi(e.target.value)}
                    placeholder="Bay 12 - Line Injeksi Baru"
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs"
                  />
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowAddMachineModal(false)}
                  className="px-4 py-2 border rounded-xl text-slate-600"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl shadow-md"
                >
                  Simpan Mesin
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
