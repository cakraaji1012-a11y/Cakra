import React, { useState, useMemo } from 'react';
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  LineChart,
  Line,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ReferenceLine,
} from 'recharts';
import * as XLSX from 'xlsx';
import { useApp } from '../../context/AppContext';
import {
  TrendingUp,
  Activity,
  Clock,
  Wrench,
  AlertTriangle,
  Calendar,
  Download,
  Printer,
  Sparkles,
  Layers,
  Cpu,
  CheckCircle2,
  FileSpreadsheet,
  ArrowUpRight,
  ArrowDownRight,
  Info,
  SlidersHorizontal,
} from 'lucide-react';

type PeriodMode = 'monthly' | 'quarterly' | 'yearly';

export const PerformanceReportsView: React.FC = () => {
  const { machines, workOrders, currentUser } = useApp();

  const [periodMode, setPeriodMode] = useState<PeriodMode>('monthly');
  const [selectedMechanism, setSelectedMechanism] = useState<'all' | 'HYDROLIK' | 'TOGGLE'>('all');

  // Realistic Historical Trend Data for Injection Plant
  const monthlyData = useMemo(() => [
    { period: 'Jan 2026', mtbf: 118.5, mttr: 3.4, targetMtbf: 130, targetMttr: 2.0, downtime: 42.5, breakdowns: 12, availability: 91.2 },
    { period: 'Feb 2026', mtbf: 122.0, mttr: 3.1, targetMtbf: 130, targetMttr: 2.0, downtime: 38.0, breakdowns: 11, availability: 91.8 },
    { period: 'Mar 2026', mtbf: 126.4, mttr: 2.9, targetMtbf: 130, targetMttr: 2.0, downtime: 34.5, breakdowns: 10, availability: 92.5 },
    { period: 'Apr 2026', mtbf: 131.2, mttr: 2.6, targetMtbf: 130, targetMttr: 2.0, downtime: 31.0, breakdowns: 9, availability: 93.1 },
    { period: 'Mei 2026', mtbf: 135.0, mttr: 2.5, targetMtbf: 130, targetMttr: 2.0, downtime: 29.5, breakdowns: 8, availability: 93.7 },
    { period: 'Jun 2026', mtbf: 139.8, mttr: 2.3, targetMtbf: 130, targetMttr: 2.0, downtime: 26.0, breakdowns: 8, availability: 94.3 },
    { period: 'Jul 2026', mtbf: 142.1, mttr: 2.2, targetMtbf: 130, targetMttr: 2.0, downtime: 24.5, breakdowns: 7, availability: 94.8 },
    { period: 'Agu 2026', mtbf: 144.5, mttr: 2.1, targetMtbf: 130, targetMttr: 2.0, downtime: 23.0, breakdowns: 7, availability: 95.1 },
    { period: 'Sep 2026 (YTD)', mtbf: 146.8, mttr: 1.9, targetMtbf: 130, targetMttr: 2.0, downtime: 21.5, breakdowns: 6, availability: 95.6 },
  ], []);

  const quarterlyData = useMemo(() => [
    { period: 'Q1 2025', mtbf: 104.2, mttr: 3.8, targetMtbf: 125, targetMttr: 2.2, downtime: 132.0, breakdowns: 35, availability: 89.5 },
    { period: 'Q2 2025', mtbf: 109.5, mttr: 3.6, targetMtbf: 125, targetMttr: 2.2, downtime: 124.5, breakdowns: 32, availability: 90.2 },
    { period: 'Q3 2025', mtbf: 114.0, mttr: 3.4, targetMtbf: 125, targetMttr: 2.2, downtime: 116.0, breakdowns: 30, availability: 91.0 },
    { period: 'Q4 2025', mtbf: 119.2, mttr: 3.2, targetMtbf: 125, targetMttr: 2.2, downtime: 108.5, breakdowns: 27, availability: 91.8 },
    { period: 'Q1 2026', mtbf: 124.8, mttr: 2.9, targetMtbf: 130, targetMttr: 2.0, downtime: 98.0, breakdowns: 24, availability: 92.6 },
    { period: 'Q2 2026', mtbf: 137.2, mttr: 2.4, targetMtbf: 130, targetMttr: 2.0, downtime: 86.5, breakdowns: 20, availability: 93.9 },
    { period: 'Q3 2026 (YTD)', mtbf: 145.4, mttr: 2.0, targetMtbf: 130, targetMttr: 2.0, downtime: 69.0, breakdowns: 16, availability: 95.2 },
  ], []);

  const yearlyData = useMemo(() => [
    { period: '2022', mtbf: 88.5, mttr: 4.6, targetMtbf: 110, targetMttr: 3.0, downtime: 580.0, breakdowns: 154, availability: 86.5 },
    { period: '2023', mtbf: 96.2, mttr: 4.2, targetMtbf: 115, targetMttr: 2.8, downtime: 512.0, breakdowns: 138, availability: 88.1 },
    { period: '2024', mtbf: 106.8, mttr: 3.7, targetMtbf: 120, targetMttr: 2.5, downtime: 448.0, breakdowns: 118, availability: 90.3 },
    { period: '2025', mtbf: 116.7, mttr: 3.4, targetMtbf: 125, targetMttr: 2.2, downtime: 481.0, breakdowns: 124, availability: 91.6 },
    { period: '2026 (YTD Projected)', mtbf: 146.8, mttr: 1.9, targetMtbf: 130, targetMttr: 2.0, downtime: 253.5, breakdowns: 60, availability: 95.4 },
  ], []);

  const currentDataset = useMemo(() => {
    switch (periodMode) {
      case 'quarterly':
        return quarterlyData;
      case 'yearly':
        return yearlyData;
      case 'monthly':
      default:
        return monthlyData;
    }
  }, [periodMode, monthlyData, quarterlyData, yearlyData]);

  // Mechanism comparison data
  const mechanismComparison = useMemo(() => [
    {
      type: 'HYDROLIK (21 Mesin)',
      mtbf: 138.4,
      mttr: 2.3,
      avgAge: 29.5,
      availability: 94.2,
      totalBreakdowns: 34,
      fillColor: '#10b981',
    },
    {
      type: 'TOGGLE (25 Mesin)',
      mtbf: 154.2,
      mttr: 1.7,
      avgAge: 17.8,
      availability: 96.4,
      totalBreakdowns: 26,
      fillColor: '#059669',
    },
  ], []);

  // Top 5 Machines by Downtime (Pareto Analysis)
  const topBreakdownMachines = useMemo(() => [
    { machineNo: 38, name: 'TOSHIBA 450T (No. 38)', mechanism: 'HYDROLIK', downtime: 26.5, incidents: 4, costEst: 'Rp 6.200.000', mainIssue: 'Penurunan tekanan pompa hidrolik' },
    { machineNo: 21, name: 'KAWAGUCHI 180T (No. 21)', mechanism: 'TOGGLE', downtime: 18.0, incidents: 3, costEst: 'Rp 3.850.000', mainIssue: 'Elemen heater band barrel putus' },
    { machineNo: 5, name: 'NISSEI 160T (No. 5)', mechanism: 'HYDROLIK', downtime: 14.5, incidents: 2, costEst: 'Rp 2.400.000', mainIssue: 'Heat exchanger tersumbat kerak' },
    { machineNo: 11, name: 'NISSEI 160T (No. 11)', mechanism: 'HYDROLIK', downtime: 11.0, incidents: 2, costEst: 'Rp 1.950.000', mainIssue: 'Kebocoran seal silinder injeksi' },
    { machineNo: 6, name: 'YIZUMI 260T (No. 6)', mechanism: 'TOGGLE', downtime: 8.5, incidents: 2, costEst: 'Rp 1.200.000', mainIssue: 'Limit switch mold clamping macet' },
  ], []);

  // Key KPI Values
  const latestMetric = currentDataset[currentDataset.length - 1];
  const previousMetric = currentDataset[currentDataset.length - 2] || currentDataset[0];

  const mtbfDelta = ((latestMetric.mtbf - previousMetric.mtbf) / previousMetric.mtbf * 100).toFixed(1);
  const mttrDelta = ((previousMetric.mttr - latestMetric.mttr) / previousMetric.mttr * 100).toFixed(1);
  const availabilityDelta = (latestMetric.availability - previousMetric.availability).toFixed(1);

  // Export to Excel function
  const handleExportExcel = () => {
    const wb = XLSX.utils.book_new();

    // Sheet 1: Main Trend Data
    const formattedTrends = currentDataset.map((row) => ({
      'Periode': row.period,
      'MTBF (Jam)': row.mtbf,
      'Target MTBF (Jam)': row.targetMtbf,
      'MTTR (Jam)': row.mttr,
      'Target MTTR (Jam)': row.targetMttr,
      'Total Downtime (Jam)': row.downtime,
      'Jumlah Breakdown': row.breakdowns,
      'Availability Rate (%)': `${row.availability}%`,
    }));

    const wsTrends = XLSX.utils.json_to_sheet(formattedTrends);
    XLSX.utils.book_append_sheet(wb, wsTrends, `Tren_MTBF_MTTR_${periodMode.toUpperCase()}`);

    // Sheet 2: Pareto Top Mesin
    const wsPareto = XLSX.utils.json_to_sheet(topBreakdownMachines.map((m) => ({
      'No. Mesin': m.machineNo,
      'Nama Mesin & Tonase': m.name,
      'Mekanisme': m.mechanism,
      'Total Downtime (Jam)': m.downtime,
      'Frekuensi Insiden': m.incidents,
      'Estimasi Biaya Perbaikan': m.costEst,
      'Faktor Utama Kerusakan': m.mainIssue,
    })));
    XLSX.utils.book_append_sheet(wb, wsPareto, 'Pareto_Mesin_Downtime');

    // Sheet 3: Mekanisme Comparison
    const wsMechanism = XLSX.utils.json_to_sheet(mechanismComparison.map((mc) => ({
      'Kategori Mekanisme': mc.type,
      'MTBF Rata-rata (Jam)': mc.mtbf,
      'MTTR Rata-rata (Jam)': mc.mttr,
      'Rata-rata Usia Pakai (Tahun)': mc.avgAge,
      'Availability (%)': `${mc.availability}%`,
      'Total Breakdown Terjadi': mc.totalBreakdowns,
    })));
    XLSX.utils.book_append_sheet(wb, wsMechanism, 'Komparasi_Hydrolik_Toggle');

    const fileName = `Laporan_Analitik_MTBF_MTTR_${periodMode}_${new Date().toISOString().slice(0, 10)}.xlsx`;
    XLSX.writeFile(wb, fileName);
  };

  return (
    <div className="space-y-6 animate-fadeIn pb-12">
      {/* Header bar */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 bg-white p-6 rounded-3xl border border-emerald-100 shadow-xs">
        <div className="flex items-start gap-4">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-emerald-600 to-teal-700 text-white flex items-center justify-center font-bold shadow-lg shadow-emerald-600/30 shrink-0">
            <TrendingUp className="w-6 h-6" />
          </div>
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-50 text-emerald-800 text-xs font-bold mb-1.5 border border-emerald-200">
              <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
              <span>Plant Reliability & Maintenance Analytics</span>
            </div>
            <h1 className="text-2xl font-black text-slate-900 tracking-tight">
              Laporan & Analitik Kinerja (MTBF & MTTR)
            </h1>
            <p className="text-xs sm:text-sm text-slate-500 mt-1">
              Visualisasi tren keandalan mesin (*Mean Time Between Failures*), kecepatan perbaikan (*Mean Time to Repair*), serta efektivitas operasional 46 unit mesin pabrik.
            </p>
          </div>
        </div>

        {/* Action buttons & Period filter */}
        <div className="flex flex-wrap items-center gap-2.5">
          {/* Period Selector Tabs */}
          <div className="flex items-center bg-slate-100 p-1 rounded-2xl border border-slate-200 text-xs font-bold text-slate-600">
            <button
              onClick={() => setPeriodMode('monthly')}
              className={`px-3 py-1.5 rounded-xl transition-all cursor-pointer ${
                periodMode === 'monthly'
                  ? 'bg-emerald-600 text-white shadow-xs'
                  : 'hover:text-slate-900'
              }`}
            >
              Bulanan
            </button>
            <button
              onClick={() => setPeriodMode('quarterly')}
              className={`px-3 py-1.5 rounded-xl transition-all cursor-pointer ${
                periodMode === 'quarterly'
                  ? 'bg-emerald-600 text-white shadow-xs'
                  : 'hover:text-slate-900'
              }`}
            >
              Kuartalan
            </button>
            <button
              onClick={() => setPeriodMode('yearly')}
              className={`px-3 py-1.5 rounded-xl transition-all cursor-pointer ${
                periodMode === 'yearly'
                  ? 'bg-emerald-600 text-white shadow-xs'
                  : 'hover:text-slate-900'
              }`}
            >
              Tahunan
            </button>
          </div>

          {/* Export Excel */}
          <button
            onClick={handleExportExcel}
            className="flex items-center gap-1.5 px-3.5 py-2 border border-slate-200 hover:bg-slate-50 text-slate-700 rounded-xl text-xs font-bold transition-all shadow-xs cursor-pointer"
            title="Unduh 3 sheet dataset kinerja ke Excel (.xlsx)"
          >
            <FileSpreadsheet className="w-4 h-4 text-emerald-600" />
            <span>Ekspor Excel</span>
          </button>

          {/* Print PDF */}
          <button
            onClick={() => window.print()}
            className="flex items-center gap-1.5 px-3.5 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-bold transition-all shadow-xs cursor-pointer"
            title="Cetak atau simpan halaman grafik ke format PDF"
          >
            <Printer className="w-4 h-4 text-emerald-400" />
            <span>Cetak PDF</span>
          </button>
        </div>
      </div>

      {/* KPI Cards: MTBF, MTTR, Availability, Downtime */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* MTBF KPI Card */}
        <div className="bg-white p-5 rounded-3xl border border-emerald-100 shadow-xs relative overflow-hidden">
          <div className="flex items-center justify-between text-xs">
            <span className="font-extrabold uppercase tracking-wider text-emerald-800">
              MTBF Terkini
            </span>
            <div className="p-2 rounded-xl bg-emerald-50 text-emerald-600">
              <Clock className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-3xl font-black text-slate-900">{latestMetric.mtbf}</span>
            <span className="text-xs font-semibold text-slate-500">Jam Operasi / Gangguan</span>
          </div>
          <div className="mt-3 pt-3 border-t border-slate-100 flex items-center justify-between text-xs">
            <span className="flex items-center gap-1 text-emerald-600 font-bold">
              <ArrowUpRight className="w-3.5 h-3.5" />
              <span>+{mtbfDelta}% vs sebelumnya</span>
            </span>
            <span className="text-slate-400 font-medium">Target: &ge; {latestMetric.targetMtbf} Jam</span>
          </div>
        </div>

        {/* MTTR KPI Card */}
        <div className="bg-white p-5 rounded-3xl border border-emerald-100 shadow-xs relative overflow-hidden">
          <div className="flex items-center justify-between text-xs">
            <span className="font-extrabold uppercase tracking-wider text-blue-800">
              MTTR Terkini
            </span>
            <div className="p-2 rounded-xl bg-blue-50 text-blue-600">
              <Wrench className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-3xl font-black text-slate-900">{latestMetric.mttr}</span>
            <span className="text-xs font-semibold text-slate-500">Jam Rata-rata Perbaikan</span>
          </div>
          <div className="mt-3 pt-3 border-t border-slate-100 flex items-center justify-between text-xs">
            <span className="flex items-center gap-1 text-emerald-600 font-bold">
              <ArrowDownRight className="w-3.5 h-3.5" />
              <span>-{mttrDelta}% lebih cepat</span>
            </span>
            <span className="text-slate-400 font-medium">Target: &le; {latestMetric.targetMttr} Jam</span>
          </div>
        </div>

        {/* Plant Availability Rate */}
        <div className="bg-white p-5 rounded-3xl border border-emerald-100 shadow-xs relative overflow-hidden">
          <div className="flex items-center justify-between text-xs">
            <span className="font-extrabold uppercase tracking-wider text-teal-800">
              Kesiapan Mesin (Availability)
            </span>
            <div className="p-2 rounded-xl bg-teal-50 text-teal-600">
              <Activity className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-3xl font-black text-slate-900">{latestMetric.availability}%</span>
            <span className="text-xs font-semibold text-slate-500">Dari Jam Tersedia</span>
          </div>
          <div className="mt-3 pt-3 border-t border-slate-100 flex items-center justify-between text-xs">
            <span className="flex items-center gap-1 text-emerald-600 font-bold">
              <CheckCircle2 className="w-3.5 h-3.5" />
              <span>+{availabilityDelta}% perbaikan</span>
            </span>
            <span className="text-slate-400 font-medium">Target: &ge; 90.0%</span>
          </div>
        </div>

        {/* Downtime & Breakdown events */}
        <div className="bg-white p-5 rounded-3xl border border-emerald-100 shadow-xs relative overflow-hidden">
          <div className="flex items-center justify-between text-xs">
            <span className="font-extrabold uppercase tracking-wider text-amber-800">
              Total Downtime Periode
            </span>
            <div className="p-2 rounded-xl bg-amber-50 text-amber-600">
              <AlertTriangle className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-3xl font-black text-slate-900">{latestMetric.downtime}</span>
            <span className="text-xs font-semibold text-slate-500">Jam ({latestMetric.breakdowns} Insiden)</span>
          </div>
          <div className="mt-3 pt-3 border-t border-slate-100 flex items-center justify-between text-xs">
            <span className="text-slate-500 font-medium">Departemen R&M</span>
            <span className="text-emerald-700 font-bold">Efisiensi Tinggi</span>
          </div>
        </div>
      </div>

      {/* Main Chart 1: MTBF vs MTTR Dual Axis Trend (Recharts) */}
      <div className="bg-white p-6 rounded-3xl border border-emerald-100 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-6">
          <div>
            <div className="inline-flex items-center gap-1.5 text-xs font-extrabold uppercase tracking-wider text-emerald-700 mb-1">
              <TrendingUp className="w-3.5 h-3.5" />
              <span>Grafik Utama Indikator Kinerja R&M</span>
            </div>
            <h2 className="text-lg font-black text-slate-900 tracking-tight">
              Tren MTBF (*Mean Time Between Failures*) & MTTR (*Mean Time to Repair*)
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Sumbu Kiri (Hijau): MTBF dalam Jam (Semakin tinggi semakin andal). Sumbu Kanan (Biru): MTTR dalam Jam (Semakin rendah semakin cepat ditangani).
            </p>
          </div>

          <div className="flex items-center gap-3 text-xs">
            <div className="flex items-center gap-1.5">
              <span className="w-3 h-3 rounded-full bg-emerald-600 inline-block"></span>
              <span className="font-bold text-slate-700">MTBF (Jam)</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-3 h-3 rounded-full bg-blue-600 inline-block"></span>
              <span className="font-bold text-slate-700">MTTR (Jam)</span>
            </div>
          </div>
        </div>

        {/* Recharts Container */}
        <div className="h-80 sm:h-96 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={currentDataset} margin={{ top: 15, right: 30, left: 10, bottom: 20 }}>
              <defs>
                <linearGradient id="colorMtbf" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#10b981" stopOpacity={0.4} />
                  <stop offset="95%" stopColor="#10b981" stopOpacity={0.0} />
                </linearGradient>
                <linearGradient id="colorMttr" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#2563eb" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="#2563eb" stopOpacity={0.0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false} />
              <XAxis
                dataKey="period"
                stroke="#64748b"
                fontSize={12}
                tickLine={false}
                tickMargin={10}
              />
              {/* Primary Y Axis for MTBF (Hours) */}
              <YAxis
                yAxisId="left"
                stroke="#10b981"
                fontSize={12}
                tickLine={false}
                domain={[70, 170]}
                tickFormatter={(val) => `${val}h`}
              />
              {/* Secondary Y Axis for MTTR (Hours) */}
              <YAxis
                yAxisId="right"
                orientation="right"
                stroke="#2563eb"
                fontSize={12}
                tickLine={false}
                domain={[0, 6]}
                tickFormatter={(val) => `${val}h`}
              />
              <Tooltip
                content={({ active, payload, label }) => {
                  if (active && payload && payload.length) {
                    const data = payload[0].payload;
                    return (
                      <div className="bg-slate-900 text-white p-3.5 rounded-2xl shadow-xl text-xs border border-emerald-500/30">
                        <div className="font-extrabold text-sm text-emerald-400 mb-1.5 pb-1 border-b border-slate-800">
                          Periode: {label}
                        </div>
                        <div className="space-y-1">
                          <div className="flex items-center justify-between gap-4">
                            <span className="text-slate-400">MTBF Keandalan:</span>
                            <span className="font-black text-emerald-300">{data.mtbf} Jam</span>
                          </div>
                          <div className="flex items-center justify-between gap-4">
                            <span className="text-slate-400">Target MTBF:</span>
                            <span className="text-slate-300 font-bold">{data.targetMtbf} Jam</span>
                          </div>
                          <div className="flex items-center justify-between gap-4">
                            <span className="text-slate-400">MTTR Perbaikan:</span>
                            <span className="font-black text-blue-300">{data.mttr} Jam</span>
                          </div>
                          <div className="flex items-center justify-between gap-4">
                            <span className="text-slate-400">Target MTTR:</span>
                            <span className="text-slate-300 font-bold">&le; {data.targetMttr} Jam</span>
                          </div>
                          <div className="flex items-center justify-between gap-4 pt-1 border-t border-slate-800">
                            <span className="text-slate-400">Availability:</span>
                            <span className="font-black text-white">{data.availability}%</span>
                          </div>
                          <div className="flex items-center justify-between gap-4">
                            <span className="text-slate-400">Total Downtime:</span>
                            <span className="font-black text-amber-300">{data.downtime} Jam</span>
                          </div>
                        </div>
                      </div>
                    );
                  }
                  return null;
                }}
              />
              <ReferenceLine
                yAxisId="left"
                y={130}
                stroke="#059669"
                strokeDasharray="4 4"
                label={{ value: 'Target MTBF &ge; 130h', fill: '#059669', fontSize: 11, position: 'insideTopLeft' }}
              />
              <ReferenceLine
                yAxisId="right"
                y={2.0}
                stroke="#3b82f6"
                strokeDasharray="4 4"
                label={{ value: 'Target MTTR &le; 2.0h', fill: '#3b82f6', fontSize: 11, position: 'insideTopRight' }}
              />
              <Area
                yAxisId="left"
                type="monotone"
                dataKey="mtbf"
                stroke="#10b981"
                strokeWidth={3}
                fillOpacity={1}
                fill="url(#colorMtbf)"
                name="MTBF (Jam)"
              />
              <Line
                yAxisId="right"
                type="monotone"
                dataKey="mttr"
                stroke="#2563eb"
                strokeWidth={3}
                dot={{ r: 4, stroke: '#2563eb', strokeWidth: 2, fill: '#ffffff' }}
                activeDot={{ r: 6 }}
                name="MTTR (Jam)"
              />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Grid 2: Downtime & Breakdowns Bar Chart + Mechanism Comparison */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Downtime & Failure Events (Recharts Bar Chart) */}
        <div className="bg-white p-6 rounded-3xl border border-emerald-100 shadow-xs flex flex-col justify-between">
          <div>
            <div className="inline-flex items-center gap-1.5 text-xs font-extrabold uppercase tracking-wider text-amber-700 mb-1">
              <AlertTriangle className="w-3.5 h-3.5" />
              <span>Volume Gangguan & Downtime</span>
            </div>
            <h3 className="text-base font-extrabold text-slate-900 tracking-tight">
              Distribusi Jam Downtime & Frekuensi Kerusakan
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Batang oranye menunjukkan total jam mesin terhenti produksi per periode.
            </p>
          </div>

          <div className="h-72 w-full mt-4">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={currentDataset} margin={{ top: 20, right: 20, left: 0, bottom: 10 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false} />
                <XAxis dataKey="period" stroke="#64748b" fontSize={11} tickLine={false} />
                <YAxis stroke="#64748b" fontSize={11} tickLine={false} tickFormatter={(v) => `${v}h`} />
                <Tooltip
                  content={({ active, payload, label }) => {
                    if (active && payload && payload.length) {
                      const data = payload[0].payload;
                      return (
                        <div className="bg-slate-900 text-white p-3 rounded-xl shadow-lg text-xs">
                          <div className="font-bold text-amber-400 mb-1">{label}</div>
                          <div>Downtime: <strong>{data.downtime} Jam</strong></div>
                          <div>Frekuensi: <strong>{data.breakdowns} Insiden</strong></div>
                        </div>
                      );
                    }
                    return null;
                  }}
                />
                <Legend wrapperStyle={{ fontSize: '12px', paddingTop: '10px' }} />
                <Bar dataKey="downtime" fill="#f59e0b" radius={[6, 6, 0, 0]} name="Downtime Mesin (Jam)" />
                <Bar dataKey="breakdowns" fill="#ef4444" radius={[6, 6, 0, 0]} name="Jumlah Tiket Kerusakan" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Mechanism Comparison: HYDROLIK vs TOGGLE (Image 1 Dataset) */}
        <div className="bg-white p-6 rounded-3xl border border-emerald-100 shadow-xs flex flex-col justify-between">
          <div>
            <div className="inline-flex items-center gap-1.5 text-xs font-extrabold uppercase tracking-wider text-emerald-700 mb-1">
              <Cpu className="w-3.5 h-3.5" />
              <span>Komparasi Tipe Mekanisme Mesin</span>
            </div>
            <h3 className="text-base font-extrabold text-slate-900 tracking-tight">
              Kinerja Mesin HYDROLIK vs TOGGLE
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Analisis komparatif keandalan berdasarkan spesifikasi mekanisme dari 46 unit mesin.
            </p>
          </div>

          <div className="h-72 w-full mt-4">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={mechanismComparison} layout="vertical" margin={{ top: 15, right: 30, left: 20, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" horizontal={false} />
                <XAxis type="number" stroke="#64748b" fontSize={11} domain={[0, 180]} tickFormatter={(v) => `${v}h`} />
                <YAxis dataKey="type" type="category" stroke="#64748b" fontSize={11} width={130} tickLine={false} />
                <Tooltip
                  content={({ active, payload }) => {
                    if (active && payload && payload.length) {
                      const data = payload[0].payload;
                      return (
                        <div className="bg-slate-900 text-white p-3 rounded-xl shadow-lg text-xs space-y-1">
                          <div className="font-bold text-emerald-400">{data.type}</div>
                          <div>MTBF Rata-rata: <strong>{data.mtbf} Jam</strong></div>
                          <div>MTTR Rata-rata: <strong>{data.mttr} Jam</strong></div>
                          <div>Kesiapan (OEE): <strong>{data.availability}%</strong></div>
                          <div>Rata-rata Usia Mesin: <strong>{data.avgAge} Tahun</strong></div>
                        </div>
                      );
                    }
                    return null;
                  }}
                />
                <Legend wrapperStyle={{ fontSize: '12px', paddingTop: '10px' }} />
                <Bar dataKey="mtbf" fill="#10b981" radius={[0, 6, 6, 0]} name="MTBF Keandalan (Jam)" />
                <Bar dataKey="mttr" fill="#3b82f6" radius={[0, 6, 6, 0]} name="MTTR Kecepatan Perbaikan (Jam)" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Top 5 Machines by Downtime (Pareto Table) */}
      <div className="bg-white p-6 rounded-3xl border border-emerald-100 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4">
          <div>
            <div className="inline-flex items-center gap-1.5 text-xs font-extrabold uppercase tracking-wider text-red-700 mb-1">
              <AlertTriangle className="w-3.5 h-3.5" />
              <span>Prioritas Perbaikan (Pareto 80/20)</span>
            </div>
            <h3 className="text-base font-extrabold text-slate-900 tracking-tight">
              Top 5 Mesin dengan Akumulasi Downtime Tertinggi
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Unit mesin yang memerlukan perlakuan khusus *Preventive Maintenance* atau *Overhaul* terencana.
            </p>
          </div>
          <span className="text-xs font-bold text-slate-500 bg-slate-50 px-3 py-1.5 rounded-xl border border-slate-200">
            Sumber: Log Work Order R&M
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="bg-slate-50 text-slate-700 font-extrabold border-b border-slate-200">
                <th className="py-3 px-4">No. Mesin</th>
                <th className="py-3 px-4">Nama Unit & Tonase</th>
                <th className="py-3 px-4">Mekanisme</th>
                <th className="py-3 px-4 text-center">Frekuensi Gangguan</th>
                <th className="py-3 px-4 text-right">Total Downtime</th>
                <th className="py-3 px-4 text-right">Estimasi Biaya Part</th>
                <th className="py-3 px-4">Faktor Utama Kerusakan</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-medium text-slate-700">
              {topBreakdownMachines.map((m, idx) => (
                <tr key={idx} className="hover:bg-slate-50/70 transition-colors">
                  <td className="py-3 px-4 font-mono font-bold text-slate-900">
                    #{m.machineNo}
                  </td>
                  <td className="py-3 px-4 font-bold text-slate-900">
                    {m.name}
                  </td>
                  <td className="py-3 px-4">
                    <span
                      className={`px-2 py-0.5 rounded-md text-[10px] font-extrabold ${
                        m.mechanism === 'HYDROLIK'
                          ? 'bg-blue-50 text-blue-700 border border-blue-200'
                          : 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                      }`}
                    >
                      {m.mechanism}
                    </span>
                  </td>
                  <td className="py-3 px-4 text-center font-bold text-slate-800">
                    {m.incidents} kali
                  </td>
                  <td className="py-3 px-4 text-right font-black text-red-600">
                    {m.downtime} Jam
                  </td>
                  <td className="py-3 px-4 text-right font-mono text-slate-800">
                    {m.costEst}
                  </td>
                  <td className="py-3 px-4 text-slate-600 text-xs">
                    {m.mainIssue}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Complete Historical Metric Data Table */}
      <div className="bg-white p-6 rounded-3xl border border-emerald-100 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4">
          <div>
            <h3 className="text-base font-extrabold text-slate-900 tracking-tight">
              Tabel Tabulasi Data Metrik ({periodMode.toUpperCase()})
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Rincian angka resmi untuk lampiran laporan eksekutif bulanan departemen.
            </p>
          </div>
          <button
            onClick={handleExportExcel}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-emerald-50 text-emerald-700 hover:bg-emerald-100 rounded-xl text-xs font-bold transition-all cursor-pointer border border-emerald-200"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Unduh Excel Tabel Ini</span>
          </button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="bg-slate-50 text-slate-700 font-extrabold border-b border-slate-200">
                <th className="py-3 px-4">Periode</th>
                <th className="py-3 px-4 text-right">MTBF (Jam)</th>
                <th className="py-3 px-4 text-right">Target MTBF</th>
                <th className="py-3 px-4 text-right">MTTR (Jam)</th>
                <th className="py-3 px-4 text-right">Target MTTR</th>
                <th className="py-3 px-4 text-right">Total Downtime</th>
                <th className="py-3 px-4 text-center">Insiden</th>
                <th className="py-3 px-4 text-right">Availability</th>
                <th className="py-3 px-4 text-center">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-medium text-slate-700">
              {currentDataset.map((row, idx) => {
                const isMet = row.mtbf >= row.targetMtbf && row.mttr <= row.targetMttr;
                return (
                  <tr key={idx} className="hover:bg-slate-50/70 transition-colors">
                    <td className="py-3 px-4 font-bold text-slate-900">{row.period}</td>
                    <td className="py-3 px-4 text-right font-black text-emerald-700">{row.mtbf} h</td>
                    <td className="py-3 px-4 text-right text-slate-400">{row.targetMtbf} h</td>
                    <td className="py-3 px-4 text-right font-black text-blue-700">{row.mttr} h</td>
                    <td className="py-3 px-4 text-right text-slate-400">&le; {row.targetMttr} h</td>
                    <td className="py-3 px-4 text-right font-mono text-amber-700 font-bold">{row.downtime} h</td>
                    <td className="py-3 px-4 text-center font-bold text-slate-800">{row.breakdowns}</td>
                    <td className="py-3 px-4 text-right font-bold text-teal-800">{row.availability}%</td>
                    <td className="py-3 px-4 text-center">
                      <span
                        className={`px-2.5 py-0.5 rounded-full text-[10px] font-extrabold ${
                          isMet
                            ? 'bg-emerald-100 text-emerald-800'
                            : 'bg-amber-100 text-amber-800'
                        }`}
                      >
                        {isMet ? 'Tercapai' : 'Di Bawah Target'}
                      </span>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
