import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Activity,
  AlertTriangle,
  CheckCircle2,
  Clock,
  Cpu,
  Wrench,
  Boxes,
  Calendar,
  ArrowUpRight,
  TrendingDown,
  TrendingUp,
  AlertOctagon,
  ShieldAlert,
  ArrowRight,
  Layers,
  ChevronRight,
  Sparkles,
  Scan,
  UserCheck,
} from 'lucide-react';

interface DashboardViewProps {
  onOpenNewTicket: () => void;
  onOpenQRScanner?: () => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  onOpenNewTicket,
  onOpenQRScanner,
}) => {
  const {
    machines,
    workOrders,
    spareParts,
    pmTasks,
    setActiveTab,
    currentUser,
  } = useApp();

  const [timeframe, setTimeframe] = useState<'month' | 'quarter' | 'year'>('month');

  // Asset Status Calculation
  const totalMachines = machines.length;
  const activeMachines = machines.filter((m) => m.status === 'active').length;
  const breakdownMachines = machines.filter((m) => m.status === 'breakdown').length;
  const maintenanceMachines = machines.filter((m) => m.status === 'maintenance').length;
  const availabilityRate = ((activeMachines / totalMachines) * 100).toFixed(1);

  // Performance KPI
  const closedWOs = workOrders.filter((w) => w.status === 'Closed');
  const openWOs = workOrders.filter((w) => w.status !== 'Closed');
  const emergencyWOs = workOrders.filter(
    (w) => w.urgency === 'Emergency' && w.status !== 'Closed'
  );

  // Calculated MTTR: total downtime hours / count of breakdowns
  const totalDowntime = closedWOs.reduce(
    (acc, curr) => acc + (curr.downtimeHours || 0),
    0
  );
  const avgMTTR = closedWOs.length > 0 ? (totalDowntime / closedWOs.length).toFixed(1) : '2.1';
  // Standard simulated plant MTBF (Hours)
  const simulatedMTBF = 146.8;

  // Low stock items
  const lowStockParts = spareParts.filter((p) => p.currentStock <= p.minStock);

  // Overdue or upcoming PM
  const upcomingPM = pmTasks.filter((pm) => pm.status === 'Scheduled');

  // Breakdown by Mechanism
  const hydrolikCount = machines.filter((m) => m.mekanisme === 'HYDROLIK').length;
  const toggleCount = machines.filter((m) => m.mekanisme === 'TOGGLE').length;

  const myAssignedTasks = workOrders.filter((w) => {
    if (!currentUser?.name) return false;
    const currentName = currentUser.name.toLowerCase();
    const assigned = (w.assignedTechnician || '').toLowerCase();
    return (
      w.status !== 'Closed' &&
      (assigned.includes(currentName) ||
        currentName.includes(assigned) ||
        (assigned.includes('agus') && currentName.includes('agus')) ||
        (assigned.includes('budi') && currentName.includes('budi')))
    );
  });

  return (
    <div className="space-y-6">
      {/* Welcome Banner */}
      <div className="bg-gradient-to-r from-emerald-800 via-emerald-700 to-teal-800 rounded-3xl p-6 sm:p-8 text-white relative overflow-hidden shadow-lg shadow-emerald-950/10">
        <div className="absolute right-0 top-0 w-96 h-96 bg-white/10 rounded-full blur-3xl pointer-events-none -mr-20 -mt-20"></div>

        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="max-w-2xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/15 backdrop-blur-md text-emerald-200 text-xs font-semibold mb-3 border border-white/10">
              <Sparkles className="w-3.5 h-3.5 text-emerald-300" />
              <span>Plant Injection Moulding Division</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
              Ringkasan Eksekutif Pemeliharaan & Aset
            </h1>
            <p className="text-emerald-100 text-xs sm:text-sm mt-2 leading-relaxed">
              Halo, <strong>{currentUser?.name}</strong> ({currentUser?.position}). Status operasional
              46 mesin injeksi dan kartu inventaris terpantau secara real-time.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <button
              onClick={() => setActiveTab('my-tasks')}
              className="px-4 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl font-bold text-xs sm:text-sm border border-emerald-400/40 shadow-sm transition-all active:scale-95 flex items-center gap-2 cursor-pointer"
            >
              <UserCheck className="w-4 h-4 text-emerald-200" />
              <span>Tugas Saya ({myAssignedTasks.length})</span>
            </button>
            {onOpenQRScanner && (
              <button
                onClick={onOpenQRScanner}
                className="px-4 py-2.5 bg-emerald-950/70 hover:bg-emerald-950 text-white rounded-xl font-bold text-xs sm:text-sm border border-emerald-400/40 shadow-sm transition-all active:scale-95 flex items-center gap-2 cursor-pointer"
                title="Pindai plat tag QR aset mesin menggunakan kamera"
              >
                <Scan className="w-4 h-4 text-emerald-400" />
                <span>Scan QR Mesin</span>
              </button>
            )}
            <button
              onClick={onOpenNewTicket}
              className="px-4 py-2.5 bg-white text-emerald-800 hover:bg-emerald-50 rounded-xl font-bold text-xs sm:text-sm shadow-md transition-all active:scale-95 flex items-center gap-2 cursor-pointer"
            >
              <Wrench className="w-4 h-4 text-emerald-700" />
              <span>Buat Tiket Perbaikan</span>
            </button>
            <button
              onClick={() => setActiveTab('inventory')}
              className="px-4 py-2.5 bg-emerald-900/50 hover:bg-emerald-900/80 text-white rounded-xl font-bold text-xs sm:text-sm border border-emerald-400/30 transition-all flex items-center gap-2 cursor-pointer"
            >
              <Boxes className="w-4 h-4 text-emerald-300" />
              <span>Cek Stok Suku Cadang</span>
            </button>
          </div>
        </div>
      </div>

      {/* Critical Emergency Banner if any */}
      {emergencyWOs.length > 0 && (
        <div className="p-4 sm:p-5 rounded-2xl bg-red-50 border-2 border-red-300 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-4 animate-pulse">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-red-600 text-white flex items-center justify-center shrink-0 shadow-md shadow-red-600/30">
              <AlertOctagon className="w-6 h-6" />
            </div>
            <div>
              <div className="text-xs uppercase font-extrabold tracking-wider text-red-700">
                Peringatan Darurat ({emergencyWOs.length} Tiket Emergency Terbuka)
              </div>
              <div className="text-sm font-bold text-slate-900 mt-0.5">
                {emergencyWOs[0].ticketNumber}: {emergencyWOs[0].machineName} - {emergencyWOs[0].title}
              </div>
            </div>
          </div>
          <button
            onClick={() => setActiveTab('work-orders')}
            className="px-4 py-2 bg-red-600 hover:bg-red-700 text-white text-xs font-bold rounded-xl transition-all flex items-center justify-center gap-2 shrink-0 cursor-pointer shadow-sm"
          >
            <span>Buka Tiket Darurat</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* 1. Status Aset & KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Mesin Aktif */}
        <div className="bg-white rounded-2xl p-5 border border-emerald-100 shadow-xs hover:shadow-md transition-shadow">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-400">
              Status Mesin Aktif
            </span>
            <span className="p-2 rounded-xl bg-emerald-50 text-emerald-600">
              <Cpu className="w-4 h-4" />
            </span>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-3xl font-extrabold text-slate-900">{activeMachines}</span>
            <span className="text-xs text-slate-400 font-medium">/ {totalMachines} Mesin</span>
          </div>
          <div className="mt-3 flex items-center justify-between text-xs pt-3 border-t border-slate-100">
            <span className="text-emerald-700 font-bold flex items-center gap-1">
              <CheckCircle2 className="w-3.5 h-3.5" />
              <span>{availabilityRate}% OEE Kesiapan</span>
            </span>
            <span className="text-slate-400">Target: &gt;90%</span>
          </div>
        </div>

        {/* Mesin Rusak / Breakdown */}
        <div className="bg-white rounded-2xl p-5 border border-red-100 shadow-xs hover:shadow-md transition-shadow">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-400">
              Kerusakan / Breakdown
            </span>
            <span className="p-2 rounded-xl bg-red-50 text-red-600">
              <AlertTriangle className="w-4 h-4" />
            </span>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-3xl font-extrabold text-red-600">{breakdownMachines}</span>
            <span className="text-xs text-slate-400 font-medium">Unit Henti Produksi</span>
          </div>
          <div className="mt-3 flex items-center justify-between text-xs pt-3 border-t border-slate-100">
            <span className="text-slate-600 font-medium">
              Maintenance:{' '}
              <strong className="text-amber-600">{maintenanceMachines} Unit</strong>
            </span>
            <button
              onClick={() => setActiveTab('assets')}
              className="text-xs text-emerald-700 font-bold hover:underline cursor-pointer"
            >
              Lihat Unit
            </button>
          </div>
        </div>

        {/* MTBF Indicator */}
        <div className="bg-white rounded-2xl p-5 border border-emerald-100 shadow-xs hover:shadow-md transition-shadow">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-400">
              MTBF (Keandalan)
            </span>
            <span className="p-2 rounded-xl bg-teal-50 text-teal-600">
              <Activity className="w-4 h-4" />
            </span>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-3xl font-extrabold text-slate-900">{simulatedMTBF}</span>
            <span className="text-xs text-slate-400 font-medium">Jam / Gangguan</span>
          </div>
          <div className="mt-3 flex items-center justify-between text-xs pt-3 border-t border-slate-100">
            <span className="text-emerald-700 font-bold flex items-center gap-1">
              <TrendingUp className="w-3.5 h-3.5" />
              <span>+12.4% vs bln lalu</span>
            </span>
            <span className="text-slate-400">Mean Time Between Failures</span>
          </div>
        </div>

        {/* MTTR Indicator */}
        <div className="bg-white rounded-2xl p-5 border border-emerald-100 shadow-xs hover:shadow-md transition-shadow">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-400">
              MTTR (Kecepatan Perbaikan)
            </span>
            <span className="p-2 rounded-xl bg-blue-50 text-blue-600">
              <Clock className="w-4 h-4" />
            </span>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-3xl font-extrabold text-slate-900">{avgMTTR}</span>
            <span className="text-xs text-slate-400 font-medium">Jam Rata-rata</span>
          </div>
          <div className="mt-3 flex items-center justify-between text-xs pt-3 border-t border-slate-100">
            <span className="text-emerald-700 font-bold flex items-center gap-1">
              <TrendingDown className="w-3.5 h-3.5" />
              <span>-0.8 Jam (Lebih Cepat)</span>
            </span>
            <span className="text-slate-400">Mean Time To Repair</span>
          </div>
        </div>
      </div>

      {/* 2. Visual Charts & Trend Performance */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Main Performance Graph: MTBF & MTTR Trend */}
        <div className="lg:col-span-8 bg-white rounded-3xl p-6 border border-emerald-100 shadow-xs">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-6">
            <div>
              <h2 className="text-base sm:text-lg font-bold text-slate-900">
                Grafik Kinerja Pemeliharaan (MTBF vs MTTR)
              </h2>
              <p className="text-xs text-slate-500">
                Rasio keandalan mesin injeksi dan efisiensi waktu penanganan teknisi
              </p>
            </div>
            <div className="flex flex-wrap items-center gap-2">
              <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-xl text-xs font-semibold text-slate-600">
                <button
                  onClick={() => setTimeframe('month')}
                  className={`px-3 py-1 rounded-lg transition-colors cursor-pointer ${
                    timeframe === 'month'
                      ? 'bg-white text-emerald-800 shadow-xs font-bold'
                      : 'hover:text-slate-900'
                  }`}
                >
                  6 Bulan
                </button>
                <button
                  onClick={() => setTimeframe('quarter')}
                  className={`px-3 py-1 rounded-lg transition-colors cursor-pointer ${
                    timeframe === 'quarter'
                      ? 'bg-white text-emerald-800 shadow-xs font-bold'
                      : 'hover:text-slate-900'
                  }`}
                >
                  Kuartal
                </button>
                <button
                  onClick={() => setTimeframe('year')}
                  className={`px-3 py-1 rounded-lg transition-colors cursor-pointer ${
                    timeframe === 'year'
                      ? 'bg-white text-emerald-800 shadow-xs font-bold'
                      : 'hover:text-slate-900'
                  }`}
                >
                  Tahunan
                </button>
              </div>

              <button
                onClick={() => setActiveTab('reports')}
                className="flex items-center gap-1.5 px-3 py-1.5 bg-emerald-50 text-emerald-800 hover:bg-emerald-100 rounded-xl text-xs font-bold transition-all border border-emerald-200 cursor-pointer"
                title="Buka Tab Khusus Visualisasi Analitik Recharts"
              >
                <span>Analitik Tren Lengkap</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {/* Bar Chart Presentation */}
          <div className="space-y-4">
            {[
              { month: 'Apr 2026', mtbf: 124, mttr: 3.2, woClosed: 14, rate: 88 },
              { month: 'Mei 2026', mtbf: 130, mttr: 2.8, woClosed: 11, rate: 91 },
              { month: 'Jun 2026', mtbf: 138, mttr: 2.6, woClosed: 9, rate: 92 },
              { month: 'Jul 2026', mtbf: 142, mttr: 2.4, woClosed: 8, rate: 93 },
              { month: 'Agt 2026', mtbf: 140, mttr: 2.5, woClosed: 12, rate: 90 },
              { month: 'Sep 2026 (Aktif)', mtbf: 148, mttr: 2.1, woClosed: 16, rate: 94 },
            ].map((row, idx) => (
              <div key={idx} className="p-3 rounded-2xl bg-slate-50/70 hover:bg-emerald-50/40 transition-colors border border-slate-100">
                <div className="flex items-center justify-between text-xs mb-2">
                  <span className="font-bold text-slate-800">{row.month}</span>
                  <div className="flex items-center gap-4 text-slate-600">
                    <span>
                      MTBF: <strong className="text-emerald-700">{row.mtbf} Jam</strong>
                    </span>
                    <span>
                      MTTR: <strong className="text-blue-700">{row.mttr} Jam</strong>
                    </span>
                    <span className="font-semibold text-slate-800">
                      WO Tuntas: {row.woClosed}
                    </span>
                  </div>
                </div>

                <div className="grid grid-cols-12 gap-2 items-center">
                  <div className="col-span-12 flex h-3.5 rounded-full overflow-hidden bg-slate-200 gap-1 p-0.5">
                    {/* MTBF segment */}
                    <div
                      style={{ width: `${(row.mtbf / 180) * 80}%` }}
                      className="bg-emerald-600 rounded-full h-full"
                      title={`MTBF: ${row.mtbf} Jam`}
                    ></div>
                    {/* MTTR bar */}
                    <div
                      style={{ width: `${(row.mttr / 5) * 20}%` }}
                      className="bg-blue-500 rounded-full h-full"
                      title={`MTTR: ${row.mttr} Jam`}
                    ></div>
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div className="flex items-center justify-between mt-6 pt-4 border-t border-slate-100 text-xs text-slate-500">
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-1.5">
                <span className="w-3 h-3 rounded-md bg-emerald-600"></span>
                <span>MTBF (Semakin tinggi semakin andal)</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="w-3 h-3 rounded-md bg-blue-500"></span>
                <span>MTTR (Semakin rendah semakin gesit)</span>
              </div>
            </div>
            <span className="text-[11px] text-slate-400">Standar ISO 55001 Maintenance</span>
          </div>
        </div>

        {/* Mechanism & Equipment Distribution */}
        <div className="lg:col-span-4 bg-white rounded-3xl p-6 border border-emerald-100 shadow-xs flex flex-col justify-between">
          <div>
            <h2 className="text-base sm:text-lg font-bold text-slate-900 mb-1">
              Komposisi 46 Mesin Injeksi
            </h2>
            <p className="text-xs text-slate-500 mb-6">
              Distribusi mekanisme penguncian & tonase
            </p>

            <div className="space-y-4">
              {/* Hydrolik vs Toggle */}
              <div className="p-4 rounded-2xl bg-emerald-50/70 border border-emerald-200/60">
                <div className="flex items-center justify-between text-xs font-bold mb-2">
                  <span className="text-emerald-900">Mekanisme Hydrolik</span>
                  <span className="text-emerald-700">{hydrolikCount} Mesin ({((hydrolikCount / totalMachines) * 100).toFixed(0)}%)</span>
                </div>
                <div className="w-full bg-emerald-200/60 h-2.5 rounded-full overflow-hidden">
                  <div
                    style={{ width: `${(hydrolikCount / totalMachines) * 100}%` }}
                    className="bg-emerald-600 h-full rounded-full"
                  ></div>
                </div>
                <p className="text-[11px] text-emerald-800/80 mt-2">
                  Toshiba, Nissei (Akumulator, Servo Valve & Piston)
                </p>
              </div>

              <div className="p-4 rounded-2xl bg-teal-50/70 border border-teal-200/60">
                <div className="flex items-center justify-between text-xs font-bold mb-2">
                  <span className="text-teal-900">Mekanisme Toggle</span>
                  <span className="text-teal-700">{toggleCount} Mesin ({((toggleCount / totalMachines) * 100).toFixed(0)}%)</span>
                </div>
                <div className="w-full bg-teal-200/60 h-2.5 rounded-full overflow-hidden">
                  <div
                    style={{ width: `${(toggleCount / totalMachines) * 100}%` }}
                    className="bg-teal-600 h-full rounded-full"
                  ></div>
                </div>
                <p className="text-[11px] text-teal-800/80 mt-2">
                  Yizumi, Kawaguchi, Accel, Cosmo, Top's (Toggle pin lubrication)
                </p>
              </div>

              {/* Tonase Distribution */}
              <div className="pt-2">
                <div className="text-xs font-bold text-slate-700 mb-2">
                  Rentang Tonase Terbanyak:
                </div>
                <div className="grid grid-cols-3 gap-2 text-center text-xs">
                  <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-200">
                    <div className="font-extrabold text-slate-800">260 Ton</div>
                    <div className="text-[10px] text-slate-400 mt-0.5">14 Mesin</div>
                  </div>
                  <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-200">
                    <div className="font-extrabold text-slate-800">450 Ton</div>
                    <div className="text-[10px] text-slate-400 mt-0.5">5 Mesin Heavy</div>
                  </div>
                  <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-200">
                    <div className="font-extrabold text-slate-800">80 - 120T</div>
                    <div className="text-[10px] text-slate-400 mt-0.5">15 Mesin</div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <button
            onClick={() => setActiveTab('assets')}
            className="w-full mt-6 py-2.5 rounded-xl border border-emerald-600 text-emerald-700 hover:bg-emerald-50 text-xs font-bold transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
          >
            <span>Buka Database Riwayat Aset</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* 3. Alerts & Real-time Action Banners */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Alert 1: Suku Cadang Perlu Auto-Reorder (From real Heater & Electrical sheets) */}
        <div className="bg-white rounded-3xl p-6 border border-emerald-100 shadow-xs">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-xl bg-red-50 text-red-600 flex items-center justify-center font-bold">
                <Boxes className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-bold text-slate-900">
                  Alert Stok Menipis (Auto-Reorder)
                </h3>
                <p className="text-xs text-slate-500">
                  {lowStockParts.length} jenis suku cadang di bawah batas minimum
                </p>
              </div>
            </div>
            <button
              onClick={() => setActiveTab('inventory')}
              className="text-xs font-bold text-emerald-700 hover:underline cursor-pointer"
            >
              Lihat Gudang
            </button>
          </div>

          <div className="space-y-2.5 max-h-72 overflow-y-auto pr-1">
            {lowStockParts.slice(0, 5).map((part) => (
              <div
                key={part.id}
                className="p-3 rounded-2xl border border-red-100 bg-red-50/40 flex items-center justify-between gap-3 text-xs"
              >
                <div>
                  <div className="font-bold text-slate-900 flex items-center gap-2">
                    <span>{part.name}</span>
                    <span className="text-[10px] px-2 py-0.5 rounded-full bg-slate-200 text-slate-700 font-semibold">
                      {part.category}
                    </span>
                  </div>
                  <div className="text-[11px] text-slate-500 mt-0.5">
                    Lokasi: {part.rackLocation} | Batas Min: {part.minStock} {part.unit}
                  </div>
                </div>

                <div className="text-right">
                  <span
                    className={`inline-block px-2.5 py-1 rounded-xl font-extrabold ${
                      part.currentStock === 0
                        ? 'bg-red-600 text-white'
                        : 'bg-amber-100 text-amber-800'
                    }`}
                  >
                    {part.currentStock === 0 ? 'HABIS (0)' : `Sisa ${part.currentStock}`}
                  </span>
                  <div className="text-[10px] text-red-600 font-bold mt-1">
                    Order Rekomendasi: +{part.maxStock - part.currentStock}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Alert 2: Jadwal Preventive Maintenance Terdekat */}
        <div className="bg-white rounded-3xl p-6 border border-emerald-100 shadow-xs">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-xl bg-emerald-50 text-emerald-700 flex items-center justify-center font-bold">
                <Calendar className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-bold text-slate-900">
                  Jadwal Servis Berkala (PM)
                </h3>
                <p className="text-xs text-slate-500">
                  {upcomingPM.length} inspeksi rutin terjadwal minggu ini
                </p>
              </div>
            </div>
            <button
              onClick={() => setActiveTab('pm')}
              className="text-xs font-bold text-emerald-700 hover:underline cursor-pointer"
            >
              Buka Kalender
            </button>
          </div>

          <div className="space-y-2.5 max-h-72 overflow-y-auto pr-1">
            {upcomingPM.map((task) => (
              <div
                key={task.id}
                className="p-3 rounded-2xl border border-emerald-100 bg-emerald-50/30 flex items-center justify-between gap-3 text-xs"
              >
                <div>
                  <div className="font-bold text-slate-900">{task.title}</div>
                  <div className="text-[11px] text-slate-500 mt-0.5">
                    Frekuensi: <span className="font-semibold text-emerald-800">{task.frequency}</span> | PIC:{' '}
                    {task.assignedTechnician}
                  </div>
                </div>

                <div className="text-right">
                  <span className="inline-block px-2.5 py-1 rounded-xl bg-emerald-100 text-emerald-800 font-bold">
                    {task.dueDate}
                  </span>
                  <div className="text-[10px] text-slate-500 mt-1">
                    {task.checklist.filter((c) => c.status === 'pass').length} / {task.checklist.length} Ceklis
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
