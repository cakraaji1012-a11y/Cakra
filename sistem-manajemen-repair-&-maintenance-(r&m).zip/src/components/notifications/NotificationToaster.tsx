import React from 'react';
import { useApp } from '../../context/AppContext';
import { ToastNotification } from '../../types';
import {
  AlertTriangle,
  CalendarCheck2,
  Bell,
  X,
  ArrowRight,
  ExternalLink,
  Volume2,
  Sparkles,
} from 'lucide-react';

export const NotificationToaster: React.FC = () => {
  const { toasts, dismissToast, setActiveTab, openAssetHistoryById } = useApp();

  if (!toasts || toasts.length === 0) return null;

  return (
    <div className="fixed top-20 right-4 sm:right-6 z-50 flex flex-col gap-3 max-w-sm sm:max-w-md w-full pointer-events-none">
      {toasts.map((toast) => {
        const isUrgentWO = toast.type === 'urgent_wo';
        const isPMDue = toast.type === 'pm_due';

        return (
          <div
            key={toast.id}
            className={`pointer-events-auto rounded-3xl p-4 sm:p-5 shadow-2xl border transition-all duration-300 transform translate-y-0 backdrop-blur-md animate-fadeIn ${
              isUrgentWO
                ? 'bg-red-950/95 text-white border-red-500/50 shadow-red-950/40 ring-2 ring-red-500/30'
                : isPMDue
                ? 'bg-amber-950/95 text-white border-amber-500/50 shadow-amber-950/40 ring-2 ring-amber-500/30'
                : 'bg-slate-900/95 text-white border-emerald-500/40 shadow-slate-950/40'
            }`}
          >
            <div className="flex items-start justify-between gap-3">
              <div className="flex items-start gap-3">
                {/* Icon Badge */}
                <div
                  className={`w-10 h-10 rounded-2xl flex items-center justify-center shrink-0 shadow-md ${
                    isUrgentWO
                      ? 'bg-red-600 text-white animate-pulse'
                      : isPMDue
                      ? 'bg-amber-500 text-white'
                      : 'bg-emerald-600 text-white'
                  }`}
                >
                  {isUrgentWO ? (
                    <AlertTriangle className="w-5 h-5" />
                  ) : isPMDue ? (
                    <CalendarCheck2 className="w-5 h-5" />
                  ) : (
                    <Bell className="w-5 h-5" />
                  )}
                </div>

                {/* Details */}
                <div>
                  <div className="flex items-center gap-2">
                    <span
                      className={`text-[10px] font-black uppercase tracking-wider px-2 py-0.5 rounded-full ${
                        isUrgentWO
                          ? 'bg-red-800/90 text-red-200'
                          : isPMDue
                          ? 'bg-amber-800/90 text-amber-200'
                          : 'bg-emerald-800 text-emerald-200'
                      }`}
                    >
                      {isUrgentWO ? 'Urgent Work Order' : isPMDue ? 'PM Due / Servis' : 'Alert Sistem'}
                    </span>
                    <span className="text-[10px] text-slate-400 font-medium flex items-center gap-1">
                      <Volume2 className="w-3 h-3 text-slate-400" />
                      <span>{toast.time}</span>
                    </span>
                  </div>

                  <h4 className="text-sm font-extrabold text-white mt-1 leading-snug">
                    {toast.title}
                  </h4>
                  <p className="text-xs text-slate-300 mt-1 leading-relaxed line-clamp-3">
                    {toast.message}
                  </p>
                </div>
              </div>

              {/* Dismiss button */}
              <button
                onClick={() => dismissToast(toast.id)}
                className="p-1 rounded-xl text-slate-400 hover:text-white hover:bg-white/10 transition-colors shrink-0 cursor-pointer"
                title="Tutup Notifikasi"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Quick Action Footer */}
            <div className="mt-3 pt-3 border-t border-white/10 flex items-center justify-between gap-2">
              <span className="text-[11px] text-slate-400 font-medium">
                {isUrgentWO ? 'Penugasan staf teknisi PIC' : 'Jadwal pemeliharaan berkala'}
              </span>

              <button
                onClick={() => {
                  dismissToast(toast.id);
                  if (toast.linkTab) {
                    setActiveTab(toast.linkTab);
                  } else if (isUrgentWO) {
                    setActiveTab('my-tasks');
                  } else if (isPMDue) {
                    setActiveTab('pm');
                  }
                  if (toast.targetId) {
                    openAssetHistoryById(toast.targetId);
                  }
                }}
                className={`px-3 py-1.5 rounded-xl text-xs font-extrabold flex items-center gap-1.5 transition-all shadow-sm active:scale-95 cursor-pointer ${
                  isUrgentWO
                    ? 'bg-red-600 hover:bg-red-500 text-white'
                    : isPMDue
                    ? 'bg-amber-500 hover:bg-amber-400 text-slate-950 font-black'
                    : 'bg-emerald-600 hover:bg-emerald-500 text-white'
                }`}
              >
                <span>{isUrgentWO ? 'Lihat Tugas Saya' : isPMDue ? 'Buka Jadwal PM' : 'Periksa'}</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        );
      })}
    </div>
  );
};
