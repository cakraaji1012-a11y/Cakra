import React, { useState } from 'react';
import { WorkOrder, SparePart, StockLog } from '../../types';
import { exportWorkOrdersToExcel, exportInventoryToExcel } from '../../utils/exportUtils';
import {
  Printer,
  FileSpreadsheet,
  X,
  FileText,
  Calendar,
  CheckCircle2,
  Clock,
  Wrench,
  Package,
  Layers,
  Building,
  ShieldCheck,
} from 'lucide-react';

interface ReportPrintModalProps {
  isOpen: boolean;
  onClose: () => void;
  reportType: 'work-order' | 'inventory';
  workOrders?: WorkOrder[];
  spareParts?: SparePart[];
  stockLogs?: StockLog[];
  activeCategory?: string;
}

export const ReportPrintModal: React.FC<ReportPrintModalProps> = ({
  isOpen,
  onClose,
  reportType,
  workOrders = [],
  spareParts = [],
  stockLogs = [],
  activeCategory = 'Semua',
}) => {
  const [selectedMonth, setSelectedMonth] = useState('September 2026');
  const [filterStatus, setFilterStatus] = useState('all');

  if (!isOpen) return null;

  // Filtered data for report
  const filteredWOs = workOrders.filter((wo) => {
    if (filterStatus === 'all') return true;
    return wo.status === filterStatus;
  });

  const totalWO = filteredWOs.length;
  const closedWO = filteredWOs.filter((w) => w.status === 'Closed').length;
  const inProgressWO = filteredWOs.filter((w) => w.status === 'In Progress').length;
  const emergencyWO = filteredWOs.filter((w) => w.urgency === 'Emergency').length;
  const totalDowntime = filteredWOs.reduce((acc, curr) => acc + (curr.downtimeHours || 0), 0);
  const avgMTTR = closedWO > 0 ? (totalDowntime / closedWO).toFixed(1) : '2.1';

  // Inventory calculations
  const totalParts = spareParts.length;
  const lowStockParts = spareParts.filter((p) => p.currentStock <= p.minStock);
  const outOfStockParts = spareParts.filter((p) => p.currentStock === 0);

  const handlePrint = () => {
    window.print();
  };

  const handleDownloadExcel = () => {
    if (reportType === 'work-order') {
      exportWorkOrdersToExcel(filteredWOs, `Laporan_Bulanan_WorkOrder_${selectedMonth.replace(' ', '_')}`);
    } else {
      exportInventoryToExcel(spareParts, stockLogs, activeCategory, `Laporan_Bulanan_Inventaris_${selectedMonth.replace(' ', '_')}`);
    }
  };

  return (
    <div className="fixed inset-0 bg-slate-900/70 z-50 flex items-center justify-center p-2 sm:p-4 backdrop-blur-xs overflow-y-auto">
      <div className="bg-white rounded-3xl max-w-5xl w-full max-h-[94vh] flex flex-col shadow-2xl border border-slate-200 overflow-hidden animate-fadeIn">
        {/* Top Control Bar (Hidden when printing!) */}
        <div className="print:hidden p-4 sm:p-5 bg-slate-900 text-white flex flex-wrap items-center justify-between gap-3 border-b border-slate-800 shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-emerald-600 text-white flex items-center justify-center font-bold">
              <FileText className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-extrabold text-sm sm:text-base text-white">
                Pratinjau Laporan Bulanan (PDF & Excel)
              </h3>
              <p className="text-[11px] text-slate-300">
                Dokumen formal standar Departemen Repair & Maintenance
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {/* Filter controls */}
            <select
              value={selectedMonth}
              onChange={(e) => setSelectedMonth(e.target.value)}
              className="bg-slate-800 text-white border border-slate-700 px-3 py-1.5 rounded-xl text-xs font-semibold"
            >
              <option value="September 2026">Periode: September 2026</option>
              <option value="Agustus 2026">Periode: Agustus 2026</option>
              <option value="Juli 2026">Periode: Juli 2026</option>
            </select>

            {reportType === 'work-order' && (
              <select
                value={filterStatus}
                onChange={(e) => setFilterStatus(e.target.value)}
                className="bg-slate-800 text-white border border-slate-700 px-3 py-1.5 rounded-xl text-xs font-semibold"
              >
                <option value="all">Semua Status WO</option>
                <option value="Closed">Hanya Closed</option>
                <option value="In Progress">In Progress & Open</option>
              </select>
            )}

            {/* Direct Excel download */}
            <button
              onClick={handleDownloadExcel}
              className="flex items-center gap-1.5 px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-700 active:scale-95 text-white rounded-xl text-xs font-bold transition-all shadow-sm cursor-pointer"
            >
              <FileSpreadsheet className="w-4 h-4" />
              <span>Unduh Excel (.xlsx)</span>
            </button>

            {/* Print / Save as PDF */}
            <button
              onClick={handlePrint}
              className="flex items-center gap-1.5 px-3.5 py-1.5 bg-blue-600 hover:bg-blue-700 active:scale-95 text-white rounded-xl text-xs font-bold transition-all shadow-sm cursor-pointer"
            >
              <Printer className="w-4 h-4" />
              <span>Cetak / Simpan PDF</span>
            </button>

            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-white rounded-lg cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Scrollable Printable Document Area */}
        <div className="flex-1 overflow-y-auto p-6 sm:p-10 bg-slate-100 print:bg-white print:p-0">
          {/* Formal A4 Document Container */}
          <div id="printable-report" className="max-w-4xl mx-auto bg-white p-8 sm:p-12 rounded-2xl shadow-md border border-slate-200 print:shadow-none print:border-none print:p-0 text-slate-800">
            {/* 1. KOP SURAT FORMAL */}
            <div className="border-b-2 border-slate-900 pb-4 mb-6">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div className="w-14 h-14 rounded-2xl bg-emerald-800 text-white flex items-center justify-center font-black text-xl shadow-sm">
                    <Wrench className="w-8 h-8 text-emerald-300" />
                  </div>
                  <div>
                    <h1 className="text-xl font-black uppercase tracking-wider text-slate-950">
                      PT MANUFAKTUR PLASTIK & INJEKSI
                    </h1>
                    <h2 className="text-xs uppercase font-extrabold tracking-widest text-emerald-800">
                      DEPARTEMEN REPAIR & MAINTENANCE (R&M)
                    </h2>
                    <p className="text-[10px] text-slate-500 mt-0.5">
                      Kawasan Industri Cikarang Blok F-12, Jawa Barat | Telepon: (021) 8980-3321 | Ext. 402 Maintenance
                    </p>
                  </div>
                </div>

                <div className="text-right text-[10px] text-slate-500 font-mono">
                  <div><strong>No. Dok:</strong> {reportType === 'work-order' ? 'RM/REP/WO/2026-09' : 'RM/REP/INV/2026-09'}</div>
                  <div><strong>Tanggal Cetak:</strong> {new Date().toLocaleDateString('id-ID', { day: '2-digit', month: 'long', year: 'numeric' })}</div>
                  <div><strong>Klasifikasi:</strong> Dokumen Internal Pabrik</div>
                </div>
              </div>
            </div>

            {/* Title & Period Banner */}
            <div className="text-center my-6">
              <h2 className="text-lg sm:text-xl font-extrabold uppercase text-slate-900 tracking-tight">
                {reportType === 'work-order'
                  ? 'LAPORAN REKAPITULASI WORK ORDER & PERBAIKAN MESIN'
                  : 'LAPORAN REKAPITULASI INVENTARIS SUKU CADANG & KARTU STOK'}
              </h2>
              <div className="inline-block mt-1 px-4 py-1 rounded-full bg-emerald-100 text-emerald-900 text-xs font-bold">
                Periode Pelaporan: {selectedMonth}
              </div>
            </div>

            {/* 2. EXECUTIVE KPI CARDS */}
            {reportType === 'work-order' ? (
              <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 mb-6 text-center text-xs">
                <div className="p-3 rounded-xl bg-slate-50 border border-slate-200">
                  <span className="text-[10px] uppercase font-bold text-slate-500 block">Total Tiket</span>
                  <span className="text-xl font-black text-slate-900 mt-0.5 block">{totalWO}</span>
                </div>
                <div className="p-3 rounded-xl bg-emerald-50 border border-emerald-200">
                  <span className="text-[10px] uppercase font-bold text-emerald-800 block">Tiket Selesai</span>
                  <span className="text-xl font-black text-emerald-800 mt-0.5 block">{closedWO}</span>
                </div>
                <div className="p-3 rounded-xl bg-amber-50 border border-amber-200">
                  <span className="text-[10px] uppercase font-bold text-amber-800 block">In Progress</span>
                  <span className="text-xl font-black text-amber-800 mt-0.5 block">{inProgressWO}</span>
                </div>
                <div className="p-3 rounded-xl bg-red-50 border border-red-200">
                  <span className="text-[10px] uppercase font-bold text-red-700 block">Darurat (Emerg.)</span>
                  <span className="text-xl font-black text-red-700 mt-0.5 block">{emergencyWO}</span>
                </div>
                <div className="p-3 rounded-xl bg-blue-50 border border-blue-200">
                  <span className="text-[10px] uppercase font-bold text-blue-800 block">Rata-rata MTTR</span>
                  <span className="text-xl font-black text-blue-800 mt-0.5 block">{avgMTTR} Jam</span>
                </div>
              </div>
            ) : (
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-6 text-center text-xs">
                <div className="p-3 rounded-xl bg-slate-50 border border-slate-200">
                  <span className="text-[10px] uppercase font-bold text-slate-500 block">Total Jenis Part</span>
                  <span className="text-xl font-black text-slate-900 mt-0.5 block">{totalParts} Item</span>
                </div>
                <div className="p-3 rounded-xl bg-emerald-50 border border-emerald-200">
                  <span className="text-[10px] uppercase font-bold text-emerald-800 block">Stok Aman</span>
                  <span className="text-xl font-black text-emerald-800 mt-0.5 block">
                    {totalParts - lowStockParts.length} Item
                  </span>
                </div>
                <div className="p-3 rounded-xl bg-amber-50 border border-amber-200">
                  <span className="text-[10px] uppercase font-bold text-amber-800 block">Perlu Restock</span>
                  <span className="text-xl font-black text-amber-800 mt-0.5 block">{lowStockParts.length} Item</span>
                </div>
                <div className="p-3 rounded-xl bg-red-50 border border-red-200">
                  <span className="text-[10px] uppercase font-bold text-red-700 block">Stok Habis (0)</span>
                  <span className="text-xl font-black text-red-700 mt-0.5 block">{outOfStockParts.length} Item</span>
                </div>
              </div>
            )}

            {/* 3. TABLE OF DATA */}
            {reportType === 'work-order' ? (
              <div className="overflow-hidden border border-slate-300 rounded-xl mb-8">
                <table className="w-full text-left text-[11px] leading-tight">
                  <thead className="bg-slate-100 text-slate-700 font-extrabold uppercase border-b border-slate-300 text-[10px]">
                    <tr>
                      <th className="py-2.5 px-3">No</th>
                      <th className="py-2.5 px-3">No. Tiket</th>
                      <th className="py-2.5 px-3">Mesin / Lokasi</th>
                      <th className="py-2.5 px-3">Kategori</th>
                      <th className="py-2.5 px-3">Urgensi</th>
                      <th className="py-2.5 px-3">Uraian Gangguan / Masalah</th>
                      <th className="py-2.5 px-3">Teknisi</th>
                      <th className="py-2.5 px-3">Status</th>
                      <th className="py-2.5 px-3 text-right">Downtime</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-200">
                    {filteredWOs.map((wo, idx) => (
                      <tr key={wo.id} className={idx % 2 === 1 ? 'bg-slate-50/60' : 'bg-white'}>
                        <td className="py-2 px-3 text-slate-500 font-mono">{idx + 1}</td>
                        <td className="py-2 px-3 font-mono font-bold text-emerald-800">{wo.ticketNumber}</td>
                        <td className="py-2 px-3 font-semibold text-slate-900">{wo.machineName}</td>
                        <td className="py-2 px-3 text-slate-600">{wo.category}</td>
                        <td className="py-2 px-3 font-bold">
                          <span
                            className={`px-1.5 py-0.5 rounded text-[9px] ${
                              wo.urgency === 'Emergency'
                                ? 'bg-red-600 text-white'
                                : wo.urgency === 'High'
                                ? 'bg-amber-500 text-white'
                                : 'bg-slate-200 text-slate-800'
                            }`}
                          >
                            {wo.urgency}
                          </span>
                        </td>
                        <td className="py-2 px-3 text-slate-700 max-w-xs">{wo.title}</td>
                        <td className="py-2 px-3 text-slate-700">{wo.assignedTechnician || '-'}</td>
                        <td className="py-2 px-3 font-semibold">{wo.status}</td>
                        <td className="py-2 px-3 text-right font-mono font-bold text-slate-900">
                          {wo.downtimeHours || 0} Jam
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : (
              <div className="overflow-hidden border border-slate-300 rounded-xl mb-8">
                <table className="w-full text-left text-[11px] leading-tight">
                  <thead className="bg-slate-100 text-slate-700 font-extrabold uppercase border-b border-slate-300 text-[10px]">
                    <tr>
                      <th className="py-2.5 px-3">No</th>
                      <th className="py-2.5 px-3">Nama Suku Cadang / Ukuran</th>
                      <th className="py-2.5 px-3">Kategori</th>
                      <th className="py-2.5 px-3 text-center">Stok Awal</th>
                      <th className="py-2.5 px-3 text-center">Min</th>
                      <th className="py-2.5 px-3 text-center">Max</th>
                      <th className="py-2.5 px-3 text-center">Stok Akhir</th>
                      <th className="py-2.5 px-3 text-center">Kekurangan</th>
                      <th className="py-2.5 px-3 text-center">Status</th>
                      <th className="py-2.5 px-3">Lokasi Rak</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-200">
                    {spareParts.slice(0, 35).map((part, idx) => {
                      const shortage = Math.max(0, part.maxStock - part.currentStock);
                      const isLow = part.currentStock <= part.minStock;
                      return (
                        <tr key={part.id} className={idx % 2 === 1 ? 'bg-slate-50/60' : 'bg-white'}>
                          <td className="py-2 px-3 text-slate-500 font-mono">{idx + 1}</td>
                          <td className="py-2 px-3 font-bold text-slate-900">{part.name}</td>
                          <td className="py-2 px-3 text-slate-600">{part.category}</td>
                          <td className="py-2 px-3 text-center font-mono text-slate-500">{part.stockAwal}</td>
                          <td className="py-2 px-3 text-center font-mono text-red-600">{part.minStock}</td>
                          <td className="py-2 px-3 text-center font-mono text-emerald-700">{part.maxStock}</td>
                          <td className="py-2 px-3 text-center font-mono font-bold text-slate-900">
                            {part.currentStock} {part.unit}
                          </td>
                          <td className="py-2 px-3 text-center font-mono font-bold text-red-600">
                            {shortage > 0 ? `-${shortage}` : '0'}
                          </td>
                          <td className="py-2 px-3 text-center">
                            <span
                              className={`px-1.5 py-0.5 rounded text-[9px] font-bold ${
                                part.currentStock === 0
                                  ? 'bg-red-600 text-white'
                                  : isLow
                                  ? 'bg-amber-500 text-white'
                                  : 'bg-emerald-100 text-emerald-800'
                              }`}
                            >
                              {isLow ? 'RESTOCK' : 'AMAN'}
                            </span>
                          </td>
                          <td className="py-2 px-3 text-slate-500">{part.rackLocation}</td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}

            {/* 4. OFFICIAL SIGNATURE BLOCKS */}
            <div className="pt-6 border-t border-slate-300 grid grid-cols-3 gap-6 text-center text-xs">
              <div>
                <p className="text-[11px] text-slate-500">Dibuat Oleh (PIC Teknisi):</p>
                <div className="h-16 flex items-end justify-center">
                  <div className="w-32 border-b border-slate-400"></div>
                </div>
                <p className="font-bold text-slate-900 mt-1.5">Agus Wijaya</p>
                <p className="text-[10px] text-slate-500">Teknisi Senior R&M</p>
              </div>

              <div>
                <p className="text-[11px] text-slate-500">Diperiksa Oleh (Supervisor):</p>
                <div className="h-16 flex items-end justify-center">
                  <div className="w-32 border-b border-slate-400"></div>
                </div>
                <p className="font-bold text-slate-900 mt-1.5">Budi Santoso, S.T.</p>
                <p className="text-[10px] text-slate-500">Supervisor Pemeliharaan</p>
              </div>

              <div>
                <p className="text-[11px] text-slate-500">Disetujui Oleh (Dept. Head):</p>
                <div className="h-16 flex items-end justify-center">
                  <div className="w-32 border-b border-slate-400"></div>
                </div>
                <p className="font-bold text-slate-900 mt-1.5">Ir. Bambang Hartono</p>
                <p className="text-[10px] text-slate-500">Factory / Operations Manager</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
