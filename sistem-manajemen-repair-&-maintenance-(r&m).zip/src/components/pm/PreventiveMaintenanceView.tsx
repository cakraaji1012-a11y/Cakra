import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { PMTask, PMFrequency, PMStatus } from '../../types';
import {
  CalendarCheck2,
  Calendar,
  CheckCircle2,
  Clock,
  Plus,
  AlertCircle,
  FileCheck,
  CheckSquare,
  Square,
  AlertTriangle,
  User,
  Wrench,
  ChevronRight,
  ShieldCheck,
  Building,
  Cpu,
  Trash2,
} from 'lucide-react';

export const PreventiveMaintenanceView: React.FC = () => {
  const {
    pmTasks,
    updatePMTask,
    updateChecklistStatus,
    addPMTask,
    isAdmin,
    machines,
    createWorkOrder,
    currentUser,
  } = useApp();

  const [selectedFrequency, setSelectedFrequency] = useState<string>('all');
  const [selectedTask, setSelectedTask] = useState<PMTask | null>(null);

  // New PM schedule modal
  const [showNewTaskModal, setShowNewTaskModal] = useState(false);
  const [newTitle, setNewTitle] = useState('');
  const [newFrequency, setNewFrequency] = useState<PMFrequency>('Bulanan');
  const [newMachineId, setNewMachineId] = useState('');
  const [newDueDate, setNewDueDate] = useState(() => {
    const d = new Date();
    d.setDate(d.getDate() + 7);
    return d.toISOString().slice(0, 10);
  });
  const [newTechnician, setNewTechnician] = useState('Agus Wijaya');

  // Filtered PM tasks
  const filteredTasks = pmTasks.filter((task) => {
    if (selectedFrequency === 'all') return true;
    return task.frequency === selectedFrequency;
  });

  const getFrequencyBadge = (freq: PMFrequency) => {
    switch (freq) {
      case 'Harian':
        return 'bg-blue-100 text-blue-800';
      case 'Mingguan':
        return 'bg-emerald-100 text-emerald-800';
      case 'Bulanan':
        return 'bg-amber-100 text-amber-800';
      case '6 Bulanan':
        return 'bg-purple-100 text-purple-800';
      case 'Tahunan':
        return 'bg-rose-100 text-rose-800';
    }
  };

  const handleCreatePM = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim()) return;

    const mach = machines.find((m) => m.id === newMachineId);

    // Default template checklist items based on frequency
    const defaultChecklist = [
      { id: `chk-${Date.now()}-1`, task: 'Cek kebersihan umum platen, tie bar dan area kerja mesin', category: 'Kebersihan', status: 'pending' as const },
      { id: `chk-${Date.now()}-2`, task: 'Pemeriksaan level pelumas oli hidrolik & grease auto-lube', category: 'Lubrikasi', status: 'pending' as const },
      { id: `chk-${Date.now()}-3`, task: 'Pemeriksaan kebocoran fitting selang hidrolik & pendingin', category: 'Hidrolik', status: 'pending' as const },
      { id: `chk-${Date.now()}-4`, task: 'Uji fungsi emergency stop button dan safety interlock pintu', category: 'Safety', status: 'pending' as const },
    ];

    addPMTask({
      title: newTitle,
      frequency: newFrequency,
      machineId: mach?.id,
      machineName: mach ? `${mach.name} (No. ${mach.noMc})` : 'Fasilitas & Area Pabrik',
      machineNo: mach?.noMc,
      dueDate: newDueDate,
      assignedTechnician: newTechnician,
      status: 'Scheduled',
      checklist: defaultChecklist,
    });

    setShowNewTaskModal(false);
    setNewTitle('');
    setNewMachineId('');
  };

  // Convert failed checklist item into a Work Order
  const handleCreateWOFromFailure = (taskName: string) => {
    if (!selectedTask) return;
    createWorkOrder({
      title: `[Temuan PM ${selectedTask.code}] ${taskName}`,
      machineId: selectedTask.machineId || 'mc-2',
      machineName: selectedTask.machineName || 'Mesin Pabrik',
      machineNo: selectedTask.machineNo || 0,
      reporterName: currentUser?.name || 'Inspektor PM',
      department: 'Repair & Maintenance',
      urgency: 'High',
      category: 'Mekanikal',
      description: `Ditemukan ketidaksesuaian/kerusakan saat eksekusi ${selectedTask.title}: ${taskName}. Memerlukan perbaikan mendalam atau penggantian komponen.`,
      status: 'Open',
      targetDate: new Date().toISOString().slice(0, 10),
      usedParts: [],
    });
    alert(`Tiket Work Order berhasil dibuat dari temuan PM "${taskName}"! Tim teknisi akan segera menindaklanjuti.`);
  };

  return (
    <div className="space-y-6">
      {/* Header bar */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white p-6 rounded-3xl border border-emerald-100 shadow-xs">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-50 text-emerald-700 text-xs font-bold mb-2">
            <CalendarCheck2 className="w-3.5 h-3.5" />
            <span>Pemeliharaan Pencegahan & Keandalan Terjadwal</span>
          </div>
          <h1 className="text-2xl font-extrabold text-slate-900 tracking-tight">
            Preventive Maintenance (PM) & Jadwal Rutin
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Kalender servis berkala mesin injeksi, sistem hidrolik, kelistrikan, HVAC, dan formulir ceklis digital.
          </p>
        </div>

        {isAdmin && (
          <button
            onClick={() => setShowNewTaskModal(true)}
            className="flex items-center gap-2 px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 active:scale-95 text-white rounded-xl text-xs sm:text-sm font-bold shadow-md shadow-emerald-600/30 transition-all cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>Tambah Jadwal PM Baru</span>
          </button>
        )}
      </div>

      {/* Calendar & Frequency Tabs */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-white p-3.5 rounded-2xl border border-emerald-100 shadow-xs">
        <div className="flex flex-wrap items-center gap-1.5 text-xs font-semibold">
          {['all', 'Harian', 'Mingguan', 'Bulanan', '6 Bulanan', 'Tahunan'].map((freq) => (
            <button
              key={freq}
              onClick={() => setSelectedFrequency(freq)}
              className={`px-3.5 py-1.5 rounded-xl transition-all cursor-pointer ${
                selectedFrequency === freq
                  ? 'bg-emerald-600 text-white font-bold shadow-xs'
                  : 'text-slate-600 hover:bg-emerald-50 hover:text-emerald-800'
              }`}
            >
              {freq === 'all' ? 'Semua Frekuensi' : freq}
            </button>
          ))}
        </div>

        <div className="flex items-center gap-2 text-xs text-slate-500 font-medium">
          <Calendar className="w-4 h-4 text-emerald-600" />
          <span>Periode Kerja: September - Oktober 2026</span>
        </div>
      </div>

      {/* Task Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-6">
        {filteredTasks.map((task) => {
          const passCount = task.checklist.filter((i) => i.status === 'pass').length;
          const failCount = task.checklist.filter((i) => i.status === 'fail').length;
          const progress = Math.round(
            (task.checklist.filter((i) => i.status !== 'pending').length /
              task.checklist.length) *
              100
          );

          return (
            <div
              key={task.id}
              className="bg-white rounded-3xl p-6 border border-emerald-100 shadow-xs hover:shadow-md transition-all flex flex-col justify-between"
            >
              <div>
                <div className="flex items-start justify-between gap-3 mb-3">
                  <div>
                    <div className="flex items-center gap-2 mb-1.5">
                      <span className="font-mono text-xs font-bold text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded-md">
                        {task.code}
                      </span>
                      <span
                        className={`text-[10px] font-bold px-2.5 py-0.5 rounded-full ${getFrequencyBadge(
                          task.frequency
                        )}`}
                      >
                        {task.frequency}
                      </span>
                      <span
                        className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                          task.status === 'Completed'
                            ? 'bg-emerald-100 text-emerald-800'
                            : 'bg-amber-100 text-amber-800'
                        }`}
                      >
                        {task.status}
                      </span>
                    </div>

                    <h3 className="text-base font-extrabold text-slate-900 leading-snug">
                      {task.title}
                    </h3>
                  </div>
                </div>

                <div className="text-xs text-slate-500 space-y-1 mt-2">
                  <div className="flex items-center gap-2 text-slate-700 font-medium">
                    <Cpu className="w-3.5 h-3.5 text-slate-400" />
                    <span>Target: {task.machineName || 'Pabrik & Gedung'}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <User className="w-3.5 h-3.5 text-slate-400" />
                    <span>Teknisi PIC: {task.assignedTechnician}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Clock className="w-3.5 h-3.5 text-slate-400" />
                    <span>Batas Waktu: <strong>{task.dueDate}</strong></span>
                  </div>
                </div>

                {/* Progress bar */}
                <div className="mt-5 p-3.5 rounded-2xl bg-slate-50 border border-slate-100">
                  <div className="flex items-center justify-between text-xs font-bold mb-1.5">
                    <span className="text-slate-700">Progres Checklist</span>
                    <span className="text-emerald-700">{progress}% Selesai</span>
                  </div>
                  <div className="w-full bg-slate-200 h-2 rounded-full overflow-hidden">
                    <div
                      style={{ width: `${progress}%` }}
                      className="bg-emerald-600 h-full rounded-full transition-all"
                    ></div>
                  </div>
                  <div className="flex items-center justify-between text-[11px] text-slate-500 mt-2">
                    <span className="text-emerald-700 font-semibold">
                      ✓ {passCount} Normal (OK)
                    </span>
                    {failCount > 0 && (
                      <span className="text-red-600 font-bold">
                        ⚠ {failCount} Kerusakan Terdeteksi
                      </span>
                    )}
                    <span>Total {task.checklist.length} Titik Uji</span>
                  </div>
                </div>
              </div>

              {/* Action execute button */}
              <div className="mt-6 pt-4 border-t border-slate-100 flex items-center justify-between">
                <span className="text-[11px] text-slate-400">
                  Standar Mutu PM-ISO 9001
                </span>
                <button
                  onClick={() => setSelectedTask(task)}
                  className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 active:scale-95 text-white rounded-xl text-xs font-bold transition-all flex items-center gap-2 cursor-pointer shadow-sm shadow-emerald-600/20"
                >
                  <FileCheck className="w-4 h-4" />
                  <span>Buka Form Ceklis</span>
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* CHECKLIST EXECUTION MODAL */}
      {selectedTask && (
        <div className="fixed inset-0 bg-slate-900/60 z-50 flex items-center justify-center p-4 backdrop-blur-xs">
          <div className="bg-white rounded-3xl max-w-3xl w-full max-h-[90vh] overflow-y-auto shadow-2xl border border-slate-200">
            {/* Modal Header */}
            <div className="p-6 bg-gradient-to-r from-emerald-800 to-teal-800 text-white rounded-t-3xl flex items-start justify-between">
              <div>
                <div className="flex items-center gap-2 mb-2">
                  <span className="font-mono bg-white/20 px-2 py-0.5 rounded-md text-xs font-bold">
                    {selectedTask.code}
                  </span>
                  <span className="text-xs px-2.5 py-0.5 rounded-full bg-emerald-700 font-bold">
                    Frekuensi: {selectedTask.frequency}
                  </span>
                </div>
                <h3 className="text-xl font-extrabold text-white">
                  {selectedTask.title}
                </h3>
                <p className="text-emerald-100 text-xs mt-1">
                  Target: {selectedTask.machineName} | Teknisi: {selectedTask.assignedTechnician} | Jatuh Tempo: {selectedTask.dueDate}
                </p>
              </div>
              <button
                onClick={() => setSelectedTask(null)}
                className="text-emerald-200 hover:text-white p-1 rounded-lg text-lg font-bold"
              >
                ✕
              </button>
            </div>

            {/* Checklist items list */}
            <div className="p-6 space-y-4">
              <div className="flex items-center justify-between bg-slate-50 p-3 rounded-xl border border-slate-200 text-xs font-medium text-slate-600">
                <span>Klik status pada setiap parameter untuk mencatat hasil inspeksi fisik:</span>
                <span className="font-bold text-emerald-800">
                  {selectedTask.checklist.filter((c) => c.status === 'pass').length} / {selectedTask.checklist.length} Lolos
                </span>
              </div>

              <div className="space-y-3">
                {selectedTask.checklist.map((item, index) => (
                  <div
                    key={item.id}
                    className={`p-4 rounded-2xl border transition-all ${
                      item.status === 'pass'
                        ? 'bg-emerald-50/40 border-emerald-200'
                        : item.status === 'fail'
                        ? 'bg-red-50/50 border-red-200'
                        : item.status === 'adjusted'
                        ? 'bg-amber-50/40 border-amber-200'
                        : 'bg-white border-slate-200'
                    }`}
                  >
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                      <div className="flex items-start gap-3">
                        <span className="w-6 h-6 rounded-full bg-slate-100 text-slate-700 font-bold text-xs flex items-center justify-center shrink-0 mt-0.5">
                          {index + 1}
                        </span>
                        <div>
                          <div className="text-xs sm:text-sm font-bold text-slate-900 leading-snug">
                            {item.task}
                          </div>
                          <span className="text-[10px] px-2 py-0.5 rounded-md bg-slate-100 text-slate-600 font-semibold mt-1 inline-block">
                            Sistem: {item.category}
                          </span>
                        </div>
                      </div>

                      {/* Status toggle buttons */}
                      <div className="flex items-center gap-1.5 shrink-0 self-end sm:self-center">
                        <button
                          type="button"
                          onClick={() => {
                            updateChecklistStatus(selectedTask.id, item.id, 'pass');
                            setSelectedTask({
                              ...selectedTask,
                              checklist: selectedTask.checklist.map((i) =>
                                i.id === item.id ? { ...i, status: 'pass' } : i
                              ),
                            });
                          }}
                          className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                            item.status === 'pass'
                              ? 'bg-emerald-600 text-white shadow-xs'
                              : 'bg-slate-100 text-slate-600 hover:bg-emerald-100'
                          }`}
                        >
                          ✓ OK (Normal)
                        </button>

                        <button
                          type="button"
                          onClick={() => {
                            updateChecklistStatus(selectedTask.id, item.id, 'adjusted');
                            setSelectedTask({
                              ...selectedTask,
                              checklist: selectedTask.checklist.map((i) =>
                                i.id === item.id ? { ...i, status: 'adjusted' } : i
                              ),
                            });
                          }}
                          className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                            item.status === 'adjusted'
                              ? 'bg-amber-500 text-white shadow-xs'
                              : 'bg-slate-100 text-slate-600 hover:bg-amber-100'
                          }`}
                        >
                          ⚙ Disetel Ulang
                        </button>

                        <button
                          type="button"
                          onClick={() => {
                            updateChecklistStatus(selectedTask.id, item.id, 'fail');
                            setSelectedTask({
                              ...selectedTask,
                              checklist: selectedTask.checklist.map((i) =>
                                i.id === item.id ? { ...i, status: 'fail' } : i
                              ),
                            });
                          }}
                          className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                            item.status === 'fail'
                              ? 'bg-red-600 text-white shadow-xs'
                              : 'bg-slate-100 text-slate-600 hover:bg-red-100'
                          }`}
                        >
                          ✗ Rusak / Gagal
                        </button>
                      </div>
                    </div>

                    {/* If item failed, show button to generate WO immediately! */}
                    {item.status === 'fail' && (
                      <div className="mt-3 pt-3 border-t border-red-200 flex items-center justify-between text-xs">
                        <span className="text-red-700 font-semibold flex items-center gap-1">
                          <AlertTriangle className="w-3.5 h-3.5" />
                          <span>Temuan kritis memerlukan tiket perbaikan!</span>
                        </span>
                        <button
                          onClick={() => handleCreateWOFromFailure(item.task)}
                          className="px-3 py-1 bg-red-600 hover:bg-red-700 text-white font-bold rounded-lg text-[11px] transition-colors cursor-pointer shadow-xs"
                        >
                          + Otomatis Buat Work Order (WO)
                        </button>
                      </div>
                    )}
                  </div>
                ))}
              </div>

              {/* Close & sign */}
              <div className="pt-4 border-t border-slate-200 flex items-center justify-between">
                <span className="text-xs text-slate-500">
                  Diverifikasi oleh: <strong>{currentUser?.name}</strong>
                </span>
                <button
                  onClick={() => setSelectedTask(null)}
                  className="px-6 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl transition-all cursor-pointer shadow-md shadow-emerald-600/30"
                >
                  Selesai & Simpan Ceklis
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* CREATE NEW PM SCHEDULE MODAL (Admin Only) */}
      {showNewTaskModal && (
        <div className="fixed inset-0 bg-slate-900/60 z-50 flex items-center justify-center p-4 backdrop-blur-xs">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 shadow-2xl border border-slate-200 animate-fadeIn">
            <div className="flex items-center justify-between mb-4 pb-3 border-b border-slate-100">
              <h3 className="text-lg font-bold text-slate-900">
                Tambah Jadwal Preventive Maintenance Baru
              </h3>
              <button
                onClick={() => setShowNewTaskModal(false)}
                className="text-slate-400 hover:text-slate-600 font-bold"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleCreatePM} className="space-y-4 text-xs">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Nama Program Pemeliharaan <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  placeholder="Contoh: Kalibrasi Pemanas Barrel & Uji Tekanan Clamping"
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-xs focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Frekuensi Servis:
                  </label>
                  <select
                    value={newFrequency}
                    onChange={(e) => setNewFrequency(e.target.value as PMFrequency)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs bg-white"
                  >
                    <option value="Harian">Harian</option>
                    <option value="Mingguan">Mingguan</option>
                    <option value="Bulanan">Bulanan</option>
                    <option value="6 Bulanan">6 Bulanan</option>
                    <option value="Tahunan">Tahunan</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Target Tanggal Servis:
                  </label>
                  <input
                    type="date"
                    required
                    value={newDueDate}
                    onChange={(e) => setNewDueDate(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs bg-white"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Target Mesin / Fasilitas:
                </label>
                <select
                  value={newMachineId}
                  onChange={(e) => setNewMachineId(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs bg-white"
                >
                  <option value="">Fasilitas Seluruh Pabrik</option>
                  {machines.map((m) => (
                    <option key={m.id} value={m.id}>
                      No. {m.noMc} - {m.name} ({m.tonase})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Teknisi Penanggung Jawab (PIC):
                </label>
                <select
                  value={newTechnician}
                  onChange={(e) => setNewTechnician(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs bg-white"
                >
                  <option value="Agus Wijaya">Agus Wijaya</option>
                  <option value="Hendra Pratama">Hendra Pratama</option>
                  <option value="Dwi Kurniawan">Dwi Kurniawan</option>
                  <option value="Budi Santoso">Budi Santoso</option>
                </select>
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowNewTaskModal(false)}
                  className="px-4 py-2 border rounded-xl text-slate-600"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl shadow-md"
                >
                  Jadwalkan PM
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
