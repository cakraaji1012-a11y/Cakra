export interface OfflineSyncItem {
  id: string;
  timestamp: string;
  entity: 'work_order' | 'pm_task' | 'stock' | 'machine';
  action: 'UPDATE_STATUS' | 'CREATE_WO' | 'UPDATE_WO' | 'UPDATE_CHECKLIST' | 'RECORD_STOCK';
  title: string;
  payload: any;
  status: 'pending' | 'syncing' | 'synced' | 'failed';
  retryCount: number;
}

const STORAGE_KEY_QUEUE = 'rm_offline_sync_queue_v1';
const STORAGE_KEY_SIMULATED_OFFLINE = 'rm_simulated_offline_mode';

export const getOfflineQueue = (): OfflineSyncItem[] => {
  try {
    const raw = localStorage.getItem(STORAGE_KEY_QUEUE);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
};

export const saveOfflineQueue = (queue: OfflineSyncItem[]) => {
  try {
    localStorage.setItem(STORAGE_KEY_QUEUE, JSON.stringify(queue));
  } catch (err) {
    console.error('Failed to save offline queue:', err);
  }
};

export const enqueueOfflineAction = (
  item: Omit<OfflineSyncItem, 'id' | 'timestamp' | 'status' | 'retryCount'>
): OfflineSyncItem => {
  const queue = getOfflineQueue();
  const newItem: OfflineSyncItem = {
    ...item,
    id: `offline-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
    timestamp: new Date().toISOString().slice(0, 19).replace('T', ' '),
    status: 'pending',
    retryCount: 0,
  };
  const updated = [newItem, ...queue];
  saveOfflineQueue(updated);
  return newItem;
};

export const clearSyncedQueue = () => {
  const queue = getOfflineQueue().filter((q) => q.status === 'pending');
  saveOfflineQueue(queue);
};

export const getSimulatedOfflineState = (): boolean => {
  try {
    return localStorage.getItem(STORAGE_KEY_SIMULATED_OFFLINE) === 'true';
  } catch {
    return false;
  }
};

export const setSimulatedOfflineState = (offline: boolean) => {
  try {
    localStorage.setItem(STORAGE_KEY_SIMULATED_OFFLINE, offline ? 'true' : 'false');
  } catch (err) {
    console.error('Failed to set simulated offline state:', err);
  }
};
