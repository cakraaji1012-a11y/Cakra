import * as XLSX from 'xlsx';
import { WorkOrder, SparePart, StockLog } from '../types';

export const exportWorkOrdersToExcel = (
  workOrders: WorkOrder[],
  title = 'Laporan_Bulanan_Work_Order_RM'
) => {
  // Format rows for Work Orders
  const data = workOrders.map((wo, index) => ({
    'No.': index + 1,
    'No. Tiket': wo.ticketNumber,
    'Nama Mesin / Fasilitas': wo.machineName,
    'No. Mesin': wo.machineNo,
    'Kategori': wo.category,
    'Tingkat Urgensi': wo.urgency,
    'Judul Kerusakan': wo.title,
    'Departemen Pelapor': wo.department,
    'Nama Pelapor': wo.reporterName,
    'Teknisi Bertugas': wo.assignedTechnician || 'Belum ditugaskan',
    'Status': wo.status,
    'Tanggal Lapor': wo.createdDate,
    'Target Selesai': wo.targetDate,
    'Tanggal Selesai': wo.completedDate || '-',
    'Downtime (Jam)': wo.downtimeHours || 0,
    'Tindakan Troubleshooting': wo.actionsTaken || wo.description,
    'Suku Cadang Terpakai': wo.usedParts.map((p) => `${p.partName} (${p.quantity})`).join(', ') || '-',
  }));

  // Create worksheet
  const worksheet = XLSX.utils.json_to_sheet(data);

  // Set column widths for readability
  const colWidths = [
    { wch: 5 },  // No
    { wch: 18 }, // No Tiket
    { wch: 28 }, // Nama Mesin
    { wch: 10 }, // No Mesin
    { wch: 15 }, // Kategori
    { wch: 14 }, // Urgensi
    { wch: 35 }, // Judul
    { wch: 20 }, // Dept
    { wch: 18 }, // Pelapor
    { wch: 18 }, // Teknisi
    { wch: 14 }, // Status
    { wch: 18 }, // Tanggal Lapor
    { wch: 14 }, // Target
    { wch: 18 }, // Tanggal Selesai
    { wch: 14 }, // Downtime
    { wch: 45 }, // Tindakan
    { wch: 30 }, // Suku Cadang
  ];
  worksheet['!cols'] = colWidths;

  // Create workbook and append sheet
  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, 'Daftar Work Orders');

  // Summary sheet
  const totalWO = workOrders.length;
  const closedWO = workOrders.filter((w) => w.status === 'Closed').length;
  const openWO = workOrders.filter((w) => w.status !== 'Closed').length;
  const emergencyWO = workOrders.filter((w) => w.urgency === 'Emergency').length;
  const totalDowntime = workOrders.reduce((sum, w) => sum + (w.downtimeHours || 0), 0);
  const avgMTTR = closedWO > 0 ? (totalDowntime / closedWO).toFixed(1) : 0;

  const summaryData = [
    { Indikator: 'Nama Departemen', Nilai: 'Repair & Maintenance (R&M)' },
    { Indikator: 'Periode Laporan', Nilai: new Date().toLocaleDateString('id-ID', { month: 'long', year: 'numeric' }) },
    { Indikator: 'Total Tiket Masuk', Nilai: totalWO },
    { Indikator: 'Tiket Selesai (Closed)', Nilai: closedWO },
    { Indikator: 'Tiket Berjalan / Pending', Nilai: openWO },
    { Indikator: 'Tiket Darurat (Emergency)', Nilai: emergencyWO },
    { Indikator: 'Pencapaian Penyelesaian (%)', Nilai: `${((closedWO / (totalWO || 1)) * 100).toFixed(1)}%` },
    { Indikator: 'Total Jam Downtime', Nilai: `${totalDowntime} Jam` },
    { Indikator: 'Rata-rata MTTR', Nilai: `${avgMTTR} Jam/Perbaikan` },
  ];
  const summarySheet = XLSX.utils.json_to_sheet(summaryData);
  summarySheet['!cols'] = [{ wch: 25 }, { wch: 30 }];
  XLSX.utils.book_append_sheet(workbook, summarySheet, 'Ringkasan Eksekutif');

  // Save Excel file
  const fileName = `${title}_${new Date().toISOString().slice(0, 10)}.xlsx`;
  XLSX.writeFile(workbook, fileName);
};

export const exportInventoryToExcel = (
  spareParts: SparePart[],
  stockLogs: StockLog[],
  activeTabCategory = 'Semua',
  title = 'Laporan_Bulanan_Inventaris_Suku_Cadang'
) => {
  const workbook = XLSX.utils.book_new();

  // 1. Sheet: Kartu Stok Suku Cadang
  const partsData = spareParts.map((p, index) => {
    const shortage = Math.max(0, p.maxStock - p.currentStock);
    return {
      'No.': index + 1,
      'Kategori': p.category,
      'Nama Suku Cadang / Ukuran': p.name,
      'Stok Awal': p.stockAwal,
      'Stok Saat Ini (Akhir)': p.currentStock,
      'Batas Min': p.minStock,
      'Batas Max': p.maxStock,
      'Defisit / Kekurangan': shortage,
      'Satuan': p.unit,
      'Status Restock': p.currentStock === 0 ? 'HABIS (RESTOCK)' : p.currentStock <= p.minStock ? 'MENIPIS (RESTOCK)' : 'AMAN',
      'Lokasi Rak': p.rackLocation,
      'Update Terakhir': p.lastUpdated,
    };
  });

  const partsSheet = XLSX.utils.json_to_sheet(partsData);
  partsSheet['!cols'] = [
    { wch: 5 },  // No
    { wch: 14 }, // Kategori
    { wch: 30 }, // Nama
    { wch: 12 }, // Awal
    { wch: 16 }, // Akhir
    { wch: 12 }, // Min
    { wch: 12 }, // Max
    { wch: 14 }, // Defisit
    { wch: 10 }, // Satuan
    { wch: 20 }, // Status
    { wch: 18 }, // Rak
    { wch: 15 }, // Update
  ];
  XLSX.utils.book_append_sheet(workbook, partsSheet, 'Kartu Stok Gudang');

  // 2. Sheet: Log Mutasi Keluar - Masuk
  const logsData = stockLogs.map((log, index) => ({
    'No.': index + 1,
    'Tanggal Transaksi': log.date,
    'Tipe': log.type === 'in' ? 'MASUK (IN)' : 'KELUAR (OUT)',
    'Nama Barang': log.partName,
    'Kategori': log.category,
    'Jumlah (Qty)': log.quantity,
    'Target No. Mesin': log.machineNo ? `Mesin No. ${log.machineNo}` : 'Fasilitas Pabrik',
    'Referensi WO / PO': log.referenceWO || '-',
    'Petugas (PIC)': log.pic,
    'Catatan / Keperluan': log.notes,
  }));

  const logsSheet = XLSX.utils.json_to_sheet(logsData);
  logsSheet['!cols'] = [
    { wch: 5 },
    { wch: 16 },
    { wch: 14 },
    { wch: 28 },
    { wch: 14 },
    { wch: 12 },
    { wch: 18 },
    { wch: 18 },
    { wch: 18 },
    { wch: 40 },
  ];
  XLSX.utils.book_append_sheet(workbook, logsSheet, 'Log Mutasi Keluar-Masuk');

  // 3. Sheet: Daftar Barang Perlu Pembelian (Auto-Reorder)
  const lowStock = spareParts.filter((p) => p.currentStock <= p.minStock);
  const reorderData = lowStock.map((p, index) => ({
    'No.': index + 1,
    'Kategori': p.category,
    'Nama Komponen': p.name,
    'Sisa Stok Saat Ini': p.currentStock,
    'Batas Min': p.minStock,
    'Batas Max': p.maxStock,
    'Jumlah Rekomendasi Beli': p.maxStock - p.currentStock,
    'Satuan': p.unit,
    'Lokasi Penyimpanan': p.rackLocation,
    'Prioritas Pembelian': p.currentStock === 0 ? 'URGENT (HABIS)' : 'NORMAL RESTOCK',
  }));

  const reorderSheet = XLSX.utils.json_to_sheet(reorderData);
  reorderSheet['!cols'] = [
    { wch: 5 },
    { wch: 14 },
    { wch: 28 },
    { wch: 18 },
    { wch: 12 },
    { wch: 12 },
    { wch: 24 },
    { wch: 10 },
    { wch: 20 },
    { wch: 22 },
  ];
  XLSX.utils.book_append_sheet(workbook, reorderSheet, 'Daftar Auto-Reorder');

  const fileName = `${title}_${activeTabCategory}_${new Date().toISOString().slice(0, 10)}.xlsx`;
  XLSX.writeFile(workbook, fileName);
};
