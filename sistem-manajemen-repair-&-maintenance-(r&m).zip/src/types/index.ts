export type Role = 'admin' | 'staff';

export interface User {
  id: string;
  name: string;
  username: string;
  role: Role;
  position: string;
  department: string;
  avatar: string;
}

export type MachineStatus = 'active' | 'breakdown' | 'maintenance';
export type MekanismeType = 'HYDROLIK' | 'TOGGLE';

export interface Machine {
  id: string;
  name: string;
  noMc: number;
  tonase: string;
  tonaseVal: number;
  negaraAsal: string;
  tahunPembuatan: number;
  tahunPembelian: number;
  usiaPemakaian: number;
  totalUsia: number;
  mekanisme: MekanismeType;
  status: MachineStatus;
  lokasi: string;
  lastMaintenance?: string;
  nextMaintenance?: string;
  specNotes?: string;
}

export type UrgencyLevel = 'Low' | 'Medium' | 'High' | 'Emergency';
export type WorkOrderStatus = 'Open' | 'In Progress' | 'Pending' | 'Closed';
export type WorkOrderCategory =
  | 'Kelistrikan'
  | 'Hidrolik'
  | 'Mekanikal'
  | 'Heater'
  | 'Pendingin/Chiller'
  | 'Fasilitas';

export interface UsedPart {
  partId: string;
  partName: string;
  category: string;
  quantity: number;
}

export interface WorkOrder {
  id: string;
  ticketNumber: string;
  title: string;
  machineId: string;
  machineName: string;
  machineNo: number;
  reporterName: string;
  department: string;
  urgency: UrgencyLevel;
  category: WorkOrderCategory;
  description: string;
  status: WorkOrderStatus;
  assignedTechnician?: string;
  createdDate: string;
  targetDate: string;
  completedDate?: string;
  downtimeHours?: number;
  actionsTaken?: string;
  usedParts: UsedPart[];
  priorityScore?: number;
}

export type PartCategory = 'Heater' | 'Electrical' | 'Mechanical';

export interface SparePart {
  id: string;
  category: PartCategory;
  name: string;
  stockAwal: number;
  currentStock: number;
  minStock: number;
  maxStock: number;
  unit: string;
  rackLocation: string;
  dailyLogs?: { [day: number]: number };
  lastUpdated: string;
}

export interface StockLog {
  id: string;
  partId: string;
  partName: string;
  category: PartCategory;
  type: 'in' | 'out';
  quantity: number;
  date: string;
  referenceWO?: string;
  machineNo?: number;
  pic: string;
  notes: string;
}

export type PMFrequency = 'Harian' | 'Mingguan' | 'Bulanan' | '6 Bulanan' | 'Tahunan';
export type PMStatus = 'Scheduled' | 'In Progress' | 'Completed' | 'Overdue';

export interface ChecklistItem {
  id: string;
  task: string;
  category: string;
  status: 'pending' | 'pass' | 'fail' | 'adjusted';
  notes?: string;
}

export interface PMTask {
  id: string;
  code: string;
  title: string;
  machineId?: string;
  machineName?: string;
  machineNo?: number;
  frequency: PMFrequency;
  dueDate: string;
  completedDate?: string;
  assignedTechnician: string;
  status: PMStatus;
  checklist: ChecklistItem[];
  overallNotes?: string;
}

export interface DocumentSOP {
  id: string;
  code: string;
  title: string;
  category: 'Manual Mesin' | 'Diagram Kelistrikan' | 'SOP Perawatan' | 'K3 / LOTO';
  machineTarget?: string;
  version: string;
  updatedAt: string;
  author: string;
  fileSize: string;
  description: string;
  steps: { stepNo: number; title: string; detail: string; warning?: string }[];
}

export interface ToastNotification {
  id: string;
  title: string;
  message: string;
  type: 'urgent_wo' | 'pm_due' | 'system';
  time: string;
  linkTab?: string;
  targetId?: string;
}
