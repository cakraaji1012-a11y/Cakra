import React, { useState } from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { LoginScreen } from './components/auth/LoginScreen';
import { Navbar } from './components/layout/Navbar';
import { Sidebar } from './components/layout/Sidebar';
import { DashboardView } from './components/dashboard/DashboardView';
import { WorkOrderView } from './components/workorders/WorkOrderView';
import { PreventiveMaintenanceView } from './components/pm/PreventiveMaintenanceView';
import { InventoryView } from './components/inventory/InventoryView';
import { AssetDatabaseView } from './components/assets/AssetDatabaseView';
import { MyAssignedTasksView } from './components/workorders/MyAssignedTasksView';
import { PerformanceReportsView } from './components/reports/PerformanceReportsView';
import { NewTicketModal } from './components/workorders/NewTicketModal';
import { QRScannerModal } from './components/scanner/QRScannerModal';
import { NotificationToaster } from './components/notifications/NotificationToaster';
import { OfflineStatusBar } from './components/offline/OfflineStatusBar';

const MainLayout: React.FC = () => {
  const { currentUser, activeTab } = useApp();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [newTicketModalOpen, setNewTicketModalOpen] = useState(false);
  const [qrScannerModalOpen, setQrScannerModalOpen] = useState(false);

  if (!currentUser) {
    return <LoginScreen />;
  }

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col lg:flex-row font-['Plus_Jakarta_Sans',sans-serif]">
      {/* Sidebar Navigation */}
      <Sidebar
        mobileOpen={mobileMenuOpen}
        onCloseMobile={() => setMobileMenuOpen(false)}
      />

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col min-w-0">
        <Navbar
          onOpenNewTicketModal={() => setNewTicketModalOpen(true)}
          onOpenMobileMenu={() => setMobileMenuOpen(true)}
          onOpenQRScanner={() => setQrScannerModalOpen(true)}
        />

        {/* Offline Status & Background Sync Bar */}
        <OfflineStatusBar />

        <main className="flex-1 p-4 sm:p-6 lg:p-8 max-w-7xl w-full mx-auto">
          {activeTab === 'dashboard' && (
            <DashboardView
              onOpenNewTicket={() => setNewTicketModalOpen(true)}
              onOpenQRScanner={() => setQrScannerModalOpen(true)}
            />
          )}
          {activeTab === 'my-tasks' && (
            <MyAssignedTasksView
              onOpenNewTicketModal={() => setNewTicketModalOpen(true)}
            />
          )}
          {activeTab === 'work-orders' && (
            <WorkOrderView onOpenNewTicketModal={() => setNewTicketModalOpen(true)} />
          )}
          {activeTab === 'pm' && <PreventiveMaintenanceView />}
          {activeTab === 'inventory' && <InventoryView />}
          {activeTab === 'assets' && (
            <AssetDatabaseView onOpenQRScanner={() => setQrScannerModalOpen(true)} />
          )}
          {activeTab === 'reports' && <PerformanceReportsView />}
        </main>
      </div>

      {/* Global New Work Order Ticket Modal */}
      <NewTicketModal
        isOpen={newTicketModalOpen}
        onClose={() => setNewTicketModalOpen(false)}
      />

      {/* Camera QR Code Asset Tag Scanner Modal */}
      <QRScannerModal
        isOpen={qrScannerModalOpen}
        onClose={() => setQrScannerModalOpen(false)}
      />

      {/* Global In-App Web Notification & Urgent Alert Toaster */}
      <NotificationToaster />
    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <MainLayout />
    </AppProvider>
  );
}
