import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  User,
  Machine,
  WorkOrder,
  SparePart,
  StockLog,
  PMTask,
  DocumentSOP,
  Role,
  ToastNotification,
} from '../types';
import {
  playUrgentAlertSound,
  playPMDueAlertSound,
} from '../utils/notificationSound';
import {
  OfflineSyncItem,
  getOfflineQueue,
  saveOfflineQueue,
  enqueueOfflineAction,
  getSimulatedOfflineState,
  setSimulatedOfflineState,
  clearSyncedQueue,
} from '../utils/offlineSync';
import {
  initialUsers,
  initialMachines,
  initialSpareParts,
  initialStockLogs,
  initialWorkOrders,
  initialPMTasks,
  initialSOPDocuments,
} from '../data/initialData';

export interface AppNotification {
  id: string;
  title: string;
  message: string;
  type: 'urgent' | 'warning' | 'info';
  time: string;
  read: boolean;
  linkTab?: string;
}

interface AppContextType {
  currentUser: User | null;
  login: (username: string) => boolean;
  loginAs: (role: Role) => void;
  logout: () => void;
  isAdmin: boolean;
  isStaff: boolean;

  selectedAssetIdForView: string | null;
  setSelectedAssetIdForView: (id: string | null) => void;
  openAssetHistoryById: (query: string | number) => boolean;

  activeTab: string;
  setActiveTab: (tab: string) => void;

  machines: Machine[];
  addMachine: (machine: Omit<Machine, 'id'>) => void;
  updateMachine: (id: string, updates: Partial<Machine>) => void;
  deleteMachine: (id: string) => void;

  workOrders: WorkOrder[];
  createWorkOrder: (wo: Omit<WorkOrder, 'id' | 'ticketNumber' | 'createdDate'>) => void;
  updateWorkOrder: (id: string, updates: Partial<WorkOrder>) => void;
  deleteWorkOrder: (id: string) => void;

  spareParts: SparePart[];
  addSparePart: (part: Omit<SparePart, 'id' | 'lastUpdated'>) => void;
  updateSparePart: (id: string, updates: Partial<SparePart>) => void;
  deleteSparePart: (id: string) => void;

  stockLogs: StockLog[];
  recordStockMovement: (movement: {
    partId: string;
    type: 'in' | 'out';
    quantity: number;
    machineNo?: number;
    referenceWO?: string;
    notes: string;
  }) => boolean;

  pmTasks: PMTask[];
  updatePMTask: (id: string, updates: Partial<PMTask>) => void;
  updateChecklistStatus: (
    taskId: string,
    itemId: string,
    status: 'pending' | 'pass' | 'fail' | 'adjusted',
    notes?: string
  ) => void;
  addPMTask: (task: Omit<PMTask, 'id' | 'code'>) => void;

  sopDocuments: DocumentSOP[];
  addSOP: (sop: Omit<DocumentSOP, 'id'>) => void;
  deleteSOP: (id: string) => void;

  notifications: AppNotification[];
  markNotificationAsRead: (id: string) => void;
  markAllNotificationsAsRead: () => void;

  toasts: ToastNotification[];
  dismissToast: (id: string) => void;
  webNotificationPermission: NotificationPermission | 'unsupported';
  requestWebNotificationPermission: () => Promise<boolean>;
  isSoundEnabled: boolean;
  setIsSoundEnabled: (val: boolean) => void;
  sendStaffAlert: (options: {
    title: string;
    body: string;
    type: 'urgent_wo' | 'pm_due' | 'system';
    targetWOId?: string;
    targetPMId?: string;
    linkTab?: string;
  }) => void;
  triggerTestUrgentAlert: () => void;
  triggerTestPMAlert: () => void;

  isOnline: boolean;
  isSimulatedOffline: boolean;
  toggleSimulatedOffline: () => void;
  offlineQueue: OfflineSyncItem[];
  syncOfflineQueue: () => Promise<number>;
  isSyncing: boolean;

  resetToDefaultData: () => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

const STORAGE_KEYS = {
  USER: 'rm_current_user',
  MACHINES: 'rm_machines_v1',
  WORK_ORDERS: 'rm_work_orders_v1',
  PARTS: 'rm_spare_parts_v1',
  STOCK_LOGS: 'rm_stock_logs_v1',
  PM_TASKS: 'rm_pm_tasks_v1',
  SOPS: 'rm_sops_v1',
};

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Current user
  const [currentUser, setCurrentUser] = useState<User | null>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.USER);
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch {
        return null;
      }
    }
    return null;
  });

  const [activeTab, setActiveTab] = useState<string>('dashboard');
  const [selectedAssetIdForView, setSelectedAssetIdForView] = useState<string | null>(null);

  // Machines
  const [machines, setMachines] = useState<Machine[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.MACHINES);
    if (saved) {
      try { return JSON.parse(saved); } catch {}
    }
    return initialMachines;
  });

  // Work Orders
  const [workOrders, setWorkOrders] = useState<WorkOrder[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.WORK_ORDERS);
    if (saved) {
      try { return JSON.parse(saved); } catch {}
    }
    return initialWorkOrders;
  });

  // Spare Parts
  const [spareParts, setSpareParts] = useState<SparePart[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.PARTS);
    if (saved) {
      try { return JSON.parse(saved); } catch {}
    }
    return initialSpareParts;
  });

  // Stock Logs
  const [stockLogs, setStockLogs] = useState<StockLog[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.STOCK_LOGS);
    if (saved) {
      try { return JSON.parse(saved); } catch {}
    }
    return initialStockLogs;
  });

  // PM Tasks
  const [pmTasks, setPmTasks] = useState<PMTask[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.PM_TASKS);
    if (saved) {
      try { return JSON.parse(saved); } catch {}
    }
    return initialPMTasks;
  });

  // SOPs
  const [sopDocuments, setSopDocuments] = useState<DocumentSOP[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.SOPS);
    if (saved) {
      try { return JSON.parse(saved); } catch {}
    }
    return initialSOPDocuments;
  });

  // Sync to localStorage
  useEffect(() => {
    if (currentUser) {
      localStorage.setItem(STORAGE_KEYS.USER, JSON.stringify(currentUser));
    } else {
      localStorage.removeItem(STORAGE_KEYS.USER);
    }
  }, [currentUser]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.MACHINES, JSON.stringify(machines));
  }, [machines]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.WORK_ORDERS, JSON.stringify(workOrders));
  }, [workOrders]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.PARTS, JSON.stringify(spareParts));
  }, [spareParts]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.STOCK_LOGS, JSON.stringify(stockLogs));
  }, [stockLogs]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.PM_TASKS, JSON.stringify(pmTasks));
  }, [pmTasks]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.SOPS, JSON.stringify(sopDocuments));
  }, [sopDocuments]);

  // Notifications calculation
  const [notifications, setNotifications] = useState<AppNotification[]>([]);

  useEffect(() => {
    const notifs: AppNotification[] = [];

    // Emergency or High priority open/in-progress work orders
    workOrders
      .filter((wo) => (wo.urgency === 'Emergency' || wo.urgency === 'High') && wo.status !== 'Closed')
      .forEach((wo) => {
        notifs.push({
          id: `notif-wo-${wo.id}`,
          title: `[${wo.urgency.toUpperCase()}] Tiket ${wo.ticketNumber}`,
          message: `${wo.machineName}: ${wo.title} (${wo.status})`,
          type: wo.urgency === 'Emergency' ? 'urgent' : 'warning',
          time: wo.createdDate,
          read: false,
          linkTab: 'work-orders',
        });
      });

    // Low stock auto-reorder alert
    spareParts
      .filter((p) => p.currentStock <= p.minStock)
      .slice(0, 8)
      .forEach((p) => {
        notifs.push({
          id: `notif-part-${p.id}`,
          title: `Peringatan Stok: ${p.name}`,
          message: `Sisa stok ${p.currentStock} ${p.unit} (Batas Min: ${p.minStock} ${p.unit}). Perlu auto-reorder segera!`,
          type: p.currentStock === 0 ? 'urgent' : 'warning',
          time: p.lastUpdated,
          read: false,
          linkTab: 'inventory',
        });
      });

    // PM Task upcoming
    pmTasks
      .filter((pm) => pm.status === 'Scheduled')
      .forEach((pm) => {
        notifs.push({
          id: `notif-pm-${pm.id}`,
          title: `Jadwal Servis: ${pm.code}`,
          message: `${pm.title} jatuh tempo pada ${pm.dueDate}`,
          type: 'info',
          time: pm.dueDate,
          read: false,
          linkTab: 'pm',
        });
      });

    setNotifications(notifs);
  }, [workOrders, spareParts, pmTasks]);

  const markNotificationAsRead = (id: string) => {
    setNotifications((prev) =>
      prev.map((n) => (n.id === id ? { ...n, read: true } : n))
    );
  };

  const markAllNotificationsAsRead = () => {
    setNotifications((prev) => prev.map((n) => ({ ...n, read: true })));
  };

  // Toast notifications & Web Notification state
  const [toasts, setToasts] = useState<ToastNotification[]>([]);
  const [isSoundEnabled, setIsSoundEnabled] = useState<boolean>(true);
  const [webNotificationPermission, setWebNotificationPermission] = useState<
    NotificationPermission | 'unsupported'
  >('default');

  useEffect(() => {
    if (typeof window !== 'undefined' && 'Notification' in window) {
      setWebNotificationPermission(Notification.permission);
    } else {
      setWebNotificationPermission('unsupported');
    }
  }, []);

  const requestWebNotificationPermission = async (): Promise<boolean> => {
    if (typeof window === 'undefined' || !('Notification' in window)) {
      setWebNotificationPermission('unsupported');
      return false;
    }
    try {
      const perm = await Notification.requestPermission();
      setWebNotificationPermission(perm);
      return perm === 'granted';
    } catch {
      return false;
    }
  };

  const dismissToast = (id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  };

  const sendStaffAlert = (options: {
    title: string;
    body: string;
    type: 'urgent_wo' | 'pm_due' | 'system';
    targetWOId?: string;
    targetPMId?: string;
    linkTab?: string;
  }) => {
    // 1. Audio chime
    if (isSoundEnabled) {
      if (options.type === 'urgent_wo') {
        playUrgentAlertSound();
      } else {
        playPMDueAlertSound();
      }
    }

    // 2. Browser Native Web Notification
    if (
      typeof window !== 'undefined' &&
      'Notification' in window &&
      Notification.permission === 'granted'
    ) {
      try {
        const notif = new Notification(options.title, {
          body: options.body,
          tag: `${options.type}-${Date.now()}`,
        });
        notif.onclick = () => {
          window.focus();
          if (options.linkTab) {
            setActiveTab(options.linkTab);
          } else if (options.type === 'urgent_wo') {
            setActiveTab('my-tasks');
          } else if (options.type === 'pm_due') {
            setActiveTab('pm');
          }
        };
      } catch (err) {
        console.warn('Native web notification dispatch error:', err);
      }
    }

    // 3. Floating In-App Toast
    const toastId = `toast-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`;
    const newToast: ToastNotification = {
      id: toastId,
      title: options.title,
      message: options.body,
      type: options.type,
      time: new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' }),
      linkTab: options.linkTab || (options.type === 'urgent_wo' ? 'my-tasks' : 'pm'),
      targetId: options.targetWOId || options.targetPMId,
    };

    setToasts((prev) => [newToast, ...prev.slice(0, 3)]);

    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== toastId));
    }, 8500);

    // 4. Also register to persistent notifications drawer
    const appNotif: AppNotification = {
      id: `notif-${Date.now()}`,
      title: options.title,
      message: options.body,
      type: options.type === 'urgent_wo' ? 'urgent' : 'warning',
      time: new Date().toISOString().slice(0, 16).replace('T', ' '),
      read: false,
      linkTab: options.linkTab || (options.type === 'urgent_wo' ? 'my-tasks' : 'pm'),
    };
    setNotifications((prev) => [appNotif, ...prev]);
  };

  const triggerTestUrgentAlert = () => {
    sendStaffAlert({
      title: '🚨 [EMERGENCY] Tiket Baru Ditugaskan: WO-2026-09-001',
      body: 'Unit TOSHIBA No. 38 (450 Ton): Tekanan oli hidrolik drop drastis dari 140 bar ke 60 bar saat mold clamping. Ditugaskan segera kepada Teknisi PIC!',
      type: 'urgent_wo',
      targetWOId: 'wo-1',
      linkTab: 'my-tasks',
    });
  };

  const triggerTestPMAlert = () => {
    sendStaffAlert({
      title: '📅 [JATUH TEMPO HARI INI] PM-001 Servis Rutin Pompa Hidrolik',
      body: 'Jadwal pemeliharaan berkala 5 poin filter & oli pompa Mesin Injeksi No. 2 TOSHIBA jatuh tempo hari ini. Segera tindak lanjuti checklist servis.',
      type: 'pm_due',
      targetPMId: 'pm-1',
      linkTab: 'pm',
    });
  };

  // Offline & Synchronization state
  const [isBrowserOnline, setIsBrowserOnline] = useState<boolean>(() =>
    typeof navigator !== 'undefined' ? navigator.onLine : true
  );
  const [isSimulatedOffline, setIsSimulatedOffline] = useState<boolean>(() =>
    getSimulatedOfflineState()
  );
  const [offlineQueue, setOfflineQueue] = useState<OfflineSyncItem[]>(() =>
    getOfflineQueue()
  );
  const [isSyncing, setIsSyncing] = useState<boolean>(false);

  const isOnline = isBrowserOnline && !isSimulatedOffline;

  // Listen to browser network changes
  useEffect(() => {
    const handleOnline = () => {
      setIsBrowserOnline(true);
      // Auto-sync when network returns
      if (!isSimulatedOffline) {
        setTimeout(() => {
          syncOfflineQueue();
        }, 1000);
      }
    };
    const handleOffline = () => {
      setIsBrowserOnline(false);
      sendStaffAlert({
        title: '⚠️ Koneksi Terputus (Mode Offline Aktif)',
        body: 'Anda tetap dapat mengakses aplikasi dan memperbarui status Work Order. Perubahan akan disimpan lokal dan disinkronkan saat online.',
        type: 'system',
      });
    };

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, [isSimulatedOffline]);

  const toggleSimulatedOffline = () => {
    setIsSimulatedOffline((prev) => {
      const next = !prev;
      setSimulatedOfflineState(next);
      if (next) {
        sendStaffAlert({
          title: '🔌 Mode Offline Diaktifkan',
          body: 'Aplikasi sekarang dalam mode simulasi terputus. Input dan update status WO akan disimpan ke antrean lokal.',
          type: 'system',
        });
      } else {
        sendStaffAlert({
          title: '🟢 Mode Online Dipulihkan',
          body: 'Koneksi kembali normal. Memulai proses sinkronisasi antrean data offline ke server...',
          type: 'system',
        });
        setTimeout(() => {
          syncOfflineQueue();
        }, 600);
      }
      return next;
    });
  };

  const syncOfflineQueue = async (): Promise<number> => {
    const currentQueue = getOfflineQueue().filter((item) => item.status === 'pending');
    if (currentQueue.length === 0) return 0;

    setIsSyncing(true);
    // Simulate real sync latency
    await new Promise((resolve) => setTimeout(resolve, 1200));

    // Mark all as synced
    const updated = currentQueue.map((item) => ({ ...item, status: 'synced' as const }));
    saveOfflineQueue(updated);
    setOfflineQueue(updated);
    setIsSyncing(false);

    // Alert user
    sendStaffAlert({
      title: '✓ Sinkronisasi Berhasil!',
      body: `${currentQueue.length} data pembaruan offline (termasuk status Work Order) telah berhasil disinkronkan ke server secara otomatis.`,
      type: 'system',
    });

    // Clean up synced items after 4 seconds
    setTimeout(() => {
      clearSyncedQueue();
      setOfflineQueue(getOfflineQueue());
    }, 4000);

    return currentQueue.length;
  };

  // Auth
  const login = (username: string): boolean => {
    const user = initialUsers.find(
      (u) => u.username.toLowerCase() === username.trim().toLowerCase()
    );
    if (user) {
      setCurrentUser(user);
      return true;
    }
    return false;
  };

  const loginAs = (role: Role) => {
    const user = initialUsers.find((u) => u.role === role);
    if (user) {
      setCurrentUser(user);
    }
  };

  const logout = () => {
    setCurrentUser(null);
  };

  const isAdmin = currentUser?.role === 'admin';
  const isStaff = currentUser?.role === 'staff';

  // Machines CRUD
  const addMachine = (machineData: Omit<Machine, 'id'>) => {
    const newMachine: Machine = {
      ...machineData,
      id: `mc-${Date.now()}`,
    };
    setMachines((prev) => [newMachine, ...prev]);
  };

  const updateMachine = (id: string, updates: Partial<Machine>) => {
    setMachines((prev) =>
      prev.map((m) => (m.id === id ? { ...m, ...updates } : m))
    );
  };

  const deleteMachine = (id: string) => {
    setMachines((prev) => prev.filter((m) => m.id !== id));
  };

  // Work Orders CRUD
  const createWorkOrder = (
    woData: Omit<WorkOrder, 'id' | 'ticketNumber' | 'createdDate'>
  ) => {
    const now = new Date();
    const dateStr = now.toISOString().slice(0, 10);
    const timeStr = now.toTimeString().slice(0, 5);
    const seq = String(workOrders.length + 1).padStart(3, '0');
    const ticketNumber = `WO-${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${seq}`;

    const newWO: WorkOrder = {
      ...woData,
      id: `wo-${Date.now()}`,
      ticketNumber,
      createdDate: `${dateStr} ${timeStr}`,
    };

    setWorkOrders((prev) => [newWO, ...prev]);

    // If WO has emergency urgency, update machine status to breakdown or maintenance
    if (newWO.urgency === 'Emergency' && newWO.machineId) {
      updateMachine(newWO.machineId, { status: 'breakdown' });
    } else if (newWO.urgency === 'High' && newWO.machineId) {
      updateMachine(newWO.machineId, { status: 'maintenance' });
    }

    // Offline enqueue if connection is disconnected
    if (!isOnline) {
      const queueItem = enqueueOfflineAction({
        entity: 'work_order',
        action: 'CREATE_WO',
        title: `Lapor Tiket Baru: ${newWO.ticketNumber} (${newWO.machineName})`,
        payload: newWO,
      });
      setOfflineQueue((q) => [queueItem, ...q]);

      sendStaffAlert({
        title: `📥 Tiket Tersimpan di Antrean Offline: ${newWO.ticketNumber}`,
        body: `Laporan gangguan disimpan lokal pada perangkat. Akan disinkronkan ke server saat terhubung kembali.`,
        type: 'system',
      });
    }

    // Web & In-App Notification alert for urgent work order
    if (newWO.urgency === 'Emergency' || newWO.urgency === 'High') {
      sendStaffAlert({
        title: `🚨 [${newWO.urgency.toUpperCase()}] Tiket Ditugaskan: ${newWO.ticketNumber}`,
        body: `${newWO.machineName}: ${newWO.title}. PIC: ${newWO.assignedTechnician || 'Teknisi R&M'}.`,
        type: 'urgent_wo',
        targetWOId: newWO.id,
        linkTab: 'my-tasks',
      });
    }
  };

  const updateWorkOrder = (id: string, updates: Partial<WorkOrder>) => {
    setWorkOrders((prev) =>
      prev.map((wo) => {
        if (wo.id === id) {
          const updated = { ...wo, ...updates };
          // If closing work order, restore machine status to active if applicable
          if (updates.status === 'Closed' && wo.machineId) {
            updateMachine(wo.machineId, { status: 'active' });
          }

          // If offline, enqueue for background sync
          if (!isOnline) {
            const queueItem = enqueueOfflineAction({
              entity: 'work_order',
              action: 'UPDATE_STATUS',
              title: `Update WO ${wo.ticketNumber} (${updates.status || 'Perubahan Data'})`,
              payload: { id, updates },
            });
            setOfflineQueue((q) => [queueItem, ...q]);

            sendStaffAlert({
              title: `📥 Tersimpan di Antrean Offline: ${wo.ticketNumber}`,
              body: `Pembaruan status ke "${updates.status || 'Updated'}" disimpan aman di perangkat. Akan otomatis disinkronkan saat terhubung kembali.`,
              type: 'system',
            });
          }

          // Alert staff if assigned or escalated to Emergency/High
          if (
            updates.status !== 'Closed' &&
            ((updates.assignedTechnician && updates.assignedTechnician !== wo.assignedTechnician) ||
              (updates.urgency === 'Emergency' && wo.urgency !== 'Emergency') ||
              (updates.urgency === 'High' && wo.urgency !== 'High'))
          ) {
            sendStaffAlert({
              title: `⚡ Penugasan Tiket Baru: ${wo.ticketNumber}`,
              body: `${wo.machineName}: ${updates.title || wo.title}. PIC: ${updates.assignedTechnician || wo.assignedTechnician}.`,
              type: 'urgent_wo',
              targetWOId: wo.id,
              linkTab: 'my-tasks',
            });
          }

          return updated;
        }
        return wo;
      })
    );
  };

  const deleteWorkOrder = (id: string) => {
    setWorkOrders((prev) => prev.filter((wo) => wo.id !== id));
  };

  // Spare Parts CRUD
  const addSparePart = (partData: Omit<SparePart, 'id' | 'lastUpdated'>) => {
    const newPart: SparePart = {
      ...partData,
      id: `part-${Date.now()}`,
      lastUpdated: new Date().toISOString().slice(0, 10),
    };
    setSpareParts((prev) => [newPart, ...prev]);
  };

  const updateSparePart = (id: string, updates: Partial<SparePart>) => {
    setSpareParts((prev) =>
      prev.map((p) =>
        p.id === id
          ? {
              ...p,
              ...updates,
              lastUpdated: new Date().toISOString().slice(0, 10),
            }
          : p
      )
    );
  };

  const deleteSparePart = (id: string) => {
    setSpareParts((prev) => prev.filter((p) => p.id !== id));
  };

  // Record Stock Movement
  const recordStockMovement = ({
    partId,
    type,
    quantity,
    machineNo,
    referenceWO,
    notes,
  }: {
    partId: string;
    type: 'in' | 'out';
    quantity: number;
    machineNo?: number;
    referenceWO?: string;
    notes: string;
  }): boolean => {
    const part = spareParts.find((p) => p.id === partId);
    if (!part) return false;

    if (type === 'out' && part.currentStock < quantity) {
      return false; // not enough stock
    }

    const newStock =
      type === 'in'
        ? part.currentStock + quantity
        : Math.max(0, part.currentStock - quantity);

    const today = new Date().toISOString().slice(0, 10);

    // Update part
    updateSparePart(partId, {
      currentStock: newStock,
      lastUpdated: today,
    });

    // Create log
    const newLog: StockLog = {
      id: `log-${Date.now()}`,
      partId,
      partName: part.name,
      category: part.category,
      type,
      quantity,
      date: today,
      machineNo,
      referenceWO,
      pic: currentUser?.name || 'Teknisi R&M',
      notes,
    };

    setStockLogs((prev) => [newLog, ...prev]);
    return true;
  };

  // PM tasks
  const updatePMTask = (id: string, updates: Partial<PMTask>) => {
    setPmTasks((prev) =>
      prev.map((task) => (task.id === id ? { ...task, ...updates } : task))
    );
  };

  const updateChecklistStatus = (
    taskId: string,
    itemId: string,
    status: 'pending' | 'pass' | 'fail' | 'adjusted',
    notes?: string
  ) => {
    setPmTasks((prev) =>
      prev.map((task) => {
        if (task.id === taskId) {
          const updatedChecklist = task.checklist.map((item) =>
            item.id === itemId ? { ...item, status, notes: notes ?? item.notes } : item
          );
          const allCompleted = updatedChecklist.every((i) => i.status !== 'pending');
          return {
            ...task,
            checklist: updatedChecklist,
            status: allCompleted ? 'Completed' : 'In Progress',
            completedDate: allCompleted ? new Date().toISOString().slice(0, 10) : task.completedDate,
          };
        }
        return task;
      })
    );
  };

  const addPMTask = (taskData: Omit<PMTask, 'id' | 'code'>) => {
    const code = `PM-${taskData.frequency.toUpperCase().slice(0, 4)}-${String(pmTasks.length + 1).padStart(2, '0')}`;
    const newTask: PMTask = {
      ...taskData,
      id: `pm-${Date.now()}`,
      code,
    };
    setPmTasks((prev) => [newTask, ...prev]);

    // Send PM due alert
    sendStaffAlert({
      title: `📅 Jadwal Servis PM Baru: ${code}`,
      body: `${newTask.title} untuk ${newTask.machineName || 'Mesin Injeksi'}. Jatuh tempo: ${newTask.dueDate}. Teknisi: ${newTask.assignedTechnician}.`,
      type: 'pm_due',
      targetPMId: newTask.id,
      linkTab: 'pm',
    });
  };

  // SOPs
  const addSOP = (sopData: Omit<DocumentSOP, 'id'>) => {
    const newSop: DocumentSOP = {
      ...sopData,
      id: `sop-${Date.now()}`,
    };
    setSopDocuments((prev) => [newSop, ...prev]);
  };

  const deleteSOP = (id: string) => {
    setSopDocuments((prev) => prev.filter((s) => s.id !== id));
  };

  const openAssetHistoryById = (query: string | number): boolean => {
    const str = String(query).trim().toLowerCase();

    // 1. Direct ID match
    let target = machines.find((m) => m.id.toLowerCase() === str);

    // 2. Format: "mc-2", "asset-mc-2", "mc 2", or numeric "2"
    if (!target) {
      const numMatch = str.match(/\d+/);
      if (numMatch) {
        const num = parseInt(numMatch[0]);
        target = machines.find((m) => m.noMc === num);
      }
    }

    // 3. Match by machine name
    if (!target) {
      target = machines.find((m) => m.name.toLowerCase().includes(str));
    }

    if (target) {
      setSelectedAssetIdForView(target.id);
      setActiveTab('assets');
      return true;
    }
    return false;
  };

  const resetToDefaultData = () => {
    localStorage.clear();
    setMachines(initialMachines);
    setSpareParts(initialSpareParts);
    setStockLogs(initialStockLogs);
    setWorkOrders(initialWorkOrders);
    setPmTasks(initialPMTasks);
    setSopDocuments(initialSOPDocuments);
  };

  return (
    <AppContext.Provider
      value={{
        currentUser,
        login,
        loginAs,
        logout,
        isAdmin,
        isStaff,
        activeTab,
        setActiveTab,
        selectedAssetIdForView,
        setSelectedAssetIdForView,
        openAssetHistoryById,
        machines,
        addMachine,
        updateMachine,
        deleteMachine,
        workOrders,
        createWorkOrder,
        updateWorkOrder,
        deleteWorkOrder,
        spareParts,
        addSparePart,
        updateSparePart,
        deleteSparePart,
        stockLogs,
        recordStockMovement,
        pmTasks,
        updatePMTask,
        updateChecklistStatus,
        addPMTask,
        sopDocuments,
        addSOP,
        deleteSOP,
        notifications,
        markNotificationAsRead,
        markAllNotificationsAsRead,
        toasts,
        dismissToast,
        webNotificationPermission,
        requestWebNotificationPermission,
        isSoundEnabled,
        setIsSoundEnabled,
        sendStaffAlert,
        triggerTestUrgentAlert,
        triggerTestPMAlert,
        isOnline,
        isSimulatedOffline,
        toggleSimulatedOffline,
        offlineQueue,
        syncOfflineQueue,
        isSyncing,
        resetToDefaultData,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
